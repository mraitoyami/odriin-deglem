import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { viteSingleFile } from "vite-plugin-singlefile";

// `npm run build:single` → dist-single/index.html: интернэт, сервергүйгээр нээгддэг ганц HTML файл (танилцуулгад).
export default defineConfig(({ mode }) => ({
  plugins: mode === "single" ? [react(), viteSingleFile()] : [react()],
  build: mode === "single" ? { outDir: "dist-single", assetsInlineLimit: 100_000_000 } : {},
}));
