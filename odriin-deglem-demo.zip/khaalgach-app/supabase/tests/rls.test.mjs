// RLS тест: PGlite (WASM Postgres) дээр Supabase-ийн auth.uid()-г дуурайж ажиллуулна.
// Ажиллуулах: npm i @electric-sql/pglite && node supabase/tests/rls.test.mjs
import { PGlite } from "@electric-sql/pglite";
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";

const here = dirname(fileURLToPath(import.meta.url));
const sql = readFileSync(join(here, "../migrations/0001_init.sql"), "utf8");
const db = new PGlite();

await db.exec(`
  create role anon nologin; create role authenticated nologin; create role service_role nologin bypassrls;
  create schema auth;
  create table auth.users (id uuid primary key, email text, raw_user_meta_data jsonb default '{}');
  create function auth.uid() returns uuid language sql stable as
    $$ select nullif(current_setting('request.jwt.claim.sub', true), '')::uuid $$;
  grant usage on schema auth to anon, authenticated;
  grant execute on function auth.uid() to anon, authenticated;
`);
await db.exec(sql);

const U = {
  stu: "00000000-0000-0000-0000-000000000001",
  stu2: "00000000-0000-0000-0000-000000000002",
  tea: "00000000-0000-0000-0000-000000000003",
  par: "00000000-0000-0000-0000-000000000004",
  sneaky: "00000000-0000-0000-0000-000000000005",
};
// Admin (superuser) үйлдэл: хэрэглэгч, role, холбоос
for (const [k, id] of Object.entries(U))
  await db.query(`insert into auth.users (id,email,raw_user_meta_data) values ($1,$2,$3)`,
    [id, k + "@t.mn", JSON.stringify({ full_name: k, role: "teacher" })]); // metadata-д role бичсэн ч үл тооно
await db.exec(`
  update profiles set role='student' where id in ('${U.stu}','${U.stu2}');
  update profiles set role='teacher' where id='${U.tea}';
  update profiles set role='guardian' where id='${U.par}';
  insert into students (id,user_id,full_name) values
    ('10000000-0000-0000-0000-000000000001','${U.stu}','Бат'),
    ('10000000-0000-0000-0000-000000000002','${U.stu2}','Сараа');
  insert into teacher_students values ('${U.tea}','10000000-0000-0000-0000-000000000001');
  insert into guardian_students values ('${U.par}','10000000-0000-0000-0000-000000000001');
  select seed_student_plan('10000000-0000-0000-0000-000000000001');
  select seed_student_plan('10000000-0000-0000-0000-000000000002');
`);
const S1 = "10000000-0000-0000-0000-000000000001", S2 = "10000000-0000-0000-0000-000000000002";

let pass = 0, fail = 0;
async function as(uid, fn) {
  await db.exec(`reset role; select set_config('request.jwt.claim.sub', '${uid || ""}', false); set role ${uid ? "authenticated" : "anon"};`);
  try { return await fn(); } finally { await db.exec(`reset role; select set_config('request.jwt.claim.sub','',false);`); }
}
async function expectOk(name, q, params, check) {
  try { const r = await db.query(q, params); const ok = check ? check(r) : true;
    ok ? pass++ : fail++; console.log(ok ? "  ✓" : "  ✗", name, ok ? "" : JSON.stringify(r.rows)); }
  catch (e) { fail++; console.log("  ✗", name, "→", e.message); }
}
async function expectDenied(name, q, params, rowsCheck) {
  try { const r = await db.query(q, params);
    const denied = rowsCheck ? rowsCheck(r) : (r.affectedRows === 0 || r.rows.length === 0);
    denied ? pass++ : fail++; console.log(denied ? "  ✓" : "  ✗", name, denied ? "(хоосон)" : "ЗӨВШӨӨРӨГДЛӨӨ: " + JSON.stringify(r.rows).slice(0, 120)); }
  catch (e) { pass++; console.log("  ✓", name, "(татгалзсан:", e.message.slice(0, 70) + ")"); }
}
const today = (await db.query(`select today_ub()::text d`)).rows[0].d;
const old = (await db.query(`select (today_ub()-30)::text d`)).rows[0].d;
const taskOf = async sid => (await db.query(`select id from tasks where student_id=$1 order by sort limit 1`, [sid])).rows[0].id;
const t1 = await taskOf(S1), t2 = await taskOf(S2);

console.log("Профайл ба role");
await as(U.sneaky, async () => {
  await expectOk("metadata-д role бичсэн ч role хоосон", `select role from profiles where id=$1`, [U.sneaky], r => r.rows[0].role === null);
  await expectDenied("өөрийн role-ийг teacher болгох", `update profiles set role='teacher' where id=$1`, [U.sneaky]);
  await expectOk("verify_login_role(teacher) = false", `select verify_login_role('teacher') v`, [], r => r.rows[0].v === false);
  await expectDenied("өөрийгөө багшаар холбох", `insert into teacher_students values ($1,$2)`, [U.sneaky, S1]);
  await expectDenied("ямар ч сурагч харахгүй", `select * from students`, []);
});
await as(U.stu, async () => {
  await expectOk("сурагч verify_login_role(student)", `select verify_login_role('student') v`, [], r => r.rows[0].v === true);
  await expectOk("сурагч verify_login_role(teacher) = false", `select verify_login_role('teacher') v`, [], r => r.rows[0].v === false);
});

console.log("Сурагч");
await as(U.stu, async () => {
  await expectOk("зөвхөн өөрийгөө харна", `select id from students`, [], r => r.rows.length === 1 && r.rows[0].id === S1);
  await expectOk("өнөөдрийн даалгавар тэмдэглэх", `insert into task_logs (student_id,task_id,log_date,status) values ($1,$2,$3,'done')`, [S1, t1, today]);
  await expectOk("updated_by сервер талд тогтоогдсон", `select updated_by from task_logs where task_id=$1`, [t1], r => r.rows[0].updated_by === U.stu);
  await expectOk("төлөв өөрчлөх (help)", `update task_logs set status='help' where task_id=$1 and log_date=$2`, [t1, today], r => r.affectedRows === 1);
  await expectDenied("30 хоногийн өмнөх өдрийг засах", `insert into task_logs (student_id,task_id,log_date,status) values ($1,$2,$3,'done')`, [S1, t1, old]);
  await expectDenied("өөр сурагчийн даалгаврыг тэмдэглэх", `insert into task_logs (student_id,task_id,log_date,status) values ($1,$2,$3,'done')`, [S2, t2, today]);
  await expectDenied("өөрийн student_id-гаар бусдын task тэмдэглэх", `insert into task_logs (student_id,task_id,log_date,status) values ($1,$2,$3,'done')`, [S1, t2, today]);
  await expectOk("өдрийн тэмдэглэл бичих", `insert into student_notes (student_id,log_date,note) values ($1,$2,'Сайхан өдөр')`, [S1, today]);
  await expectDenied("даалгавар засах", `update tasks set title='x' where student_id=$1`, [S1]);
  await expectDenied("гэрийн хуудас бөглөх", `insert into home_logs (student_id,log_date,screen_minutes) values ($1,$2,10)`, [S1, today]);
  await expectDenied("багшийн тэмдэглэл харах", `select * from teacher_notes`, []);
  await expectDenied("өөрийн зорилгын хувийг өөрчлөх", `update students set goal_pct=10 where id=$1`, [S1]);
  await expectDenied("seed_student_plan дуудах", `select seed_student_plan($1)`, [S1]);
});

console.log("Багш");
await as(U.tea, async () => {
  await expectOk("зөвхөн хариуцсан сурагч", `select id from students`, [], r => r.rows.length === 1 && r.rows[0].id === S1);
  await expectOk("сурагчийн бүртгэл харна", `select * from task_logs`, [], r => r.rows.length === 1);
  await expectOk("даалгавар нэмэх", `insert into tasks (student_id,category,title) values ($1,'study','Шинэ')`, [S1]);
  await expectOk("зорилгын хувь өөрчлөх", `update students set goal_pct=70 where id=$1`, [S1], r => r.affectedRows === 1);
  await expectDenied("сурагчийн нэрийг өөрчлөх (баганын эрхгүй)", `update students set full_name='x' where id=$1`, [S1]);
  await expectDenied("хариуцаагүй сурагчид даалгавар нэмэх", `insert into tasks (student_id,category,title) values ($1,'study','x')`, [S2]);
  await expectDenied("даалгаврыг өөр сурагч руу шилжүүлэх", `update tasks set student_id=$2 where student_id=$1`, [S1, S2]);
  await expectDenied("сурагчийн оронд даалгавар тэмдэглэх", `update task_logs set status='done'`, []);
  await expectOk("тэмдэглэл бичих", `insert into teacher_notes (student_id,body) values ($1,'Сайн ахицтай')`, [S1]);
  await expectOk("зохиогч сервер талд тогтоогдсон", `select author_id from teacher_notes`, [], r => r.rows[0].author_id === U.tea);
  await expectOk("хуваалцахгүй тэмдэглэл", `insert into teacher_notes (student_id,body,share_with_guardian) values ($1,'Дотоод',false)`, [S1]);
  await expectOk("өдрийн зорилго тохируулах", `insert into day_goals (student_id,log_date,goal) values ($1,$2,'2 өгүүлбэр бичих')`, [S1, today]);
  await expectDenied("гэрийн хуудас бөглөх", `insert into home_logs (student_id,log_date) values ($1,$2)`, [S1, today]);
  await expectDenied("өөрийгөө өөр сурагчид холбох", `insert into teacher_students values ($1,$2)`, [U.tea, S2]);
  await expectOk("шагнал нэмэх", `insert into rewards (student_id,title,cost) values ($1,'Тест шагнал',5)`, [S1]);
  await expectDenied("хариуцаагүй сурагчид шагнал нэмэх", `insert into rewards (student_id,title,cost) values ($1,'x',5)`, [S2]);
  await expectOk("даалгаврын оноо өөрчлөх", `update tasks set points=7 where student_id=$1 and title='Шинэ'`, [S1], r => r.affectedRows === 1);
  await expectDenied("сурагчийн өмнөөс шагнал авах", `select redeem_reward(id) from rewards where title='Тест шагнал'`, []);
});

console.log("Оноо ба шагнал");
await as(U.stu, async () => {
  await expectOk("даалгавар хийхэд оноо нэмэгдэнэ", `update task_logs set status='done' where task_id=$1 and log_date=$2`, [t1, today], r => r.affectedRows === 1);
  await expectOk("оноо = 5", `select points_summary($1) s`, [S1], r => r.rows[0].s.balance === 5);
  await expectOk("ижил даалгаврыг дахин тэмдэглэхэд давхардахгүй",
    `insert into task_logs (student_id,task_id,log_date,status) values ($1,$2,$3,'done') on conflict (task_id,log_date) do update set status='done'`, [S1, t1, today]);
  await expectOk("оноо 5 хэвээр", `select points_summary($1) s`, [S1], r => r.rows[0].s.balance === 5);
  await expectDenied("оноо хүрэхгүй шагнал авах", `select redeem_reward(id) from rewards where student_id=$1 and title='Хаалгачийн бээлий'`, [S1]);
  await expectOk("оноо хүрэх шагнал авах", `select (redeem_reward(id)).cost c from rewards where title='Тест шагнал'`, [], r => r.rows[0].c === 5);
  await expectOk("оноо 0 болсон", `select points_summary($1) s`, [S1], r => r.rows[0].s.balance === 0 && r.rows[0].s.spent === 5);
  await expectDenied("дахин авах (оноо хүрэлцэхгүй)", `select redeem_reward(id) from rewards where title='Тест шагнал'`, []);
  await expectDenied("зарцуулсан оноотой даалгаврыг буцаах", `update task_logs set status='partial' where task_id=$1 and log_date=$2`, [t1, today]);
  await expectDenied("redemptions-д шууд бичих", `insert into redemptions (student_id,title,cost) values ($1,'x',1)`, [S1]);
  await expectDenied("өөр сурагчийн оноо харах", `select points_summary($1)`, [S2]);
  await expectDenied("өөрийн даалгаврын оноог өсгөх", `update tasks set points=100 where student_id=$1`, [S1]);
});

console.log("Эцэг эх");
await as(U.par, async () => {
  await expectOk("зөвхөн өөрийн хүүхэд", `select id from students`, [], r => r.rows.length === 1 && r.rows[0].id === S1);
  await expectOk("хуваалцсан тэмдэглэлийг л харна", `select body from teacher_notes`, [], r => r.rows.length === 1 && r.rows[0].body === "Сайн ахицтай");
  await expectOk("гэрийн хуудас бөглөх", `insert into home_logs (student_id,log_date,screen_minutes,movement_minutes) values ($1,$2,60,20)`, [S1, today]);
  await expectOk("гэрийн хуудас засах", `update home_logs set screen_minutes=45 where student_id=$1 and log_date=$2`, [S1, today], r => r.affectedRows === 1);
  await expectDenied("даалгавар нэмэх", `insert into tasks (student_id,category,title) values ($1,'study','x')`, [S1]);
  await expectDenied("хүүхдийн оронд даалгавар тэмдэглэх", `insert into task_logs (student_id,task_id,log_date,status) values ($1,$2,$3,'done')`, [S1, t1, (await db.query(`select (today_ub()-1)::text d`)).rows[0].d]);
  await expectDenied("хуваарь устгах", `delete from schedule_items where student_id=$1`, [S1]);
  await expectOk("хүүхдийн авсан шагналыг харна", `select title from redemptions`, [], r => r.rows.length === 1);
  await expectDenied("шагнал засах", `update rewards set cost=1 where student_id=$1`, [S1]);
  await expectDenied("бусдын хүүхдийн бүртгэл", `select * from task_logs where student_id=$1`, [S2]);
});

console.log("Нэвтрээгүй (anon)");
await as(null, async () => {
  await expectDenied("сурагчдыг унших", `select * from students`, []);
  await expectDenied("seed_student_plan дуудах", `select seed_student_plan($1)`, [S1]);
  await expectDenied("points_summary дуудах", `select points_summary($1)`, [S1]);
  await expectDenied("redeem_reward дуудах", `select redeem_reward(gen_random_uuid())`, []);
});

console.log(`\n${pass} тэнцсэн, ${fail} унасан`);
process.exit(fail ? 1 : 0);
