-- 51 дүгээр сургууль · Суралцагчийн өдрийн дэглэм
-- Анхны schema: профайл, эрх, сурагч-багш-эцэг эхийн холбоо, даалгавар, бүртгэл.
-- Role-ийг хэрэглэгч өөрөө ОНООЖ ЧАДАХГҮЙ. Зөвхөн admin (SQL editor / service role) онооно.

create type public.app_role as enum ('student', 'teacher', 'guardian', 'admin');
create type public.task_status as enum ('done', 'partial', 'help');
create type public.task_category as enum ('study', 'home', 'health', 'rest', 'interest');

-- Улаанбаатарын цагаар өнөөдрийн огноо
create or replace function public.today_ub() returns date
language sql stable set search_path = public as $$
  select (now() at time zone 'Asia/Ulaanbaatar')::date
$$;

-- ---------------------------------------------------------------- tables

create table public.profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  role public.app_role,                       -- null = эрх олгогдоогүй
  full_name text not null default '',
  created_at timestamptz not null default now()
);

create table public.students (
  id uuid primary key default gen_random_uuid(),
  user_id uuid unique references public.profiles (id) on delete set null,
  full_name text not null check (char_length(full_name) between 1 and 80),
  class_name text,
  goal_pct int not null default 80 check (goal_pct between 10 and 100),
  screen_limit_min int not null default 90 check (screen_limit_min between 0 and 600),
  created_at timestamptz not null default now()
);

create table public.teacher_students (
  teacher_id uuid not null references public.profiles (id) on delete cascade,
  student_id uuid not null references public.students (id) on delete cascade,
  primary key (teacher_id, student_id)
);

create table public.guardian_students (
  guardian_id uuid not null references public.profiles (id) on delete cascade,
  student_id uuid not null references public.students (id) on delete cascade,
  primary key (guardian_id, student_id)
);

create table public.tasks (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.students (id) on delete cascade,
  category public.task_category not null,
  title text not null check (char_length(title) between 1 and 80),
  description text not null default '' check (char_length(description) <= 200),
  minutes int not null default 0 check (minutes between 0 and 180),
  slot text not null default 'after' check (slot in ('morning', 'school', 'after', 'evening')),
  is_mongol boolean not null default false,
  sort int not null default 0,
  active boolean not null default true,
  points int not null default 5 check (points between 0 and 100),   -- «хийсэн» үед өгөх оноо
  created_at timestamptz not null default now(),
  unique (id, student_id)
);

create table public.schedule_items (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.students (id) on delete cascade,
  start_time time,
  period text not null default '' check (char_length(period) <= 80),
  activity text not null check (char_length(activity) between 1 and 160),
  sort int not null default 0
);

-- Сурагчийн даалгаврын төлөв, өдрөөр
create table public.task_logs (
  student_id uuid not null,
  task_id uuid not null,
  log_date date not null,
  status public.task_status not null,
  points int not null default 0,              -- trigger тогтооно: done бол даалгаврын оноо, бусад үед 0
  updated_at timestamptz not null default now(),
  updated_by uuid references public.profiles (id) on delete set null,
  primary key (task_id, log_date),
  foreign key (task_id, student_id) references public.tasks (id, student_id) on delete cascade
);

-- Сурагчийн өдрийн төгсгөлийн богино тэмдэглэл
create table public.student_notes (
  student_id uuid not null references public.students (id) on delete cascade,
  log_date date not null,
  note text not null default '' check (char_length(note) <= 500),
  updated_at timestamptz not null default now(),
  updated_by uuid references public.profiles (id) on delete set null,
  primary key (student_id, log_date)
);

-- Эцэг эхийн бөглөх гэрийн хяналтын хуудас
create table public.home_logs (
  student_id uuid not null references public.students (id) on delete cascade,
  log_date date not null,
  screen_minutes int check (screen_minutes between 0 and 960),
  movement_minutes int check (movement_minutes between 0 and 600),
  offscreen text[] not null default '{}',
  chore text not null default '' check (char_length(chore) <= 160),
  hygiene_morning boolean not null default false,
  hygiene_evening boolean not null default false,
  hygiene_reminded boolean not null default false,
  mood text check (mood in ('great', 'ok', 'tired', 'upset')),
  sleep_note text not null default '' check (char_length(sleep_note) <= 500),
  updated_at timestamptz not null default now(),
  updated_by uuid references public.profiles (id) on delete set null,
  primary key (student_id, log_date)
);

-- Багшийн тэмдэглэл
create table public.teacher_notes (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.students (id) on delete cascade,
  author_id uuid not null default auth.uid() references public.profiles (id) on delete cascade,
  log_date date not null default public.today_ub(),
  body text not null check (char_length(body) between 1 and 1000),
  share_with_guardian boolean not null default true,
  created_at timestamptz not null default now()
);

-- Өдрийн жижиг зорилго (багш тохируулна)
create table public.day_goals (
  student_id uuid not null references public.students (id) on delete cascade,
  log_date date not null,
  goal text not null check (char_length(goal) between 1 and 140),
  updated_at timestamptz not null default now(),
  updated_by uuid references public.profiles (id) on delete set null,
  primary key (student_id, log_date)
);

create index on public.task_logs (student_id, log_date);
create index on public.tasks (student_id);
create index on public.schedule_items (student_id);
create index on public.teacher_notes (student_id, log_date);
create index on public.teacher_students (student_id);
create index on public.guardian_students (student_id);

-- ---------------------------------------------------------------- triggers

-- Шинэ auth хэрэглэгчид профайл үүсгэнэ. Role-ийг metadata-аас АВАХГҮЙ (хэрэглэгч өөрөө бичиж чадна).
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, full_name)
  values (new.id, coalesce(left(new.raw_user_meta_data ->> 'full_name', 80), ''))
  on conflict (id) do nothing;
  return new;
end $$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- updated_at / updated_by-г сервер талд тогтооно (клиентийн утгыг үл тооно)
create or replace function public.stamp_update() returns trigger
language plpgsql set search_path = public as $$
begin
  new.updated_at := now();
  new.updated_by := coalesce(auth.uid(), new.updated_by);
  return new;
end $$;

create trigger stamp before insert or update on public.task_logs for each row execute function public.stamp_update();
create trigger stamp before insert or update on public.student_notes for each row execute function public.stamp_update();
create trigger stamp before insert or update on public.home_logs for each row execute function public.stamp_update();
create trigger stamp before insert or update on public.day_goals for each row execute function public.stamp_update();

-- Багшийн тэмдэглэлийн зохиогчийг хуурамчаар бичихээс сэргийлнэ
create or replace function public.stamp_author() returns trigger
language plpgsql set search_path = public as $$
begin
  if auth.uid() is not null then new.author_id := auth.uid(); end if;
  return new;
end $$;
create trigger stamp_author before insert or update on public.teacher_notes for each row execute function public.stamp_author();

-- ---------------------------------------------------------------- access helpers
-- security definer: RLS-ийн дотор давталтгүй шалгахын тулд. Бүгд auth.uid()-д тулгуурлана.

create or replace function public.my_role() returns public.app_role
language sql stable security definer set search_path = public as $$
  select role from public.profiles where id = auth.uid()
$$;

create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles where id = auth.uid() and role = 'admin')
$$;

create or replace function public.is_student_self(sid uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.students s join public.profiles p on p.id = s.user_id
    where s.id = sid and s.user_id = auth.uid() and p.role = 'student')
$$;

create or replace function public.is_teacher_of(sid uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.teacher_students ts join public.profiles p on p.id = ts.teacher_id
    where ts.student_id = sid and ts.teacher_id = auth.uid() and p.role = 'teacher')
$$;

create or replace function public.is_guardian_of(sid uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.guardian_students gs join public.profiles p on p.id = gs.guardian_id
    where gs.student_id = sid and gs.guardian_id = auth.uid() and p.role = 'guardian')
$$;

create or replace function public.can_read_student(sid uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select public.is_student_self(sid) or public.is_teacher_of(sid)
      or public.is_guardian_of(sid) or public.is_admin()
$$;

-- Сурагч зөвхөн сүүлийн 7 хоногийн бүртгэлээ засна
create or replace function public.editable_day(d date) returns boolean
language sql stable set search_path = public as $$
  select d between public.today_ub() - 7 and public.today_ub()
$$;

-- ---------------------------------------------------------------- grants

revoke all on all tables in schema public from anon, authenticated;
revoke all on all functions in schema public from public, anon;

grant usage on schema public to authenticated;
grant select on all tables in schema public to authenticated;
grant insert, update, delete on public.task_logs, public.student_notes, public.home_logs,
  public.teacher_notes, public.day_goals, public.schedule_items to authenticated;
grant insert on public.tasks to authenticated;
grant update (category, title, description, minutes, slot, is_mongol, sort, active) on public.tasks to authenticated;
grant update (class_name, goal_pct, screen_limit_min) on public.students to authenticated;
-- profiles, students (insert/delete), холбоосын хүснэгтүүдэд хэрэглэгч бичих эрхгүй.

grant execute on function public.today_ub(), public.my_role(), public.is_admin(),
  public.is_student_self(uuid), public.is_teacher_of(uuid), public.is_guardian_of(uuid),
  public.can_read_student(uuid), public.editable_day(date) to authenticated;

-- ---------------------------------------------------------------- RLS

alter table public.profiles enable row level security;
alter table public.students enable row level security;
alter table public.teacher_students enable row level security;
alter table public.guardian_students enable row level security;
alter table public.tasks enable row level security;
alter table public.schedule_items enable row level security;
alter table public.task_logs enable row level security;
alter table public.student_notes enable row level security;
alter table public.home_logs enable row level security;
alter table public.teacher_notes enable row level security;
alter table public.day_goals enable row level security;

-- profiles: зөвхөн өөрийнхөө (admin бүгдийг)
create policy profiles_read on public.profiles for select to authenticated
  using (id = auth.uid() or public.is_admin());

-- students
create policy students_read on public.students for select to authenticated
  using (public.can_read_student(id));
create policy students_teacher_update on public.students for update to authenticated
  using (public.is_teacher_of(id)) with check (public.is_teacher_of(id));

-- холбоосууд: зөвхөн өөрт хамаарах мөр
create policy ts_read on public.teacher_students for select to authenticated
  using (teacher_id = auth.uid() or public.is_admin());
create policy gs_read on public.guardian_students for select to authenticated
  using (guardian_id = auth.uid() or public.is_admin());

-- tasks: бүгд унших, зөвхөн хариуцсан багш нэмэх/засах. Устгахгүй (active=false), түүх хадгалагдана.
create policy tasks_read on public.tasks for select to authenticated
  using (public.can_read_student(student_id));
create policy tasks_teacher_insert on public.tasks for insert to authenticated
  with check (public.is_teacher_of(student_id));
create policy tasks_teacher_update on public.tasks for update to authenticated
  using (public.is_teacher_of(student_id)) with check (public.is_teacher_of(student_id));

-- schedule
create policy sched_read on public.schedule_items for select to authenticated
  using (public.can_read_student(student_id));
create policy sched_teacher_insert on public.schedule_items for insert to authenticated
  with check (public.is_teacher_of(student_id));
create policy sched_teacher_update on public.schedule_items for update to authenticated
  using (public.is_teacher_of(student_id)) with check (public.is_teacher_of(student_id));
create policy sched_teacher_delete on public.schedule_items for delete to authenticated
  using (public.is_teacher_of(student_id));

-- task_logs: зөвхөн сурагч өөрөө, сүүлийн 7 хоногт
create policy logs_read on public.task_logs for select to authenticated
  using (public.can_read_student(student_id));
create policy logs_student_insert on public.task_logs for insert to authenticated
  with check (public.is_student_self(student_id) and public.editable_day(log_date));
create policy logs_student_update on public.task_logs for update to authenticated
  using (public.is_student_self(student_id) and public.editable_day(log_date))
  with check (public.is_student_self(student_id) and public.editable_day(log_date));
create policy logs_student_delete on public.task_logs for delete to authenticated
  using (public.is_student_self(student_id) and public.editable_day(log_date));

-- student_notes
create policy snotes_read on public.student_notes for select to authenticated
  using (public.can_read_student(student_id));
create policy snotes_student_insert on public.student_notes for insert to authenticated
  with check (public.is_student_self(student_id) and public.editable_day(log_date));
create policy snotes_student_update on public.student_notes for update to authenticated
  using (public.is_student_self(student_id) and public.editable_day(log_date))
  with check (public.is_student_self(student_id) and public.editable_day(log_date));

-- home_logs: эцэг эх бөглөнө, бусад нь уншина
create policy home_read on public.home_logs for select to authenticated
  using (public.can_read_student(student_id));
create policy home_guardian_insert on public.home_logs for insert to authenticated
  with check (public.is_guardian_of(student_id) and public.editable_day(log_date));
create policy home_guardian_update on public.home_logs for update to authenticated
  using (public.is_guardian_of(student_id) and public.editable_day(log_date))
  with check (public.is_guardian_of(student_id) and public.editable_day(log_date));

-- teacher_notes: багш бичнэ; эцэг эх зөвхөн хуваалцсаныг уншина; сурагч харахгүй
create policy tnotes_read on public.teacher_notes for select to authenticated
  using (public.is_teacher_of(student_id) or public.is_admin()
         or (share_with_guardian and public.is_guardian_of(student_id)));
create policy tnotes_teacher_insert on public.teacher_notes for insert to authenticated
  with check (public.is_teacher_of(student_id) and author_id = auth.uid());
create policy tnotes_author_update on public.teacher_notes for update to authenticated
  using (author_id = auth.uid() and public.is_teacher_of(student_id))
  with check (author_id = auth.uid() and public.is_teacher_of(student_id));
create policy tnotes_author_delete on public.teacher_notes for delete to authenticated
  using (author_id = auth.uid() and public.is_teacher_of(student_id));

-- day_goals: багш тохируулна
create policy goals_read on public.day_goals for select to authenticated
  using (public.can_read_student(student_id));
create policy goals_teacher_insert on public.day_goals for insert to authenticated
  with check (public.is_teacher_of(student_id));
create policy goals_teacher_update on public.day_goals for update to authenticated
  using (public.is_teacher_of(student_id)) with check (public.is_teacher_of(student_id));
create policy goals_teacher_delete on public.day_goals for delete to authenticated
  using (public.is_teacher_of(student_id));

-- ---------------------------------------------------------------- RPC

-- Нэвтрэх үед сонгосон төрөл бодит эрхтэй таарч буйг сервер талд шалгана.
create or replace function public.verify_login_role(requested public.app_role) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles where id = auth.uid() and role = requested)
$$;
grant execute on function public.verify_login_role(public.app_role) to authenticated;

-- Төлөвлөгөөний анхны даалгавар, хуваарийг ачаална (хоосон үед л).
create or replace function public.seed_student_plan(sid uuid) returns jsonb
language plpgsql security definer set search_path = public as $$
declare n_tasks int := 0; n_sched int := 0;
begin
  if auth.uid() is not null and not (public.is_teacher_of(sid) or public.is_admin()) then
    raise exception 'Энэ сурагчийн төлөвлөгөөг өөрчлөх эрхгүй' using errcode = '42501';
  end if;
  if not exists (select 1 from public.tasks where student_id = sid) then
    insert into public.tasks (student_id, category, title, description, minutes, slot, is_mongol, sort) values
      (sid,'study','Цүнх, хэрэгслээ шалгах','Сургууль явахын өмнө жагсаалтаараа шалга.',5,'morning',false,10),
      (sid,'study','Хичээлдээ оролцох','Багшийн зааврыг сонсоод идэвхтэй оролц.',0,'school',false,20),
      (sid,'study','Монгол хэлний унших-бичих ажил','10–15 минут. Хэцүү бол 5 минутаар хоёр хуваана.',15,'after',true,30),
      (sid,'study','Уншсанаа ойлгох','Уншсан зүйлээсээ 2–3 асуултад хариул.',5,'after',false,40),
      (sid,'home','Эд зүйлсээ байранд нь хураах','Харандаа, зураг, тоглоомоо хайрцагт нь хий.',5,'evening',false,10),
      (sid,'home','Маргаашийн цүнхээ бэлдэх','Ном, дэвтэр, харандаагаа цүнхэндээ хий.',5,'evening',false,20),
      (sid,'home','Гэр бүлдээ туслах','Аяга угаах, ширээ засах зэрэг нэг жижиг ажил.',10,'evening',false,30),
      (sid,'health','Нүүр, гараа угаах','Өглөө сэрээд.',3,'morning',false,10),
      (sid,'health','Шүдээ угаах','Өглөө ба орой.',3,'morning',false,20),
      (sid,'health','Өглөөний цайгаа уух','',15,'morning',false,30),
      (sid,'health','Хангалттай ус уух','Сургууль дээр ч, гэртээ ч.',0,'school',false,40),
      (sid,'health','Оройн ариун цэвэр','Гараа угааж, шүдээ угаана.',5,'evening',false,50),
      (sid,'health','Унтахын өмнө дэлгэцээ унтраах','Унтахаас 45–60 минутын өмнө.',0,'evening',false,60),
      (sid,'rest','Бөмбөгтэй дасгал эсвэл алхалт','15–20 минут хөдөлгөөн.',20,'after',false,10),
      (sid,'rest','Дэлгэцгүй бүтээл','Зураг зурах эсвэл шавраар бүтээл хийх.',25,'after',false,20),
      (sid,'rest','Дэлгэцийн цагаа хянах','Тохирсон цаг дуусахад өөрөө унтраа.',0,'after',false,30),
      (sid,'interest','Хөлбөмбөгийн сэдвээр өгүүлбэр бичих','«Хаалгач бөмбөг барив» гэх мэт 2 өгүүлбэр.',10,'after',false,10),
      (sid,'interest','Газрын зургаас нэр унших','Нэг газрын нэр уншаад чиглэлийг нь хэл.',10,'after',false,20);
    get diagnostics n_tasks = row_count;
    update public.tasks set points = 10 where student_id = sid and (is_mongol or title = 'Хичээлдээ оролцох');
  end if;
  if not exists (select 1 from public.rewards where student_id = sid) then
    insert into public.rewards (student_id, title, description, icon, cost, sort) values
      (sid,'Хаалгачийн бээлий','Гол шагнал. Эцэг эх/багштай тохиролцож авна.','glove',600,10),
      (sid,'Хөлбөмбөгийн бөмбөг','Эцэг эх/багштай тохиролцож авна.','ball',350,20),
      (sid,'Хөлбөмбөгийн оймс','Эцэг эх/багштай тохиролцож авна.','socks',200,30),
      (sid,'Дасгалын нэмэлт 15 минут','Хөлбөмбөгийн дасгалд нэмэлт цаг. Эцэг эх/багштай тохиролцоно.','timer',80,40),
      (sid,'Бүтээлч ажлаа өөрөө сонгох','Зураг, шавар эсвэл газрын зураг. Эцэг эх/багштай тохиролцоно.','palette',120,50);
  end if;
  if not exists (select 1 from public.schedule_items where student_id = sid) then
    insert into public.schedule_items (student_id, start_time, period, activity, sort) values
      (sid,'07:00','Өглөө сэрснээс сургууль явах хүртэл','Ариун цэвэр, өглөөний цай, хувцаслах, цүнх шалгах',10),
      (sid,'08:00','Сургуулийн цаг','Хичээл, завсарлага, ус уух, хөдөлгөөн',20),
      (sid,'13:30','Сургуулиас ирээд 20–30 минут','Амрах, тайвшрах, ус уух',30),
      (sid,'14:00','15–20 минут','Бөмбөгтэй дасгал, алхалт эсвэл хөдөлгөөнт тоглоом',40),
      (sid,'14:20','10–15 минут','Монгол хэлний унших-бичих богино ажил',50),
      (sid,'14:40','20–30 минут','Зураг зурах, шавар урлал, бүтээл хийх',60),
      (sid,'15:10','5–10 минут','Эд зүйлсээ хураах, маргаашийн цүнх бэлдэх',70),
      (sid,'19:00','Орой','Гэр бүлийн хоол, ярилцах, ариун цэвэр',80),
      (sid,'20:30','Унтахаас 45–60 минутын өмнө','Дэлгэцээ унтраах, тайван амрах, унтах бэлтгэл',90);
    get diagnostics n_sched = row_count;
  end if;
  return jsonb_build_object('tasks', n_tasks, 'schedule', n_sched);
end $$;
grant execute on function public.seed_student_plan(uuid) to authenticated;



-- ---------------------------------------------------------------- Шагнал, оноо
-- Оноо = «хийсэн» даалгаврын оноо − авсан шагналын оноо. Тоолуур хадгалахгүй, бүртгэлээс тооцно.
-- task_logs нь (даалгавар, өдөр)-өөр давтагдашгүй тул нэг даалгавраас давхар оноо авах боломжгүй.

create table public.rewards (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.students (id) on delete cascade,
  title text not null check (char_length(title) between 1 and 60),
  description text not null default '' check (char_length(description) <= 160),
  icon text not null default 'gift' check (icon in ('glove', 'ball', 'socks', 'timer', 'palette', 'gift', 'star')),
  cost int not null check (cost between 1 and 10000),
  active boolean not null default true,
  sort int not null default 0,
  created_at timestamptz not null default now()
);

create table public.redemptions (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.students (id) on delete cascade,
  reward_id uuid references public.rewards (id) on delete set null,
  title text not null,
  icon text not null default 'gift',
  cost int not null check (cost > 0),
  created_at timestamptz not null default now(),
  created_by uuid references public.profiles (id) on delete set null
);
create index on public.rewards (student_id);
create index on public.redemptions (student_id);

-- Даалгаврын оноог тэмдэглэх үед хадгална (дараа нь багш оноог өөрчилсөн ч түүх өөрчлөгдөхгүй)
create or replace function public.stamp_log_points() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  new.points := case when new.status = 'done'
    then coalesce((select points from public.tasks where id = new.task_id), 0) else 0 end;
  return new;
end $$;
create trigger stamp_points before insert or update on public.task_logs for each row execute function public.stamp_log_points();

create or replace function public.points_raw(sid uuid) returns int
language sql stable security definer set search_path = public as $$
  select (select coalesce(sum(points), 0) from public.task_logs where student_id = sid)
       - (select coalesce(sum(cost), 0) from public.redemptions where student_id = sid)
$$;

-- Шагналд зарцуулсан оноог даалгавраа буцааж «устгах» боломжгүй
create or replace function public.guard_balance() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if public.points_raw(coalesce(new.student_id, old.student_id)) < 0 then
    raise exception 'Энэ даалгаврын оноог шагналд зарцуулсан тул буцаах боломжгүй.' using errcode = 'P0001';
  end if;
  return null;
end $$;
create trigger guard_balance after update or delete on public.task_logs for each row execute function public.guard_balance();

create or replace function public.points_summary(sid uuid) returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare e int; sp int;
begin
  if not public.can_read_student(sid) then raise exception 'Эрх алга' using errcode = '42501'; end if;
  select coalesce(sum(points), 0) into e from public.task_logs where student_id = sid;
  select coalesce(sum(cost), 0) into sp from public.redemptions where student_id = sid;
  return jsonb_build_object('earned', e, 'spent', sp, 'balance', e - sp);
end $$;

-- Шагнал авах: зөвхөн сурагч өөрөө, оноо хүрэлцэх үед. Давхар дарахаас сэргийлж сурагчийн мөрийг түгжинэ.
create or replace function public.redeem_reward(rid uuid) returns public.redemptions
language plpgsql security definer set search_path = public as $$
declare r public.rewards; out_row public.redemptions;
begin
  select * into r from public.rewards where id = rid and active;
  if not found then raise exception 'Шагнал олдсонгүй.' using errcode = 'P0001'; end if;
  if not public.is_student_self(r.student_id) then raise exception 'Эрх алга' using errcode = '42501'; end if;
  perform 1 from public.students where id = r.student_id for update;
  if public.points_raw(r.student_id) < r.cost then
    raise exception 'Оноо хүрэлцэхгүй байна.' using errcode = 'P0001';
  end if;
  insert into public.redemptions (student_id, reward_id, title, icon, cost, created_by)
  values (r.student_id, r.id, r.title, r.icon, r.cost, auth.uid()) returning * into out_row;
  return out_row;
end $$;

alter table public.rewards enable row level security;
alter table public.redemptions enable row level security;
grant select on public.rewards, public.redemptions to authenticated;
grant insert on public.rewards to authenticated;
grant update (title, description, icon, cost, active, sort) on public.rewards to authenticated;
grant update (points) on public.tasks to authenticated;
-- redemptions-д шууд бичих эрхгүй: зөвхөн redeem_reward() ашиглана.

create policy rewards_read on public.rewards for select to authenticated using (public.can_read_student(student_id));
create policy rewards_teacher_insert on public.rewards for insert to authenticated with check (public.is_teacher_of(student_id));
create policy rewards_teacher_update on public.rewards for update to authenticated
  using (public.is_teacher_of(student_id)) with check (public.is_teacher_of(student_id));
create policy redemptions_read on public.redemptions for select to authenticated using (public.can_read_student(student_id));

-- Сүүлд үүссэн функцуудыг anon/public-ээс хаана (Postgres анхдагчаар PUBLIC-д execute өгдөг).
revoke execute on all functions in schema public from public, anon;
grant execute on function public.verify_login_role(public.app_role), public.seed_student_plan(uuid),
  public.points_summary(uuid), public.redeem_reward(uuid) to authenticated;
