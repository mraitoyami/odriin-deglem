/** Дизайны токенууд src/index.css дотор CSS хувьсагчаар төвлөрсөн. */
export default {
  darkMode: ["selector", '[data-theme="dark"]'],
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        bg: "rgb(var(--bg) / <alpha-value>)", surface: "rgb(var(--surface) / <alpha-value>)", sunken: "rgb(var(--sunken) / <alpha-value>)",
        ink: "rgb(var(--ink) / <alpha-value>)", muted: "rgb(var(--muted) / <alpha-value>)", line: "rgb(var(--line) / <alpha-value>)",
        accent: "rgb(var(--accent) / <alpha-value>)", "accent-soft": "rgb(var(--accent-soft) / <alpha-value>)", "accent-ink": "rgb(var(--accent-ink) / <alpha-value>)",
        ok: "rgb(var(--ok) / <alpha-value>)", "ok-soft": "rgb(var(--ok-soft) / <alpha-value>)", warn: "rgb(var(--warn) / <alpha-value>)", "warn-soft": "rgb(var(--warn-soft) / <alpha-value>)",
        bad: "rgb(var(--bad) / <alpha-value>)", "bad-soft": "rgb(var(--bad-soft) / <alpha-value>)",
        "on-accent": "rgb(var(--on-accent) / <alpha-value>)", scrim: "rgb(var(--scrim) / <alpha-value>)",
      },
      fontFamily: { sans: ["Rubik", "system-ui", "-apple-system", "Segoe UI", "sans-serif"] },
      borderRadius: { card: "16px", ctl: "12px" },
    },
  },
  plugins: [],
};
