#!/usr/bin/env node
// Сургуулийн админы скрипт: аккаунт үүсгэх, role оноох, сурагч-багш-эцэг эхийг холбох.
// service_role түлхүүр нь бүх RLS-ийг давдаг тул ЗӨВХӨН өөрийн компьютер дээр ажиллуулна.
// Frontend код, .env, git-д хэзээ ч бүү оруул.
//
//   export SUPABASE_URL=https://xxxx.supabase.co
//   export SUPABASE_SERVICE_ROLE_KEY=...        (Project Settings → API → service_role)
//   export USERNAME_DOMAIN=students.51.local    (заавал биш; .env-ийн VITE_USERNAME_DOMAIN-тай ижил)
//
//   node scripts/admin.mjs user <и-мэйл|нэр> <student|teacher|guardian> "<Овог нэр>" [нууц үг]
//   node scripts/admin.mjs student <сурагчийн нэвтрэх нэр> ["<Анги>"]
//   node scripts/admin.mjs link-teacher <багшийн нэвтрэх нэр> <сурагчийн нэвтрэх нэр>
//   node scripts/admin.mjs link-guardian <эцэг эхийн нэвтрэх нэр> <сурагчийн нэвтрэх нэр>
//   node scripts/admin.mjs list
import { createClient } from "@supabase/supabase-js";
import { randomBytes } from "node:crypto";

const { SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, USERNAME_DOMAIN = "" } = process.env;
if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
  console.error("SUPABASE_URL болон SUPABASE_SERVICE_ROLE_KEY орчны хувьсагчийг тохируулна уу.");
  process.exit(1);
}
const db = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, { auth: { persistSession: false } });
const ROLES = ["student", "teacher", "guardian", "admin"];

const toEmail = (login) => {
  if (login.includes("@")) return login.toLowerCase();
  if (!USERNAME_DOMAIN) throw new Error("Нэвтрэх нэр ашиглахын тулд USERNAME_DOMAIN тохируулна уу, эсвэл и-мэйл өгнө үү.");
  return `${login.toLowerCase()}@${USERNAME_DOMAIN}`;
};
async function findUser(login) {
  const email = toEmail(login);
  for (let page = 1; page < 50; page++) {
    const { data, error } = await db.auth.admin.listUsers({ page, perPage: 200 });
    if (error) throw error;
    const u = data.users.find((x) => x.email === email);
    if (u) return u;
    if (data.users.length < 200) break;
  }
  throw new Error(`Хэрэглэгч олдсонгүй: ${email}`);
}
async function profileOf(id) {
  const { data, error } = await db.from("profiles").select("id, role, full_name").eq("id", id).single();
  if (error) throw error;
  return data;
}
async function studentOf(login) {
  const u = await findUser(login);
  const { data, error } = await db.from("students").select("id, full_name").eq("user_id", u.id).maybeSingle();
  if (error) throw error;
  if (!data) throw new Error(`${login}-д сурагчийн бүртгэл алга. Эхлээд: node scripts/admin.mjs student ${login}`);
  return data;
}
async function requireRole(login, role) {
  const u = await findUser(login); const p = await profileOf(u.id);
  if (p.role !== role) throw new Error(`${login} нь «${role}» эрхгүй (одоо: ${p.role ?? "хоосон"}).`);
  return u;
}

const [cmd, ...a] = process.argv.slice(2);
try {
  if (cmd === "user") {
    const [login, role, name, pw] = a;
    if (!login || !ROLES.includes(role) || !name) throw new Error('Хэрэглээ: user <и-мэйл|нэр> <student|teacher|guardian> "<Овог нэр>" [нууц үг]');
    const password = pw || randomBytes(6).toString("base64url");
    const { data, error } = await db.auth.admin.createUser({ email: toEmail(login), password, email_confirm: true, user_metadata: { full_name: name } });
    if (error) throw error;
    // Role-ийг зөвхөн энд, service role-оор онооно.
    const { error: e2 } = await db.from("profiles").update({ role, full_name: name }).eq("id", data.user.id);
    if (e2) throw e2;
    console.log(`Үүслээ: ${data.user.email} · ${role}${pw ? "" : ` · түр нууц үг: ${password}`}`);
  } else if (cmd === "student") {
    const [login, cls] = a;
    const u = await requireRole(login, "student"); const p = await profileOf(u.id);
    const { data, error } = await db.from("students").insert({ user_id: u.id, full_name: p.full_name || login, class_name: cls || null }).select("id").single();
    if (error) throw error;
    const { data: seeded, error: e2 } = await db.rpc("seed_student_plan", { sid: data.id });
    if (e2) throw e2;
    console.log(`Сурагчийн бүртгэл: ${data.id} · анхны төлөвлөгөө: ${seeded.tasks} даалгавар, ${seeded.schedule} хуваарь`);
  } else if (cmd === "link-teacher" || cmd === "link-guardian") {
    const [who, studentLogin] = a;
    const role = cmd === "link-teacher" ? "teacher" : "guardian";
    const u = await requireRole(who, role); const s = await studentOf(studentLogin);
    const table = role === "teacher" ? "teacher_students" : "guardian_students";
    const { error } = await db.from(table).upsert({ [`${role}_id`]: u.id, student_id: s.id });
    if (error) throw error;
    console.log(`Холбогдлоо: ${who} → ${s.full_name}`);
  } else if (cmd === "list") {
    const { data: ps } = await db.from("profiles").select("id, role, full_name").order("role");
    const { data: ss } = await db.from("students").select("id, full_name, class_name, user_id");
    console.table(ps); console.table(ss);
  } else {
    console.log("Командууд: user, student, link-teacher, link-guardian, list. Файлын эхэнд тайлбар бий.");
  }
} catch (e) {
  console.error("Алдаа:", e.message ?? e);
  process.exit(1);
}
