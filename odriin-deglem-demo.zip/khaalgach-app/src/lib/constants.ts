import type { Category, LoginRole, Mood, Slot, Status } from "./types";

export const CATEGORIES: { id: Category; label: string; hint: string }[] = [
  { id: "study", label: "Хичээл, сургалт", hint: "Монгол хэлний унших-бичих ажил орно" },
  { id: "home", label: "Гэрийн ажил, бие даах чадвар", hint: "Эд зүйлсээ хураах, маргаашийн бэлтгэл" },
  { id: "health", label: "Эрүүл ахуй, хооллолт, нойр", hint: "Ариун цэвэр, хоол, ус, унтах дэглэм" },
  { id: "rest", label: "Амралт, хөдөлгөөн, дэлгэц", hint: "Хөдөлгөөн, дэлгэцгүй бүтээл, дэлгэцийн цаг" },
  { id: "interest", label: "Сонирхол", hint: "Хөлбөмбөг, газрын зураг зэрэг дуртай сэдэв" },
];
export const categoryLabel = (c: Category) => CATEGORIES.find((x) => x.id === c)?.label ?? c;

export const SLOTS: Record<Slot, string> = {
  morning: "Өглөө",
  school: "Сургууль дээр",
  after: "Хичээлийн дараа",
  evening: "Орой",
};

export const STATUS_LABEL: Record<Status, string> = {
  done: "Хийсэн",
  partial: "Хэсэгчлэн",
  help: "Дэмжлэг хэрэгтэй",
};

export const ROLE_META: Record<LoginRole, { label: string; desc: string; home: string }> = {
  student: { label: "Сурагч", desc: "Өдрийн хийх зүйлсээ тэмдэглэнэ", home: "/s" },
  teacher: { label: "Багш", desc: "Хариуцсан сурагчийн ахицыг хянана", home: "/t" },
  guardian: { label: "Эцэг эх / Асран хамгаалагч", desc: "Хүүхдийнхээ бүртгэлийг харна", home: "/p" },
};

export const MOODS: { id: Mood; label: string }[] = [
  { id: "great", label: "Баяртай" },
  { id: "ok", label: "Тайван" },
  { id: "tired", label: "Ядарсан" },
  { id: "upset", label: "Бухимдсан" },
];
export const moodLabel = (m: Mood | null | undefined) => MOODS.find((x) => x.id === m)?.label ?? "—";

export const OFFSCREEN: { id: string; label: string }[] = [
  { id: "draw", label: "Зураг" },
  { id: "clay", label: "Шавар" },
  { id: "ball", label: "Бөмбөг" },
  { id: "geo", label: "Газарзүй" },
  { id: "other", label: "Бусад" },
];
