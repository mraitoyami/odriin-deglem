/**
 * Өгөгдлийн горим.
 *  - "demo" (анхдагч): backend-гүй танилцуулгын хувилбар. Жишээ мэдээлэл зөвхөн энэ хөтчийн localStorage-д хадгалагдана.
 *    Demo нэвтрэлт нь БОДИТ authentication биш, ямар ч аюулгүй байдлын баталгаа өгөхгүй.
 *  - "supabase": Supabase Auth + Postgres + RLS (supabase/migrations/0001_init.sql, README-г үзнэ үү).
 */
export const DATA_MODE: "demo" | "supabase" = import.meta.env.VITE_DATA_MODE === "supabase" ? "supabase" : "demo";
export const DEMO = DATA_MODE === "demo";
