import { supabase, must } from "./supabase";
import type { PointsSummary, Redemption, Reward, DayGoal, HomeLog, ScheduleItem, Status, Student, StudentNote, Task, TaskLog, TeacherNote } from "./types";

const STUDENT_COLS = "id, user_id, full_name, class_name, goal_pct, screen_limit_min";
const TASK_COLS = "id, student_id, category, title, description, minutes, slot, is_mongol, points, sort, active";

// ---- students (RLS нь хэн юуг харахыг шийднэ)
export const myStudent = async () =>
  (await must(supabase.from("students").select(STUDENT_COLS).limit(1))) as Student[];
export const listStudents = async () =>
  (await must(supabase.from("students").select(STUDENT_COLS).order("full_name"))) as Student[];
export const getStudent = async (id: string) =>
  (await must(supabase.from("students").select(STUDENT_COLS).eq("id", id).maybeSingle())) as Student | null;
export const updateStudentSettings = (id: string, v: Pick<Student, "goal_pct" | "screen_limit_min">) =>
  must(supabase.from("students").update(v).eq("id", id).select("id")).then((r) => {
    if (!(r as unknown[]).length) throw new Error("Хадгалагдсангүй: эрх хүрэлцэхгүй байна.");
  });

// ---- tasks
export const listTasks = async (studentId: string, includeInactive = false) => {
  let q = supabase.from("tasks").select(TASK_COLS).eq("student_id", studentId).order("category").order("sort");
  if (!includeInactive) q = q.eq("active", true);
  return (await must(q)) as Task[];
};
export const createTask = (t: Omit<Task, "id" | "active">) => must(supabase.from("tasks").insert(t).select(TASK_COLS).single()) as Promise<Task>;
export const updateTask = (id: string, v: Partial<Omit<Task, "id" | "student_id">>) =>
  must(supabase.from("tasks").update(v).eq("id", id).select(TASK_COLS).single()) as Promise<Task>;
export const seedPlan = (studentId: string) => must(supabase.rpc("seed_student_plan", { sid: studentId }));

// ---- task logs
export const listLogs = async (studentIds: string[], from: string, to: string) =>
  (await must(
    supabase.from("task_logs").select("task_id, student_id, log_date, status")
      .in("student_id", studentIds).gte("log_date", from).lte("log_date", to),
  )) as TaskLog[];
export const setLog = (studentId: string, taskId: string, date: string, status: Status | null) =>
  status
    ? must(supabase.from("task_logs").upsert({ student_id: studentId, task_id: taskId, log_date: date, status }, { onConflict: "task_id,log_date" }).select("task_id"))
    : must(supabase.from("task_logs").delete().eq("task_id", taskId).eq("log_date", date).select("task_id"));

// ---- schedule
export const listSchedule = async (studentId: string) =>
  (await must(supabase.from("schedule_items").select("*").eq("student_id", studentId).order("sort").order("start_time"))) as ScheduleItem[];
export const saveSchedule = async (studentId: string, rows: ScheduleItem[], removed: string[]) => {
  if (removed.length) await must(supabase.from("schedule_items").delete().in("id", removed).select("id"));
  const existing = rows.filter((r) => !r.id.startsWith("new-"));
  const added = rows.filter((r) => r.id.startsWith("new-")).map(({ id: _id, ...r }) => ({ ...r, student_id: studentId }));
  if (existing.length) await must(supabase.from("schedule_items").upsert(existing).select("id"));
  if (added.length) await must(supabase.from("schedule_items").insert(added).select("id"));
};

// ---- notes, home logs, goals
export const getStudentNote = async (studentId: string, date: string) =>
  (await must(supabase.from("student_notes").select("*").eq("student_id", studentId).eq("log_date", date).maybeSingle())) as StudentNote | null;
export const listStudentNotes = async (studentId: string, from: string, to: string) =>
  (await must(supabase.from("student_notes").select("*").eq("student_id", studentId).gte("log_date", from).lte("log_date", to))) as StudentNote[];
export const saveStudentNote = (studentId: string, date: string, note: string) =>
  must(supabase.from("student_notes").upsert({ student_id: studentId, log_date: date, note }, { onConflict: "student_id,log_date" }).select("log_date"));

export const listHomeLogs = async (studentId: string, from: string, to: string) =>
  (await must(supabase.from("home_logs").select("*").eq("student_id", studentId).gte("log_date", from).lte("log_date", to))) as HomeLog[];
export const saveHomeLog = (log: HomeLog) => {
  const { updated_at: _u, ...row } = log;
  return must(supabase.from("home_logs").upsert(row, { onConflict: "student_id,log_date" }).select("log_date"));
};

export const listTeacherNotes = async (studentId: string, limit = 20) =>
  (await must(supabase.from("teacher_notes").select("*").eq("student_id", studentId).order("created_at", { ascending: false }).limit(limit))) as TeacherNote[];
export const addTeacherNote = (studentId: string, body: string, share: boolean) =>
  must(supabase.from("teacher_notes").insert({ student_id: studentId, body, share_with_guardian: share }).select("*").single()) as Promise<TeacherNote>;
export const deleteTeacherNote = (id: string) => must(supabase.from("teacher_notes").delete().eq("id", id).select("id"));

export const listGoals = async (studentId: string, from: string, to: string) =>
  (await must(supabase.from("day_goals").select("student_id, log_date, goal").eq("student_id", studentId).gte("log_date", from).lte("log_date", to))) as DayGoal[];
export const saveGoal = (studentId: string, date: string, goal: string) =>
  goal.trim()
    ? must(supabase.from("day_goals").upsert({ student_id: studentId, log_date: date, goal: goal.trim() }, { onConflict: "student_id,log_date" }).select("log_date"))
    : must(supabase.from("day_goals").delete().eq("student_id", studentId).eq("log_date", date).select("log_date"));


export const listActiveTasksFor = async (studentIds: string[]) =>
  studentIds.length
    ? ((await must(supabase.from("tasks").select(TASK_COLS).in("student_id", studentIds).eq("active", true))) as Task[])
    : [];

// ---- оноо, шагнал (оноог сервер task_logs + redemptions-оос тооцно, шагнал авах нь redeem_reward RPC)
const REWARD_COLS = "id, student_id, title, description, icon, cost, active, sort";
export const pointsSummary = (studentId: string) => must(supabase.rpc("points_summary", { sid: studentId })) as Promise<PointsSummary>;
export const listRewards = async (studentId: string, includeInactive = false) => {
  let q = supabase.from("rewards").select(REWARD_COLS).eq("student_id", studentId).order("cost");
  if (!includeInactive) q = q.eq("active", true);
  return (await must(q)) as Reward[];
};
export const createReward = (r: Omit<Reward, "id" | "active" | "sort">) =>
  must(supabase.from("rewards").insert({ ...r, sort: 100 }).select(REWARD_COLS).single()) as Promise<Reward>;
export const updateReward = (id: string, v: Partial<Pick<Reward, "title" | "description" | "icon" | "cost" | "active">>) =>
  must(supabase.from("rewards").update(v).eq("id", id).select(REWARD_COLS).single()) as Promise<Reward>;
export const listRedemptions = async (studentId: string) =>
  (await must(supabase.from("redemptions").select("id, student_id, reward_id, title, icon, cost, created_at").eq("student_id", studentId).order("created_at", { ascending: false }))) as Redemption[];
export const redeemReward = (rewardId: string) => must(supabase.rpc("redeem_reward", { rid: rewardId })) as Promise<Redemption>;
