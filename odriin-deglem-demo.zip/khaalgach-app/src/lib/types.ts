export type LoginRole = "student" | "teacher" | "guardian";
export type AppRole = LoginRole | "admin";
export type Category = "study" | "home" | "health" | "rest" | "interest";
export type Slot = "morning" | "school" | "after" | "evening";
export type Status = "done" | "partial" | "help";
export type Mood = "great" | "ok" | "tired" | "upset";

export interface Profile { id: string; role: AppRole | null; full_name: string }

export interface Student {
  id: string;
  user_id: string | null;
  full_name: string;
  class_name: string | null;
  goal_pct: number;
  screen_limit_min: number;
}

export interface Task {
  id: string;
  student_id: string;
  category: Category;
  title: string;
  description: string;
  minutes: number;
  slot: Slot;
  is_mongol: boolean;
  /** «Хийсэн» гэж тэмдэглэхэд өгөх оноо */
  points: number;
  sort: number;
  active: boolean;
}

export interface TaskLog { task_id: string; student_id: string; log_date: string; status: Status; /** сервер/demo тогтооно */ points?: number }

export interface ScheduleItem {
  id: string;
  student_id: string;
  start_time: string | null;
  period: string;
  activity: string;
  sort: number;
}

export interface StudentNote { student_id: string; log_date: string; note: string; updated_at: string }

export interface HomeLog {
  student_id: string;
  log_date: string;
  screen_minutes: number | null;
  movement_minutes: number | null;
  offscreen: string[];
  chore: string;
  hygiene_morning: boolean;
  hygiene_evening: boolean;
  hygiene_reminded: boolean;
  mood: Mood | null;
  sleep_note: string;
  updated_at?: string;
}

export interface TeacherNote {
  id: string;
  student_id: string;
  author_id: string;
  log_date: string;
  body: string;
  share_with_guardian: boolean;
  created_at: string;
}

export interface DayGoal { student_id: string; log_date: string; goal: string }

export type RewardIcon = "glove" | "ball" | "socks" | "timer" | "palette" | "gift" | "star";
export interface Reward {
  id: string;
  student_id: string;
  title: string;
  description: string;
  icon: RewardIcon;
  cost: number;
  active: boolean;
  sort: number;
}
export interface Redemption { id: string; student_id: string; reward_id: string | null; title: string; icon: RewardIcon; cost: number; created_at: string }
export interface PointsSummary { earned: number; spent: number; balance: number }
