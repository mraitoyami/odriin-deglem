// DEMO ГОРИМ: backend-гүй танилцуулгын "database".
// Бүх өгөгдөл зөвхөн энэ хөтчийн localStorage-д хадгалагдана. Нууц үгийг хамгаалдаггүй, жинхэнэ нэвтрэлт биш.
// Supabase руу шилжихэд энэ файл хэрэггүй болно (src/lib/mode.ts → VITE_DATA_MODE=supabase).
import { DEFAULT_REWARDS, DEFAULT_SCHEDULE, DEFAULT_TASKS } from "../plan";
import { addDays, todayUB } from "../dates";
import type { AppRole, Redemption, Reward, DayGoal, HomeLog, Mood, ScheduleItem, Status, Student, StudentNote, Task, TaskLog, TeacherNote } from "../types";

export interface DemoUser { id: string; username: string; password: string; role: AppRole; full_name: string }
export interface DemoDB {
  version: 2;
  seededOn: string;
  users: DemoUser[];
  students: Student[];
  teacher_students: { teacher_id: string; student_id: string }[];
  guardian_students: { guardian_id: string; student_id: string }[];
  tasks: Task[];
  schedule_items: ScheduleItem[];
  task_logs: TaskLog[];
  student_notes: StudentNote[];
  home_logs: HomeLog[];
  teacher_notes: TeacherNote[];
  day_goals: DayGoal[];
  rewards: Reward[];
  redemptions: Redemption[];
}

const KEY = "odriin-deglem.demo.v1";
const SESSION = "odriin-deglem.demo.session";

/** Танилцуулгад зориулсан жишээ хэрэглэгчид. Бодит хүний мэдээлэл биш. */
export const DEMO_ACCOUNTS = [
  { id: "u-student", username: "bat", password: "demo123", role: "student" as const, full_name: "Бат (жишээ сурагч)" },
  { id: "u-teacher", username: "bagsh", password: "demo123", role: "teacher" as const, full_name: "Сараа багш (жишээ)" },
  { id: "u-guardian", username: "eej", password: "demo123", role: "guardian" as const, full_name: "Дулмаа (жишээ эцэг эх)" },
  { id: "u-student2", username: "nomin", password: "demo123", role: "student" as const, full_name: "Номин (жишээ сурагч)" },
];

export const uid = (p: string) => `${p}-${Math.random().toString(36).slice(2, 10)}`;

// Тогтвортой "санамсаргүй" тоо: дахин эхлүүлэхэд ижил жишээ гарна.
function rng(seed: number) { return () => { seed = (seed * 1664525 + 1013904223) % 4294967296; return seed / 4294967296; }; }

function seed(): DemoDB {
  const today = todayUB();
  const students: Student[] = [
    { id: "s-bat", user_id: "u-student", full_name: "Бат", class_name: "3б анги (жишээ)", goal_pct: 80, screen_limit_min: 90 },
    { id: "s-nomin", user_id: "u-student2", full_name: "Номин", class_name: "3б анги (жишээ)", goal_pct: 70, screen_limit_min: 90 },
  ];
  const tasks: Task[] = [];
  const schedule: ScheduleItem[] = [];
  for (const s of students) {
    DEFAULT_TASKS.forEach((t, i) => tasks.push({ id: `${s.id}-t${i}`, student_id: s.id, is_mongol: false, sort: (i + 1) * 10, active: true, ...t }));
    DEFAULT_SCHEDULE.forEach((r, i) => schedule.push({ id: `${s.id}-r${i}`, student_id: s.id, sort: (i + 1) * 10, ...r }));
  }
  // Өмнөх 6 өдрийн жишээ бүртгэл (өнөөдөр хоосон, танилцуулгын үеэр тэмдэглэнэ)
  const r = rng(51);
  const logs: TaskLog[] = [], home: HomeLog[] = [], notes: StudentNote[] = [];
  const moods: Mood[] = ["great", "ok", "ok", "tired"];
  for (const s of students) {
    for (let d = 6; d >= 1; d--) {
      const date = addDays(today, -d);
      const level = 0.55 + r() * 0.4;
      for (const t of tasks.filter((x) => x.student_id === s.id)) {
        const x = r();
        const status: Status | null = x < level ? "done" : x < level + 0.08 ? "partial" : x < level + 0.12 ? "help" : null;
        if (status) logs.push({ task_id: t.id, student_id: s.id, log_date: date, status, points: status === "done" ? t.points : 0 });
      }
      const screen = 50 + Math.round(r() * 80);
      home.push({
        student_id: s.id, log_date: date, screen_minutes: screen, movement_minutes: 15 + Math.round(r() * 30),
        offscreen: [["draw", "ball", "clay", "geo"][Math.floor(r() * 4)]], chore: ["Аяга угаасан", "Ширээ зассан", "Хувцсаа эвхсэн"][Math.floor(r() * 3)],
        hygiene_morning: true, hygiene_evening: r() > 0.2, hygiene_reminded: r() > 0.6, mood: moods[Math.floor(r() * 4)],
        sleep_note: r() > 0.5 ? "21:30-д унтсан, өглөө сэргэг байсан." : "",
      });
      if (r() > 0.5) notes.push({ student_id: s.id, log_date: date, note: ["Бөмбөгтэй дасгал хамгийн хөгжилтэй байлаа.", "Монгол хэлний даалгавар жаахан хэцүү байсан.", "Газрын зургаас Дорнод аймгийг олсон."][Math.floor(r() * 3)], updated_at: new Date().toISOString() });
    }
  }
  const rewards: Reward[] = students.flatMap((s) => DEFAULT_REWARDS.map((r, i) => ({ ...r, id: `${s.id}-w${i}`, student_id: s.id, active: true, sort: (i + 1) * 10 })));
  const timer = rewards.find((r) => r.student_id === "s-bat" && r.icon === "timer")!;
  return {
    version: 2, seededOn: today,
    rewards,
    redemptions: [{ id: "rd1", student_id: "s-bat", reward_id: timer.id, title: timer.title, icon: timer.icon, cost: timer.cost, created_at: new Date(Date.now() - 3 * 864e5).toISOString() }],
    users: DEMO_ACCOUNTS.map((a) => ({ ...a })),
    students,
    teacher_students: students.map((s) => ({ teacher_id: "u-teacher", student_id: s.id })),
    guardian_students: [{ guardian_id: "u-guardian", student_id: "s-bat" }],
    tasks, schedule_items: schedule, task_logs: logs, student_notes: notes, home_logs: home,
    teacher_notes: [
      { id: "n1", student_id: "s-bat", author_id: "u-teacher", log_date: addDays(today, -2), body: "Монгол хэлний уншлага сайжирч байна. Гэртээ өдөрт 10 минут уншуулаарай.", share_with_guardian: true, created_at: new Date(Date.now() - 2 * 864e5).toISOString() },
      { id: "n2", student_id: "s-bat", author_id: "u-teacher", log_date: addDays(today, -1), body: "Дэмжлэг хүссэн даалгаврыг маргааш хамт хийнэ.", share_with_guardian: false, created_at: new Date(Date.now() - 864e5).toISOString() },
    ],
    day_goals: [{ student_id: "s-bat", log_date: today, goal: "Хоёр өгүүлбэр бие даан бичих" }],
  };
}

let cache: DemoDB | null = null;
let storageOk = true;

export function db(): DemoDB {
  if (cache) return cache;
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as DemoDB;
      if (parsed?.version === 2) return (cache = parsed);
      if ((parsed as { version: number })?.version === 1) { cache = upgradeFromV1(parsed); persist(); return cache; }
    }
  } catch { storageOk = false; }
  cache = seed(); persist();
  return cache;
}
/** Өмнөх demo хувилбарын өгөгдлийг хадгалж, оноо ба шагналыг нэмнэ */
function upgradeFromV1(d: DemoDB): DemoDB {
  for (const t of d.tasks) if (t.points == null) t.points = t.is_mongol || t.title === "Хичээлдээ оролцох" ? 10 : 5;
  for (const l of d.task_logs) l.points = l.status === "done" ? d.tasks.find((t) => t.id === l.task_id)?.points ?? 0 : 0;
  d.rewards = d.students.flatMap((s) => DEFAULT_REWARDS.map((r, i) => ({ ...r, id: `${s.id}-w${i}`, student_id: s.id, active: true, sort: (i + 1) * 10 })));
  d.redemptions = [];
  d.version = 2;
  return d;
}

export function persist() {
  try { localStorage.setItem(KEY, JSON.stringify(cache)); storageOk = true; }
  catch { storageOk = false; throw new Error("Хөтөч мэдээлэл хадгалахыг зөвшөөрөхгүй байна (нууц цонх эсэхийг шалгана уу)."); }
}
export const storageAvailable = () => storageOk;

/** Demo өгөгдлийг анхны жишээ рүү нь буцаана */
export function resetDemo() {
  cache = seed();
  try { localStorage.setItem(KEY, JSON.stringify(cache)); localStorage.removeItem(SESSION); } catch { /* хадгалах боломжгүй */ }
}

// ---- demo "session" (жинхэнэ token биш)
export function getSessionUser(): DemoUser | null {
  try { const id = localStorage.getItem(SESSION); return id ? db().users.find((u) => u.id === id) ?? null : null; }
  catch { return null; }
}
export function setSessionUser(id: string | null) {
  try { if (id) localStorage.setItem(SESSION, id); else localStorage.removeItem(SESSION); } catch { /* ignore */ }
}

/** Жижиг хоцрогдол: loading төлөв бодитоор харагдана */
export const delay = <T,>(v: T, ms = 120) => new Promise<T>((res) => setTimeout(() => res(v), ms));

/** Тестэд: хуудсыг refresh хийсэн мэт localStorage-оос дахин уншуулна */
export function reloadFromStorage() { cache = null; }
