import { createClient, type SupabaseClient } from "@supabase/supabase-js";
import { DEMO } from "./mode";

const url = import.meta.env.VITE_SUPABASE_URL as string | undefined;
const anonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined;

/** Тохиргоо дутуу бол апп ажиллаж байгаа мэт харагдуулахгүй, тохиргооны заавар харуулна. */
export const configMissing = !DEMO && (!url || !anonKey || url.includes("YOUR-PROJECT"));
export const usernameDomain = (import.meta.env.VITE_USERNAME_DOMAIN as string | undefined)?.trim() || "";

// anon түлхүүр нь нийтэд ил байх зориулалттай; хамгаалалт нь RLS дээр. service_role-г энд хэзээ ч бүү ашигла.
export const supabase: SupabaseClient = DEMO || configMissing
  ? (null as unknown as SupabaseClient)
  : createClient(url!, anonKey!, { auth: { persistSession: true, autoRefreshToken: true } });

/** Supabase-ийн алдааг хэрэглэгчид ойлгомжтой болгоно. */
export function friendlyError(e: unknown): string {
  const msg = (e as { message?: string })?.message ?? String(e ?? "");
  const code = (e as { code?: string })?.code;
  if (/Failed to fetch|NetworkError|network/i.test(msg)) return "Сервертэй холбогдож чадсангүй. Интернэтээ шалгаад дахин оролдоно уу.";
  if (code === "42501" || /row-level security|permission denied/i.test(msg)) return "Энэ үйлдлийг хийх эрх танд алга.";
  if (/JWT|expired/i.test(msg)) return "Нэвтрэлтийн хугацаа дууссан. Дахин нэвтэрнэ үү.";
  if (code === "23514") return "Оруулсан утга зөвшөөрөгдөх хязгаараас гарсан байна.";
  return msg || "Тодорхойгүй алдаа гарлаа.";
}

/** Supabase-ийн хариуг шалгаж, алдаа байвал throw хийнэ. */
export async function must<T>(p: PromiseLike<{ data: T | null; error: unknown }>): Promise<T> {
  const { data, error } = await p;
  if (error) throw error;
  return data as T;
}
