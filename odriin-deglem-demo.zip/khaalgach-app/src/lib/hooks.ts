import { useCallback, useEffect, useRef, useState } from "react";
import { friendlyError } from "./supabase";

/** Өгөгдөл ачаалах энгийн hook: loading / error / data / reload */
export function useLoad<T>(fn: () => Promise<T>, deps: unknown[]) {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const seq = useRef(0);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const run = useCallback(fn, deps);
  const reload = useCallback(async () => {
    const my = ++seq.current;
    setLoading(true); setError(null);
    try { const d = await run(); if (my === seq.current) setData(d); }
    catch (e) { if (my === seq.current) setError(friendlyError(e)); }
    finally { if (my === seq.current) setLoading(false); }
  }, [run]);
  useEffect(() => { reload(); }, [reload]);
  return { data, setData, error, loading, reload };
}

export type SaveState = { kind: "idle" } | { kind: "saving" } | { kind: "saved"; at: Date } | { kind: "error"; message: string };

/** Хадгалалтын төлөв. Алдаа гарвал хэзээ ч "хадгалсан" гэж харуулахгүй. */
export function useSave() {
  const [state, setState] = useState<SaveState>({ kind: "idle" });
  const last = useRef<(() => Promise<unknown>) | null>(null);
  const run = useCallback(async (fn: () => Promise<unknown>): Promise<boolean> => {
    last.current = fn;
    setState({ kind: "saving" });
    try { await fn(); setState({ kind: "saved", at: new Date() }); return true; }
    catch (e) { setState({ kind: "error", message: friendlyError(e) }); return false; }
  }, []);
  const retry = useCallback(() => (last.current ? run(last.current) : Promise.resolve(false)), [run]);
  return { state, run, retry, setState };
}
