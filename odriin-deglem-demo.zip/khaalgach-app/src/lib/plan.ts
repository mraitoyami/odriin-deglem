// 51 дүгээр сургуулийн төлөвлөгөөний анхны даалгавар, хуваарь.
// supabase/migrations/0001_init.sql доторх seed_student_plan()-тай ижил агуулгатай.
import type { Category, RewardIcon, Slot } from "./types";

/** Хийсэн даалгавар бүр 5 оноо; Монгол хэлний ажил, хичээлийн оролцоо 10 оноо */
export const DEFAULT_TASKS: { category: Category; title: string; description: string; minutes: number; slot: Slot; is_mongol?: boolean; points: number }[] = [
  { category: "study", title: "Цүнх, хэрэгслээ шалгах", description: "Сургууль явахын өмнө жагсаалтаараа шалга.", minutes: 5, slot: "morning", points: 5 },
  { category: "study", title: "Хичээлдээ оролцох", description: "Багшийн зааврыг сонсоод идэвхтэй оролц.", minutes: 0, slot: "school", points: 10 },
  { category: "study", title: "Монгол хэлний унших-бичих ажил", description: "10–15 минут. Хэцүү бол 5 минутаар хоёр хуваана.", minutes: 15, slot: "after", is_mongol: true, points: 10 },
  { category: "study", title: "Уншсанаа ойлгох", description: "Уншсан зүйлээсээ 2–3 асуултад хариул.", minutes: 5, slot: "after", points: 5 },
  { category: "home", title: "Эд зүйлсээ байранд нь хураах", description: "Харандаа, зураг, тоглоомоо хайрцагт нь хий.", minutes: 5, slot: "evening", points: 5 },
  { category: "home", title: "Маргаашийн цүнхээ бэлдэх", description: "Ном, дэвтэр, харандаагаа цүнхэндээ хий.", minutes: 5, slot: "evening", points: 5 },
  { category: "home", title: "Гэр бүлдээ туслах", description: "Аяга угаах, ширээ засах зэрэг нэг жижиг ажил.", minutes: 10, slot: "evening", points: 5 },
  { category: "health", title: "Нүүр, гараа угаах", description: "Өглөө сэрээд.", minutes: 3, slot: "morning", points: 5 },
  { category: "health", title: "Шүдээ угаах", description: "Өглөө ба орой.", minutes: 3, slot: "morning", points: 5 },
  { category: "health", title: "Өглөөний цайгаа уух", description: "", minutes: 15, slot: "morning", points: 5 },
  { category: "health", title: "Хангалттай ус уух", description: "Сургууль дээр ч, гэртээ ч.", minutes: 0, slot: "school", points: 5 },
  { category: "health", title: "Оройн ариун цэвэр", description: "Гараа угааж, шүдээ угаана.", minutes: 5, slot: "evening", points: 5 },
  { category: "health", title: "Унтахын өмнө дэлгэцээ унтраах", description: "Унтахаас 45–60 минутын өмнө.", minutes: 0, slot: "evening", points: 5 },
  { category: "rest", title: "Бөмбөгтэй дасгал эсвэл алхалт", description: "15–20 минут хөдөлгөөн.", minutes: 20, slot: "after", points: 5 },
  { category: "rest", title: "Дэлгэцгүй бүтээл", description: "Зураг зурах эсвэл шавраар бүтээл хийх.", minutes: 25, slot: "after", points: 5 },
  { category: "rest", title: "Дэлгэцийн цагаа хянах", description: "Тохирсон цаг дуусахад өөрөө унтраа.", minutes: 0, slot: "after", points: 5 },
  { category: "interest", title: "Хөлбөмбөгийн сэдвээр өгүүлбэр бичих", description: "«Хаалгач бөмбөг барив» гэх мэт 2 өгүүлбэр.", minutes: 10, slot: "after", points: 5 },
  { category: "interest", title: "Газрын зургаас нэр унших", description: "Нэг газрын нэр уншаад чиглэлийг нь хэл.", minutes: 10, slot: "after", points: 5 },
];

export const DEFAULT_SCHEDULE: { start_time: string; period: string; activity: string }[] = [
  { start_time: "07:00", period: "Өглөө сэрснээс сургууль явах хүртэл", activity: "Ариун цэвэр, өглөөний цай, хувцаслах, цүнх шалгах" },
  { start_time: "08:00", period: "Сургуулийн цаг", activity: "Хичээл, завсарлага, ус уух, хөдөлгөөн" },
  { start_time: "13:30", period: "Сургуулиас ирээд 20–30 минут", activity: "Амрах, тайвшрах, ус уух" },
  { start_time: "14:00", period: "15–20 минут", activity: "Бөмбөгтэй дасгал, алхалт эсвэл хөдөлгөөнт тоглоом" },
  { start_time: "14:20", period: "10–15 минут", activity: "Монгол хэлний унших-бичих богино ажил" },
  { start_time: "14:40", period: "20–30 минут", activity: "Зураг зурах, шавар урлал, бүтээл хийх" },
  { start_time: "15:10", period: "5–10 минут", activity: "Эд зүйлсээ хураах, маргаашийн цүнх бэлдэх" },
  { start_time: "19:00", period: "Орой", activity: "Гэр бүлийн хоол, ярилцах, ариун цэвэр" },
  { start_time: "20:30", period: "Унтахаас 45–60 минутын өмнө", activity: "Дэлгэцээ унтраах, тайван амрах, унтах бэлтгэл" },
];

/** Шагнал: бодит эд зүйлийг сайт өгөхгүй, эцэг эх/багштай тохиролцож авна */
export const DEFAULT_REWARDS: { title: string; description: string; icon: RewardIcon; cost: number }[] = [
  { title: "Хаалгачийн бээлий", description: "Гол шагнал. Эцэг эх/багштай тохиролцож авна.", icon: "glove", cost: 600 },
  { title: "Хөлбөмбөгийн бөмбөг", description: "Эцэг эх/багштай тохиролцож авна.", icon: "ball", cost: 350 },
  { title: "Хөлбөмбөгийн оймс", description: "Эцэг эх/багштай тохиролцож авна.", icon: "socks", cost: 200 },
  { title: "Дасгалын нэмэлт 15 минут", description: "Хөлбөмбөгийн дасгалд нэмэлт цаг. Эцэг эх/багштай тохиролцоно.", icon: "timer", cost: 80 },
  { title: "Бүтээлч ажлаа өөрөө сонгох", description: "Зураг, шавар эсвэл газрын зураг. Эцэг эх/багштай тохиролцоно.", icon: "palette", cost: 120 },
];
