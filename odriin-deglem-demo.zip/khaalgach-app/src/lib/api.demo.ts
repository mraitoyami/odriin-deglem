// DEMO ГОРИМ: api.supabase.ts-тэй яг ижил функцуудыг localStorage дээр хэрэгжүүлнэ.
// Эрхийн шалгалт нь RLS-ийн дүрмийг дуурайсан төдий — хөтөч дээр ажилладаг тул хамгаалалт биш.
import { db, delay, getSessionUser, persist, uid } from "./demo/store";
import { DEFAULT_REWARDS, DEFAULT_SCHEDULE, DEFAULT_TASKS } from "./plan";
import { isEditableDay, todayUB } from "./dates";
import type { PointsSummary, Redemption, Reward, DayGoal, HomeLog, ScheduleItem, Status, Student, StudentNote, Task, TeacherNote } from "./types";

const denied = () => Object.assign(new Error("Энэ үйлдлийг хийх эрх танд алга."), { code: "42501" });
const clone = <T,>(v: T): T => JSON.parse(JSON.stringify(v));
const me = () => { const u = getSessionUser(); if (!u) throw Object.assign(new Error("Нэвтрэлтийн хугацаа дууссан. Дахин нэвтэрнэ үү."), { code: "JWT" }); return u; };

function readableIds(): Set<string> {
  const u = me(), d = db();
  if (u.role === "student") return new Set(d.students.filter((s) => s.user_id === u.id).map((s) => s.id));
  if (u.role === "teacher") return new Set(d.teacher_students.filter((x) => x.teacher_id === u.id).map((x) => x.student_id));
  if (u.role === "guardian") return new Set(d.guardian_students.filter((x) => x.guardian_id === u.id).map((x) => x.student_id));
  return new Set(d.students.map((s) => s.id));
}
const canRead = (sid: string) => readableIds().has(sid);
const isSelf = (sid: string) => me().role === "student" && canRead(sid);
const isTeacherOf = (sid: string) => me().role === "teacher" && canRead(sid);
const isGuardianOf = (sid: string) => me().role === "guardian" && canRead(sid);
const need = (ok: boolean) => { if (!ok) throw denied(); };
const save = <T,>(v: T) => { persist(); return delay(v); };

// ---- students
export const myStudent = async () => delay(clone(db().students.filter((s) => canRead(s.id)).slice(0, 1)));
export const listStudents = async () => delay(clone(db().students.filter((s) => canRead(s.id)).sort((a, b) => a.full_name.localeCompare(b.full_name))));
export const getStudent = async (id: string) => delay(clone(db().students.find((s) => s.id === id && canRead(id)) ?? null));
export const updateStudentSettings = async (id: string, v: Pick<Student, "goal_pct" | "screen_limit_min">) => {
  need(isTeacherOf(id));
  Object.assign(db().students.find((s) => s.id === id)!, v);
  await save(null);
};

// ---- tasks
export const listTasks = async (studentId: string, includeInactive = false) => {
  if (!canRead(studentId)) return delay([] as Task[]);
  const order = ["study", "home", "health", "rest", "interest"];
  return delay(clone(db().tasks.filter((t) => t.student_id === studentId && (includeInactive || t.active))
    .sort((a, b) => order.indexOf(a.category) - order.indexOf(b.category) || a.sort - b.sort)) as Task[]);
};
export const listActiveTasksFor = async (studentIds: string[]) =>
  delay(clone(db().tasks.filter((t) => studentIds.includes(t.student_id) && canRead(t.student_id) && t.active)) as Task[]);
export const createTask = async (t: Omit<Task, "id" | "active">) => {
  need(isTeacherOf(t.student_id));
  const row: Task = { ...t, id: uid("t"), active: true };
  db().tasks.push(row); return save(clone(row));
};
export const updateTask = async (id: string, v: Partial<Omit<Task, "id" | "student_id">>) => {
  const t = db().tasks.find((x) => x.id === id); need(!!t && isTeacherOf(t!.student_id));
  Object.assign(t!, v); return save(clone(t!) as Task);
};
export const seedPlan = async (studentId: string) => {
  need(isTeacherOf(studentId));
  const d = db(); let tasks = 0, schedule = 0;
  if (!d.tasks.some((t) => t.student_id === studentId))
    DEFAULT_TASKS.forEach((t, i) => { d.tasks.push({ id: uid("t"), student_id: studentId, is_mongol: false, sort: (i + 1) * 10, active: true, ...t }); tasks++; });
  if (!d.schedule_items.some((r) => r.student_id === studentId))
    DEFAULT_SCHEDULE.forEach((r, i) => { d.schedule_items.push({ id: uid("r"), student_id: studentId, sort: (i + 1) * 10, ...r }); schedule++; });
  if (!d.rewards.some((r) => r.student_id === studentId))
    DEFAULT_REWARDS.forEach((r, i) => d.rewards.push({ ...r, id: uid("w"), student_id: studentId, active: true, sort: (i + 1) * 10 }));
  return save({ tasks, schedule });
};

// ---- task logs (зөвхөн сурагч өөрөө, сүүлийн 7 хоногт)
export const listLogs = async (studentIds: string[], from: string, to: string) =>
  delay(clone(db().task_logs.filter((l) => studentIds.includes(l.student_id) && canRead(l.student_id) && l.log_date >= from && l.log_date <= to)));
export const setLog = async (studentId: string, taskId: string, date: string, status: Status | null) => {
  need(isSelf(studentId) && isEditableDay(date) && db().tasks.some((t) => t.id === taskId && t.student_id === studentId));
  const d = db();
  const before = d.task_logs;
  // (даалгавар, өдөр) бүрт ганц мөр → нэг даалгавраас давхар оноо гарахгүй. Оноо зөвхөн «хийсэн» үед.
  const task = d.tasks.find((t) => t.id === taskId)!;
  d.task_logs = d.task_logs.filter((l) => !(l.task_id === taskId && l.log_date === date));
  if (status) d.task_logs.push({ task_id: taskId, student_id: studentId, log_date: date, status, points: status === "done" ? task.points : 0 });
  if (summary(studentId).balance < 0) {
    d.task_logs = before;
    throw new Error("Энэ даалгаврын оноог шагналд зарцуулсан тул буцаах боломжгүй.");
  }
  return save([{ task_id: taskId }]);
};

// ---- schedule
export const listSchedule = async (studentId: string) =>
  delay(clone(db().schedule_items.filter((r) => r.student_id === studentId && canRead(studentId)).sort((a, b) => a.sort - b.sort)));
export const saveSchedule = async (studentId: string, rows: ScheduleItem[], removed: string[]) => {
  need(isTeacherOf(studentId));
  const d = db();
  const keep = d.schedule_items.filter((r) => r.student_id !== studentId || !removed.includes(r.id));
  const others = keep.filter((r) => r.student_id !== studentId);
  const mine = rows.map((r) => ({ ...r, student_id: studentId, id: r.id.startsWith("new-") ? uid("r") : r.id }));
  d.schedule_items = [...others, ...mine];
  await save(null);
};

// ---- notes, home logs, goals
export const getStudentNote = async (studentId: string, date: string) =>
  delay(clone(db().student_notes.find((n) => n.student_id === studentId && n.log_date === date && canRead(studentId)) ?? null));
export const listStudentNotes = async (studentId: string, from: string, to: string) =>
  delay(clone(db().student_notes.filter((n) => n.student_id === studentId && canRead(studentId) && n.log_date >= from && n.log_date <= to)));
export const saveStudentNote = async (studentId: string, date: string, note: string) => {
  need(isSelf(studentId) && isEditableDay(date));
  const d = db();
  d.student_notes = d.student_notes.filter((n) => !(n.student_id === studentId && n.log_date === date));
  d.student_notes.push({ student_id: studentId, log_date: date, note, updated_at: new Date().toISOString() } as StudentNote);
  return save([{ log_date: date }]);
};

export const listHomeLogs = async (studentId: string, from: string, to: string) =>
  delay(clone(db().home_logs.filter((h) => h.student_id === studentId && canRead(studentId) && h.log_date >= from && h.log_date <= to)));
export const saveHomeLog = async (log: HomeLog) => {
  need(isGuardianOf(log.student_id) && isEditableDay(log.log_date));
  const d = db();
  d.home_logs = d.home_logs.filter((h) => !(h.student_id === log.student_id && h.log_date === log.log_date));
  d.home_logs.push({ ...log, updated_at: new Date().toISOString() });
  return save([{ log_date: log.log_date }]);
};

export const listTeacherNotes = async (studentId: string, limit = 20) => {
  const u = me();
  const rows = db().teacher_notes.filter((n) => n.student_id === studentId &&
    (isTeacherOf(studentId) || (u.role === "guardian" && n.share_with_guardian && isGuardianOf(studentId))));
  return delay(clone(rows.sort((a, b) => b.created_at.localeCompare(a.created_at)).slice(0, limit)));
};
export const addTeacherNote = async (studentId: string, body: string, share: boolean) => {
  need(isTeacherOf(studentId));
  const n: TeacherNote = { id: uid("n"), student_id: studentId, author_id: me().id, log_date: todayUB(), body, share_with_guardian: share, created_at: new Date().toISOString() };
  db().teacher_notes.push(n); return save(clone(n));
};
export const deleteTeacherNote = async (id: string) => {
  const d = db(), n = d.teacher_notes.find((x) => x.id === id);
  need(!!n && n!.author_id === me().id);
  d.teacher_notes = d.teacher_notes.filter((x) => x.id !== id);
  return save([{ id }]);
};

export const listGoals = async (studentId: string, from: string, to: string) =>
  delay(clone(db().day_goals.filter((g) => g.student_id === studentId && canRead(studentId) && g.log_date >= from && g.log_date <= to)));
export const saveGoal = async (studentId: string, date: string, goal: string) => {
  need(isTeacherOf(studentId));
  const d = db();
  d.day_goals = d.day_goals.filter((g) => !(g.student_id === studentId && g.log_date === date));
  if (goal.trim()) d.day_goals.push({ student_id: studentId, log_date: date, goal: goal.trim() } as DayGoal);
  return save([{ log_date: date }]);
};



// ---- оноо, шагнал
function summary(studentId: string): PointsSummary {
  const d = db();
  const earned = d.task_logs.filter((l) => l.student_id === studentId).reduce((a, l) => a + (l.points ?? 0), 0);
  const spent = d.redemptions.filter((r) => r.student_id === studentId).reduce((a, r) => a + r.cost, 0);
  return { earned, spent, balance: earned - spent };
}
export const pointsSummary = async (studentId: string) => { need(canRead(studentId)); return delay(summary(studentId)); };
export const listRewards = async (studentId: string, includeInactive = false) =>
  delay(clone(db().rewards.filter((r) => r.student_id === studentId && canRead(studentId) && (includeInactive || r.active)).sort((a, b) => a.cost - b.cost)));
export const createReward = async (r: Omit<Reward, "id" | "active" | "sort">) => {
  need(isTeacherOf(r.student_id));
  const row: Reward = { ...r, id: uid("w"), active: true, sort: 100 };
  db().rewards.push(row); return save(clone(row));
};
export const updateReward = async (id: string, v: Partial<Pick<Reward, "title" | "description" | "icon" | "cost" | "active">>) => {
  const r = db().rewards.find((x) => x.id === id); need(!!r && isTeacherOf(r!.student_id));
  Object.assign(r!, v); return save(clone(r!));
};
export const listRedemptions = async (studentId: string) =>
  delay(clone(db().redemptions.filter((r) => r.student_id === studentId && canRead(studentId)).sort((a, b) => b.created_at.localeCompare(a.created_at))));
export const redeemReward = async (rewardId: string) => {
  const d = db(), r = d.rewards.find((x) => x.id === rewardId && x.active);
  if (!r) throw new Error("Шагнал олдсонгүй.");
  need(isSelf(r.student_id));
  if (summary(r.student_id).balance < r.cost) throw new Error("Оноо хүрэлцэхгүй байна.");
  const row: Redemption = { id: uid("rd"), student_id: r.student_id, reward_id: r.id, title: r.title, icon: r.icon, cost: r.cost, created_at: new Date().toISOString() };
  d.redemptions.push(row); return save(clone(row));
};
