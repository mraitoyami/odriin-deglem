// Өгөгдлийн давхарга: хуудсууд зөвхөн энэ файлыг импортолно.
// VITE_DATA_MODE=supabase бол Supabase, бусад үед demo (localStorage) хувилбар ажиллана.
// `typeof supa` төрөл нь хоёр хувилбарын функцууд ижил байхыг TypeScript-ээр баталгаажуулна.
import * as supa from "./api.supabase";
import * as demo from "./api.demo";
import { DEMO } from "./mode";

const impl: typeof supa = DEMO ? demo : supa;

export const {
  myStudent, listStudents, getStudent, updateStudentSettings,
  listTasks, listActiveTasksFor, createTask, updateTask, seedPlan,
  listLogs, setLog, listSchedule, saveSchedule,
  getStudentNote, listStudentNotes, saveStudentNote,
  listHomeLogs, saveHomeLog,
  listTeacherNotes, addTeacherNote, deleteTeacherNote,
  listGoals, saveGoal,
  pointsSummary, listRewards, createReward, updateReward, listRedemptions, redeemReward,
} = impl;
