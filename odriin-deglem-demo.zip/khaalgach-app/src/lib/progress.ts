import type { Category, Task, TaskLog } from "./types";

/** Хийсэн = 1, хэсэгчлэн = 0.5, дэмжлэг хэрэгтэй = 0 */
export function dayProgress(tasks: Task[], logs: TaskLog[], date: string) {
  const byTask = new Map(logs.filter((l) => l.log_date === date).map((l) => [l.task_id, l.status]));
  let score = 0, done = 0, help = 0;
  const byCat: Partial<Record<Category, { score: number; total: number }>> = {};
  for (const t of tasks) {
    const s = byTask.get(t.id);
    const v = s === "done" ? 1 : s === "partial" ? 0.5 : 0;
    score += v; if (s === "done") done++; if (s === "help") help++;
    const c = (byCat[t.category] ??= { score: 0, total: 0 });
    c.score += v; c.total++;
  }
  const total = tasks.length;
  return { total, done, help, score, pct: total ? Math.round((score / total) * 100) : 0, byTask, byCat };
}
