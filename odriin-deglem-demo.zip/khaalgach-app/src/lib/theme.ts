// Өдөр / шөнийн theme. Сонголтыг localStorage-д хадгална, анхдагч нь light.
import { useSyncExternalStore } from "react";

export type Theme = "light" | "dark";
const KEY = "odriin-deglem.theme";
const listeners = new Set<() => void>();

function read(): Theme {
  try { return localStorage.getItem(KEY) === "dark" ? "dark" : "light"; } catch { return "light"; }
}
let current: Theme = read();

export function applyTheme(t: Theme) {
  document.documentElement.setAttribute("data-theme", t);
  document.querySelector('meta[name="theme-color"]')?.setAttribute("content", t === "dark" ? "#16171a" : "#fafaf7");
}
export function setTheme(t: Theme) {
  current = t; applyTheme(t);
  try { localStorage.setItem(KEY, t); } catch { /* хадгалах боломжгүй: энэ удаад л үйлчилнэ */ }
  listeners.forEach((l) => l());
}
export function useTheme(): [Theme, () => void] {
  const t = useSyncExternalStore((cb) => { listeners.add(cb); return () => listeners.delete(cb); }, () => current);
  return [t, () => setTheme(t === "dark" ? "light" : "dark")];
}
export const initTheme = () => applyTheme(current);
