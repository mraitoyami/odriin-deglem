// Бүх огноо Улаанбаатарын цагаар (сервер талын today_ub()-тэй таарна).
const TZ = "Asia/Ulaanbaatar";
const WD = ["Ням", "Даваа", "Мягмар", "Лхагва", "Пүрэв", "Баасан", "Бямба"];
const WDS = ["Ня", "Да", "Мя", "Лх", "Пү", "Ба", "Бя"];

export function todayUB(): string {
  return new Intl.DateTimeFormat("en-CA", { timeZone: TZ, year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date());
}
export function nowMinutesUB(): number {
  const p = new Intl.DateTimeFormat("en-GB", { timeZone: TZ, hour: "2-digit", minute: "2-digit", hour12: false }).format(new Date());
  const [h, m] = p.split(":").map(Number);
  return h * 60 + m;
}
const parse = (d: string) => { const [y, m, dd] = d.split("-").map(Number); return new Date(Date.UTC(y, m - 1, dd)); };
export function addDays(d: string, n: number): string {
  const x = parse(d); x.setUTCDate(x.getUTCDate() + n); return x.toISOString().slice(0, 10);
}
export function formatLong(d: string): string {
  const x = parse(d); return `${x.getUTCMonth() + 1}-р сарын ${x.getUTCDate()}, ${WD[x.getUTCDay()]}`;
}
export function formatShort(d: string): string {
  const x = parse(d); return `${x.getUTCMonth() + 1}/${x.getUTCDate()} ${WDS[x.getUTCDay()]}`;
}
export function lastDays(n: number, end = todayUB()): string[] {
  return Array.from({ length: n }, (_, i) => addDays(end, -(n - 1 - i)));
}
/** Сурагч сүүлийн 7 хоногийн бүртгэлээ засна (RLS-тэй ижил дүрэм) */
export function isEditableDay(d: string): boolean {
  const t = todayUB(); return d <= t && d >= addDays(t, -7);
}
export function greeting(): string {
  const m = nowMinutesUB(); return m < 11 * 60 ? "Өглөөний мэнд" : m < 18 * 60 ? "Өдрийн мэнд" : "Оройн мэнд";
}
export function fmtMinutes(m: number | null | undefined): string {
  if (m == null) return "—";
  const h = Math.floor(m / 60), r = m % 60;
  return h ? `${h} ц ${r} мин` : `${r} мин`;
}
