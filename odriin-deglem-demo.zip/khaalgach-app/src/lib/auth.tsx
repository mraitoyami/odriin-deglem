import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { supabase, usernameDomain, friendlyError } from "./supabase";
import { DEMO } from "./mode";
import { db, getSessionUser, resetDemo, setSessionUser } from "./demo/store";
import type { LoginRole, Profile } from "./types";
import { ROLE_META } from "./constants";

type SignedInProfile = Profile & { role: LoginRole };
type AuthState =
  | { status: "loading" }
  | { status: "signedOut"; notice?: string }
  | { status: "signedIn"; profile: SignedInProfile };

interface AuthCtx {
  state: AuthState;
  signIn: (role: LoginRole, identifier: string, password: string) => Promise<string | null>;
  signOut: () => Promise<void>;
  /** Зөвхөн demo горимд: жишээ мэдээллийг анхны байдалд нь буцаана */
  resetDemoData?: () => void;
}
const Ctx = createContext<AuthCtx | null>(null);
const isLoginRole = (r: unknown): r is LoginRole => r === "student" || r === "teacher" || r === "guardian";
const mismatch = (role: LoginRole) => `Энэ аккаунт «${ROLE_META[role].label}» эрхгүй байна. Зөв төрлөө сонгоод дахин оролдоно уу.`;

// ------------------------------------------------------------------ DEMO нэвтрэлт
// Жинхэнэ authentication БИШ: нууц үг хөтөч дээр шалгагдана, ямар ч хамгаалалт өгөхгүй.
// Зорилго нь role сонгох → нэвтрэх → dashboard гэсэн урсгалыг танилцуулах.
function useDemoAuth(): AuthCtx {
  const [state, setState] = useState<AuthState>({ status: "loading" });
  useEffect(() => {
    const u = getSessionUser();
    setState(u && isLoginRole(u.role) ? { status: "signedIn", profile: { id: u.id, role: u.role, full_name: u.full_name } } : { status: "signedOut" });
  }, []);
  const signIn = useCallback(async (role: LoginRole, identifier: string, password: string) => {
    const id = identifier.trim().toLowerCase();
    if (!id || !password) return "Нэвтрэх нэр болон нууц үгээ оруулна уу.";
    await new Promise((r) => setTimeout(r, 250));
    const u = db().users.find((x) => x.username === id);
    if (!u || u.password !== password) return "Нэвтрэх нэр эсвэл нууц үг буруу байна.";
    if (u.role !== role || !isLoginRole(u.role)) return mismatch(role);
    setSessionUser(u.id);
    setState({ status: "signedIn", profile: { id: u.id, role: u.role, full_name: u.full_name } });
    return null;
  }, []);
  const signOut = useCallback(async () => { setSessionUser(null); setState({ status: "signedOut" }); }, []);
  const resetDemoData = useCallback(() => { resetDemo(); setState({ status: "signedOut", notice: undefined }); }, []);
  return useMemo(() => ({ state, signIn, signOut, resetDemoData }), [state, signIn, signOut, resetDemoData]);
}

// ------------------------------------------------------------------ Supabase нэвтрэлт
function useSupabaseAuth(): AuthCtx {
  const [state, setState] = useState<AuthState>({ status: "loading" });

  // Эрхийг үргэлж database-ээс уншина (браузерт хадгалсан role-д найдахгүй).
  const resolve = useCallback(async (hasSession: boolean, notice?: string) => {
    if (!hasSession) { setState({ status: "signedOut", notice }); return; }
    try {
      const { data: p, error } = await supabase.from("profiles").select("id, role, full_name").maybeSingle();
      if (error) throw error;
      if (!p || !isLoginRole(p.role)) {
        await supabase.auth.signOut();
        setState({ status: "signedOut", notice: "Энэ аккаунтад эрх олгогдоогүй байна. Сургуулийн админд хандана уу." });
        return;
      }
      setState({ status: "signedIn", profile: p as SignedInProfile });
    } catch (e) { setState({ status: "signedOut", notice: friendlyError(e) }); }
  }, []);

  useEffect(() => {
    let alive = true;
    supabase.auth.getSession().then(({ data }) => { if (alive) resolve(!!data.session); });
    const { data: sub } = supabase.auth.onAuthStateChange((event) => {
      if (event === "SIGNED_OUT") setState((s) => (s.status === "signedOut" ? s : { status: "signedOut" }));
    });
    return () => { alive = false; sub.subscription.unsubscribe(); };
  }, [resolve]);

  const signIn = useCallback(async (role: LoginRole, identifier: string, password: string) => {
    const id = identifier.trim();
    if (!id || !password) return "Нэвтрэх нэр болон нууц үгээ оруулна уу.";
    let email = id;
    if (!id.includes("@")) {
      if (!usernameDomain) return "И-мэйл хаягаа бүтнээр нь оруулна уу.";
      email = `${id.toLowerCase()}@${usernameDomain}`;
    }
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) {
      if (/invalid login credentials/i.test(error.message)) return "Нэвтрэх нэр эсвэл нууц үг буруу байна.";
      if (/email not confirmed/i.test(error.message)) return "И-мэйл баталгаажаагүй байна.";
      return friendlyError(error);
    }
    // Сонгосон төрөл аккаунтын бодит эрхтэй таарч буйг сервер талд шалгана.
    const { data: ok, error: rpcErr } = await supabase.rpc("verify_login_role", { requested: role });
    if (rpcErr || ok !== true) { await supabase.auth.signOut(); return rpcErr ? friendlyError(rpcErr) : mismatch(role); }
    await resolve(true);
    return null;
  }, [resolve]);

  const signOut = useCallback(async () => { await supabase.auth.signOut(); setState({ status: "signedOut" }); }, []);
  return useMemo(() => ({ state, signIn, signOut }), [state, signIn, signOut]);
}

// Горим build хийх үед тогтдог тул hook-ийн дараалал өөрчлөгдөхгүй.
const useBackendAuth = DEMO ? useDemoAuth : useSupabaseAuth;

export function AuthProvider({ children }: { children: ReactNode }) {
  const value = useBackendAuth();
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useAuth() {
  const c = useContext(Ctx);
  if (!c) throw new Error("AuthProvider алга");
  return c;
}
