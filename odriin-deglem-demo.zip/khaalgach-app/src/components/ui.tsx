import { useId, useState, type ButtonHTMLAttributes, type InputHTMLAttributes, type ReactNode, type TextareaHTMLAttributes, type SelectHTMLAttributes } from "react";
import { ChevronDown, CircleAlert, CircleCheck, LoaderCircle } from "lucide-react";
import type { SaveState } from "../lib/hooks";

const cx = (...c: (string | false | null | undefined)[]) => c.filter(Boolean).join(" ");

type BtnVariant = "primary" | "secondary" | "ghost" | "danger";
export function Button({ variant = "primary", size = "md", loading, className, children, disabled, ...rest }:
  ButtonHTMLAttributes<HTMLButtonElement> & { variant?: BtnVariant; size?: "sm" | "md"; loading?: boolean }) {
  const v = {
    primary: "bg-ink text-bg hover:bg-ink/90",
    secondary: "bg-surface text-ink ring-1 ring-inset ring-line hover:ring-muted/50",
    ghost: "text-muted hover:text-ink hover:bg-sunken",
    danger: "bg-surface text-bad ring-1 ring-inset ring-line hover:bg-bad-soft",
  }[variant];
  const s = size === "sm" ? "min-h-10 px-3 text-[15px]" : "min-h-12 px-5 text-base";
  return (
    <button
      className={cx("inline-flex items-center justify-center gap-2 rounded-ctl font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed", v, s, className)}
      disabled={disabled || loading} {...rest}>
      {loading && <LoaderCircle className="h-4 w-4 animate-spin" aria-hidden />}
      {children}
    </button>
  );
}

export function Card({ className, children, as: As = "section" }: { className?: string; children: ReactNode; as?: "section" | "div" | "article" }) {
  return <As className={cx("rounded-card bg-surface ring-1 ring-line", className)}>{children}</As>;
}
export function CardHeader({ title, hint, action }: { title: ReactNode; hint?: ReactNode; action?: ReactNode }) {
  return (
    <div className="flex flex-wrap items-start justify-between gap-3 px-5 pt-5">
      <div className="min-w-0"><h2 className="text-[17px] font-semibold">{title}</h2>{hint && <p className="mt-0.5 text-sm text-muted">{hint}</p>}</div>
      {action}
    </div>
  );
}

export function Field({ label, hint, error, children, htmlFor }: { label: ReactNode; hint?: ReactNode; error?: string | null; children: ReactNode; htmlFor?: string }) {
  return (
    <div className="grid min-w-0 gap-1.5">
      <label htmlFor={htmlFor} className="text-[15px] font-medium">{label}</label>
      {children}
      {hint && !error && <p className="text-sm text-muted">{hint}</p>}
      {error && <p className="text-sm font-medium text-bad" role="alert">{error}</p>}
    </div>
  );
}
const inputCls = "w-full min-h-12 rounded-ctl bg-surface px-3.5 text-base ring-1 ring-inset ring-line placeholder:text-muted/70 focus:outline-none focus:ring-2 focus:ring-accent";
export function Input({ className, invalid, ...p }: InputHTMLAttributes<HTMLInputElement> & { invalid?: boolean }) {
  return <input className={cx(inputCls, invalid && "ring-2 ring-bad", className)} aria-invalid={invalid || undefined} {...p} />;
}
export function Textarea({ className, ...p }: TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return <textarea className={cx(inputCls, "min-h-24 py-3 leading-relaxed", className)} {...p} />;
}
export function Select({ className, children, ...p }: SelectHTMLAttributes<HTMLSelectElement>) {
  return <select className={cx(inputCls, "pr-8", className)} {...p}>{children}</select>;
}

export function Checkbox({ checked, onChange, label, disabled }: { checked: boolean; onChange: (v: boolean) => void; label: string; disabled?: boolean }) {
  return (
    <label className={cx("inline-flex min-h-11 cursor-pointer items-center gap-2.5 rounded-ctl px-3 ring-1 ring-inset", checked ? "bg-accent-soft ring-accent" : "bg-surface ring-line", disabled && "opacity-60")}>
      <input type="checkbox" className="h-5 w-5 accent-[rgb(var(--ink))]" checked={checked} disabled={disabled} onChange={(e) => onChange(e.target.checked)} />
      <span className="text-[15px]">{label}</span>
    </label>
  );
}

export function Segmented<T extends string>({ value, onChange, options, label, disabled }:
  { value: T | null; onChange: (v: T) => void; options: { id: T; label: string }[]; label: string; disabled?: boolean }) {
  return (
    <div role="radiogroup" aria-label={label} className="flex flex-wrap gap-2">
      {options.map((o) => (
        <button key={o.id} type="button" role="radio" aria-checked={value === o.id} disabled={disabled}
          onClick={() => onChange(o.id)}
          className={cx("min-h-11 rounded-ctl px-3.5 text-[15px] ring-1 ring-inset transition-colors disabled:opacity-60",
            value === o.id ? "bg-ink text-bg ring-ink" : "bg-surface ring-line hover:ring-muted/50")}>
          {o.label}
        </button>
      ))}
    </div>
  );
}

export function Progress({ pct, label }: { pct: number; label: string }) {
  return (
    <div className="h-2.5 w-full overflow-hidden rounded-full bg-sunken" role="progressbar" aria-label={label} aria-valuemin={0} aria-valuemax={100} aria-valuenow={pct}>
      <div className="h-full rounded-full bg-accent transition-[width] duration-500" style={{ width: `${pct}%` }} />
    </div>
  );
}

export function Collapsible({ title, meta, defaultOpen, icon, children }: { title: string; meta?: ReactNode; defaultOpen?: boolean; icon?: ReactNode; children: ReactNode }) {
  const [open, setOpen] = useState(!!defaultOpen);
  const id = useId();
  return (
    <div className="border-b border-line last:border-b-0">
      <button type="button" aria-expanded={open} aria-controls={id} onClick={() => setOpen(!open)}
        className="flex min-h-14 w-full items-center gap-3 px-5 py-3 text-left hover:bg-sunken/60">
        {icon}
        <span className="min-w-0 flex-1 font-medium">{title}</span>
        {meta}
        <ChevronDown className={cx("h-5 w-5 shrink-0 text-muted transition-transform", open && "rotate-180")} aria-hidden />
      </button>
      <div id={id} hidden={!open}>{children}</div>
    </div>
  );
}

export function Spinner({ label = "Ачаалж байна…" }: { label?: string }) {
  return (
    <div role="status" className="flex items-center justify-center gap-3 py-16 text-muted">
      <LoaderCircle className="h-5 w-5 animate-spin" aria-hidden /><span>{label}</span>
    </div>
  );
}
export function ErrorBox({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <div role="alert" className="flex flex-wrap items-start gap-3 rounded-card bg-bad-soft p-4 text-[15px]">
      <CircleAlert className="mt-0.5 h-5 w-5 shrink-0 text-bad" aria-hidden />
      <p className="min-w-0 flex-1">{message}</p>
      {onRetry && <Button size="sm" variant="secondary" onClick={onRetry}>Дахин оролдох</Button>}
    </div>
  );
}
export function Empty({ title, children }: { title: string; children?: ReactNode }) {
  return (
    <div className="px-5 py-10 text-center">
      <p className="font-medium">{title}</p>
      {children && <div className="mx-auto mt-1 max-w-sm text-[15px] text-muted">{children}</div>}
    </div>
  );
}
export function Notice({ children, tone = "info" }: { children: ReactNode; tone?: "info" | "warn" }) {
  return <div className={cx("rounded-card p-4 text-[15px]", tone === "warn" ? "bg-warn-soft" : "bg-sunken")}>{children}</div>;
}

export function SaveIndicator({ state, onRetry }: { state: SaveState; onRetry?: () => void }) {
  return (
    <div aria-live="polite" className="min-h-6 text-sm">
      {state.kind === "saving" && <span className="inline-flex items-center gap-1.5 text-muted"><LoaderCircle className="h-4 w-4 animate-spin" aria-hidden />Хадгалж байна…</span>}
      {state.kind === "saved" && <span className="inline-flex items-center gap-1.5 text-ok"><CircleCheck className="h-4 w-4" aria-hidden />Хадгалагдсан · {state.at.toLocaleTimeString("mn-MN", { hour: "2-digit", minute: "2-digit" })}</span>}
      {state.kind === "error" && (
        <span className="inline-flex flex-wrap items-center gap-2 text-bad"><CircleAlert className="h-4 w-4" aria-hidden />Хадгалагдсангүй: {state.message}
          {onRetry && <button type="button" className="font-medium underline underline-offset-2" onClick={onRetry}>Дахин оролдох</button>}</span>
      )}
    </div>
  );
}

export function StatusPill({ status }: { status: "done" | "partial" | "help" | null | undefined }) {
  if (!status) return <span className="rounded-full bg-sunken px-2.5 py-0.5 text-[13px] text-muted">Хийгээгүй</span>;
  const m = { done: ["bg-ok-soft text-ok", "Хийсэн"], partial: ["bg-warn-soft text-warn", "Хэсэгчлэн"], help: ["bg-bad-soft text-bad", "Дэмжлэг хэрэгтэй"] }[status];
  return <span className={cx("rounded-full px-2.5 py-0.5 text-[13px] font-medium", m[0])}>{m[1]}</span>;
}

export function PageHeader({ eyebrow, title, children }: { eyebrow?: ReactNode; title: ReactNode; children?: ReactNode }) {
  return (
    <header className="mb-5">
      {eyebrow && <p className="text-sm text-muted">{eyebrow}</p>}
      <h1 className="mt-0.5 text-2xl font-semibold tracking-tight">{title}</h1>
      {children && <div className="mt-2 text-[15px] text-muted">{children}</div>}
    </header>
  );
}

export { cx };

/** Баталгаажуулах жижиг dialog. Esc эсвэл гадна дарвал хаагдана, фокус дотроо үлдэнэ. */
export function Dialog({ open, title, children, onClose, actions }: { open: boolean; title: string; children: ReactNode; onClose: () => void; actions: ReactNode }) {
  const id = useId();
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-scrim/50 px-4 py-6" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}
      onKeyDown={(e) => {
        if (e.key === "Escape") { e.stopPropagation(); onClose(); }
        if (e.key === "Tab") {
          const f = Array.from(e.currentTarget.querySelectorAll<HTMLElement>("button:not([disabled]),input,textarea,select"));
          if (!f.length) return;
          if (e.shiftKey && document.activeElement === f[0]) { e.preventDefault(); f[f.length - 1].focus(); }
          else if (!e.shiftKey && document.activeElement === f[f.length - 1]) { e.preventDefault(); f[0].focus(); }
        }
      }}>
      <div role="dialog" aria-modal="true" aria-labelledby={id} className="w-full max-w-sm rounded-card bg-surface p-5 shadow-xl ring-1 ring-line">
        <h2 id={id} className="text-[17px] font-semibold">{title}</h2>
        <div className="mt-2 text-[15px] text-muted">{children}</div>
        <div className="mt-5 flex flex-wrap justify-end gap-2">{actions}</div>
      </div>
    </div>
  );
}
