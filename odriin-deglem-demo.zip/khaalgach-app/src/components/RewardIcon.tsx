import { Footprints, Gift, Hand, Palette, Star, Timer } from "lucide-react";
import type { RewardIcon as Kind } from "../lib/types";
import { BallLogo } from "./AppShell";

export const REWARD_ICONS: { id: Kind; label: string }[] = [
  { id: "glove", label: "Бээлий" }, { id: "ball", label: "Бөмбөг" }, { id: "socks", label: "Оймс" },
  { id: "timer", label: "Нэмэлт цаг" }, { id: "palette", label: "Бүтээлч ажил" }, { id: "gift", label: "Бэлэг" }, { id: "star", label: "Од" },
];

export default function RewardIcon({ kind, className = "h-6 w-6" }: { kind: Kind; className?: string }) {
  const p = { className, "aria-hidden": true } as const;
  switch (kind) {
    case "glove": return <Hand {...p} />;
    case "ball": return <BallLogo className={className} />;
    case "socks": return <Footprints {...p} />;
    case "timer": return <Timer {...p} />;
    case "palette": return <Palette {...p} />;
    case "star": return <Star {...p} />;
    default: return <Gift {...p} />;
  }
}
