import { Moon, Sun } from "lucide-react";
import { useTheme } from "../lib/theme";

export default function ThemeToggle({ className = "" }: { className?: string }) {
  const [theme, toggle] = useTheme();
  const dark = theme === "dark";
  return (
    <button type="button" onClick={toggle} aria-pressed={dark}
      aria-label={dark ? "Өдрийн горимд шилжих" : "Шөнийн горимд шилжих"} title={dark ? "Өдрийн горим" : "Шөнийн горим"}
      className={`grid h-11 w-11 shrink-0 place-items-center rounded-ctl text-muted hover:bg-sunken hover:text-ink ${className}`}>
      {dark ? <Sun className="h-5 w-5" aria-hidden /> : <Moon className="h-5 w-5" aria-hidden />}
    </button>
  );
}
