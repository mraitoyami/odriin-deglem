import { CATEGORIES, OFFSCREEN, moodLabel } from "../lib/constants";
import { fmtMinutes, formatShort, todayUB } from "../lib/dates";
import { dayProgress } from "../lib/progress";
import type { HomeLog, Task, TaskLog } from "../lib/types";
import { Progress, cx } from "./ui";

export function CategoryBars({ tasks, logs, date }: { tasks: Task[]; logs: TaskLog[]; date: string }) {
  const p = dayProgress(tasks, logs, date);
  return (
    <div className="grid gap-3">
      {CATEGORIES.filter((c) => p.byCat[c.id]).map((c) => {
        const v = p.byCat[c.id]!; const pct = Math.round((v.score / v.total) * 100);
        return (
          <div key={c.id} className="grid grid-cols-[minmax(0,1fr)_3rem] items-center gap-x-3 gap-y-1.5">
            <span className="truncate text-[15px]">{c.label}</span>
            <span className="tnum text-right text-sm text-muted">{pct}%</span>
            <div className="col-span-2"><Progress pct={pct} label={c.label} /></div>
          </div>
        );
      })}
    </div>
  );
}

export function WeekTable({ days, tasks, logs, home, screenLimit }: { days: string[]; tasks: Task[]; logs: TaskLog[]; home: HomeLog[]; screenLimit: number }) {
  const today = todayUB();
  return (
    <div className="overflow-x-auto">
      <table className="w-full min-w-[520px] text-[15px]">
        <thead>
          <tr className="border-b border-line text-left text-[13px] text-muted">
            <th className="px-5 py-2.5 font-medium">Өдөр</th>
            <th className="px-3 py-2.5 font-medium">Биелэлт</th>
            <th className="px-3 py-2.5 text-right font-medium">Дэлгэц</th>
            <th className="px-5 py-2.5 text-right font-medium">Хөдөлгөөн</th>
          </tr>
        </thead>
        <tbody>
          {days.slice().reverse().map((d) => {
            const p = dayProgress(tasks, logs, d);
            const h = home.find((x) => x.log_date === d);
            const over = h?.screen_minutes != null && h.screen_minutes > screenLimit;
            return (
              <tr key={d} className="border-b border-line last:border-b-0">
                <td className="whitespace-nowrap px-5 py-3">{d === today ? "Өнөөдөр" : formatShort(d)}</td>
                <td className="px-3 py-3"><div className="flex items-center gap-3"><div className="w-24"><Progress pct={p.pct} label={`${d} биелэлт`} /></div><span className="tnum text-sm text-muted">{p.pct}%</span></div></td>
                <td className={cx("tnum whitespace-nowrap px-3 py-3 text-right", over && "font-medium text-warn")}>{fmtMinutes(h?.screen_minutes)}</td>
                <td className="tnum whitespace-nowrap px-5 py-3 text-right">{h?.movement_minutes != null ? `${h.movement_minutes} мин` : "—"}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

export function HomeLogSummary({ log, screenLimit }: { log: HomeLog | undefined; screenLimit: number }) {
  if (!log) return <p className="px-5 pb-5 text-[15px] text-muted">Энэ өдрийн гэрийн хуудас бөглөгдөөгүй байна.</p>;
  const rows: [string, string][] = [
    ["Дэлгэц", `${fmtMinutes(log.screen_minutes)}${log.screen_minutes != null ? ` (хязгаар ${fmtMinutes(screenLimit)})` : ""}`],
    ["Хөдөлгөөн", log.movement_minutes != null ? `${log.movement_minutes} мин` : "—"],
    ["Ариун цэвэр", [log.hygiene_morning ? "өглөө" : null, log.hygiene_evening ? "орой" : null].filter(Boolean).join(", ") + (log.hygiene_reminded ? " · сануулгатай" : "") || "—"],
    ["Дэлгэцгүй үйл ажиллагаа", log.offscreen.map((o) => OFFSCREEN.find((x) => x.id === o)?.label ?? o).join(", ") || "—"],
    ["Гэрийн ажил", log.chore || "—"],
    ["Сэтгэл санаа", moodLabel(log.mood)],
    ["Нойр, ажиглалт", log.sleep_note || "—"],
  ];
  return (
    <dl className="grid gap-x-4 px-5 pb-5 sm:grid-cols-[11rem_minmax(0,1fr)]">
      {rows.map(([k, v]) => (
        <div key={k} className="contents">
          <dt className="pt-3 text-sm text-muted sm:pt-2.5">{k}</dt>
          <dd className="border-b border-line pb-2.5 text-[15px] sm:pt-2.5 sm:[&:nth-last-child(1)]:border-b-0">{v}</dd>
        </div>
      ))}
    </dl>
  );
}
