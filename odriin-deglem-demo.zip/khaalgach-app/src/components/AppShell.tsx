import { NavLink, Navigate, Outlet, useLocation } from "react-router-dom";
import { CalendarDays, ClipboardList, Gift, History, LogOut, Sun, Users, type LucideIcon } from "lucide-react";
import ThemeToggle from "./ThemeToggle";
import { useAuth } from "../lib/auth";
import { DEMO } from "../lib/mode";
import { ROLE_META } from "../lib/constants";
import type { LoginRole } from "../lib/types";
import { Spinner, cx } from "./ui";

const NAV: Record<LoginRole, { to: string; label: string; icon: LucideIcon; end?: boolean }[]> = {
  student: [
    { to: "/s", label: "Өнөөдөр", icon: Sun, end: true },
    { to: "/s/rewards", label: "Шагнал", icon: Gift },
    { to: "/s/schedule", label: "Хуваарь", icon: CalendarDays },
    { to: "/s/history", label: "Түүх", icon: History },
  ],
  teacher: [{ to: "/t", label: "Сурагчид", icon: Users }],
  guardian: [
    { to: "/p", label: "Өнөөдөр", icon: Sun, end: true },
    { to: "/p/week", label: "Долоо хоног", icon: ClipboardList },
  ],
};

/** Нэвтрээгүй бол login руу, өөр role-ийн хуудас руу орох гэвэл өөрийн нүүр рүү буцаана.
 *  Энэ нь зөвхөн UI; өгөгдлийн жинхэнэ хамгаалалт нь database-ийн RLS. */
export function RequireRole({ role }: { role: LoginRole }) {
  const { state } = useAuth();
  const loc = useLocation();
  if (state.status === "loading") return <Spinner />;
  if (state.status === "signedOut") return <Navigate to="/login" replace state={{ from: loc.pathname }} />;
  if (state.profile.role !== role) return <Navigate to={ROLE_META[state.profile.role].home} replace />;
  return <Shell role={role} />;
}

function Shell({ role }: { role: LoginRole }) {
  const { state, signOut } = useAuth();
  const name = state.status === "signedIn" ? state.profile.full_name : "";
  const items = NAV[role];
  return (
    <div className="min-h-dvh lg:flex">
      {/* desktop sidebar */}
      <aside className="hidden w-64 shrink-0 flex-col border-r border-line bg-surface px-4 py-6 lg:flex">
        <div className="flex items-center justify-between gap-2"><Brand /><ThemeToggle className="-mr-2" /></div>
        <nav className="mt-8 grid gap-1" aria-label="Үндсэн цэс">
          {items.map((i) => (
            <NavLink key={i.to} to={i.to} end={i.end}
              className={({ isActive }) => cx("flex min-h-11 items-center gap-3 rounded-ctl px-3 text-[15px]", isActive ? "bg-accent-soft font-medium text-ink" : "text-muted hover:bg-sunken hover:text-ink")}>
              <i.icon className="h-5 w-5" aria-hidden />{i.label}
            </NavLink>
          ))}
        </nav>
        <div className="mt-auto border-t border-line pt-4">
          <p className="truncate text-[15px] font-medium">{name || "Хэрэглэгч"}</p>
          <p className="text-sm text-muted">{ROLE_META[role].label}</p>
          {DEMO && <p className="mt-2 inline-block rounded-full bg-accent-soft px-2.5 py-0.5 text-[13px] text-accent-ink">Demo · жишээ мэдээлэл</p>}
          <button onClick={signOut} className="mt-3 inline-flex min-h-10 items-center gap-2 rounded-ctl px-2 text-[15px] text-muted hover:bg-sunken hover:text-ink">
            <LogOut className="h-4 w-4" aria-hidden />Гарах
          </button>
        </div>
      </aside>

      {/* mobile top bar */}
      <header className="safe-t sticky top-0 z-20 border-b border-line bg-surface/95 backdrop-blur lg:hidden">
        <div className="flex h-14 items-center gap-1 px-4">
          <span className="mr-2"><Brand compact /></span>
          <span className="ml-auto min-w-0 truncate text-sm text-muted">{ROLE_META[role].label}{DEMO && " · Demo"}</span>
          <ThemeToggle />
          <button onClick={signOut} aria-label="Гарах" className="grid h-11 w-11 place-items-center rounded-ctl text-muted hover:bg-sunken hover:text-ink">
            <LogOut className="h-5 w-5" aria-hidden />
          </button>
        </div>
      </header>

      <main className={cx("mx-auto w-full max-w-3xl px-4 py-6 sm:px-6 lg:py-10", items.length > 1 && "pb-28 lg:pb-10")}>
        <Outlet />
      </main>

      {/* mobile bottom nav */}
      {items.length > 1 && (
        <nav aria-label="Үндсэн цэс" className="safe-b fixed inset-x-0 bottom-0 z-20 border-t border-line bg-surface lg:hidden">
          <div className="mx-auto flex max-w-md">
            {items.map((i) => (
              <NavLink key={i.to} to={i.to} end={i.end}
                className={({ isActive }) => cx("flex min-h-16 flex-1 flex-col items-center justify-center gap-1 text-[13px]", isActive ? "font-medium text-ink" : "text-muted")}>
                {({ isActive }) => (<>
                  <span className={cx("grid h-7 w-12 place-items-center rounded-full", isActive && "bg-accent-soft")}><i.icon className="h-5 w-5" aria-hidden /></span>
                  {i.label}
                </>)}
              </NavLink>
            ))}
          </div>
        </nav>
      )}
    </div>
  );
}

/** Хөлбөмбөгийн бөмбөгийн энгийн logo (сайтын бусад хэсэгт хөлбөмбөгийн дүрс ашиглахгүй) */
export function BallLogo({ className = "h-5 w-5" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <circle cx="12" cy="12" r="9.5" />
      <path d="M12 7.6l4 2.9-1.5 4.7h-5L8 10.5z" fill="currentColor" stroke="none" />
      <path d="M12 7.6V2.6M16 10.5l4.6-1.6M14.5 15.2l2.8 4.1M9.5 15.2l-2.8 4.1M8 10.5L3.4 8.9" />
    </svg>
  );
}

export function Brand({ compact }: { compact?: boolean }) {
  return (
    <div className="flex items-center gap-2.5">
      <span className="grid h-8 w-8 shrink-0 place-items-center rounded-[10px] bg-accent text-on-accent" aria-hidden><BallLogo /></span>
      <div className="min-w-0 leading-tight">
        <p className="text-[15px] font-semibold">Өдрийн дэглэм</p>
        {!compact && <p className="text-[13px] text-muted">51 дүгээр сургууль</p>}
      </div>
    </div>
  );
}
