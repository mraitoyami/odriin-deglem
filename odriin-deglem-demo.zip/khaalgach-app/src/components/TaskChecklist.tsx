import { Check, Goal } from "lucide-react";
import { CATEGORIES, SLOTS } from "../lib/constants";
import type { Status, Task } from "../lib/types";
import { Collapsible, StatusPill, cx } from "./ui";

interface Props {
  tasks: Task[];
  statuses: Map<string, Status>;
  editable: boolean;
  pending?: Set<string>;
  onSet?: (taskId: string, status: Status | null) => void;
  /** Нэг бүлэг л байгаа бол шууд нээлттэй */
  openAll?: boolean;
}

export default function TaskChecklist({ tasks, statuses, editable, pending, onSet, openAll }: Props) {
  const groups = CATEGORIES.map((c) => ({ ...c, items: tasks.filter((t) => t.category === c.id) })).filter((g) => g.items.length);
  let openedOne = false;
  return (
    <div>
      {groups.map((g) => {
        const done = g.items.filter((t) => statuses.get(t.id) === "done").length;
        const unfinished = g.items.some((t) => !statuses.get(t.id));
        // Дуусаагүй даалгавартай эхний бүлгийг нээж харуулна; бусдыг хэрэгтэй үед дэлгэрүүлнэ.
        const open = openAll || (unfinished && !openedOne);
        if (unfinished && !openAll) openedOne = true;
        return (
          <Collapsible key={g.id} title={g.label} defaultOpen={open}
            icon={g.id === "interest" ? <Goal className="h-5 w-5 shrink-0 text-accent-ink" aria-hidden /> : undefined}
            meta={<span className={cx("tnum text-sm", done === g.items.length ? "text-ok" : "text-muted")}>{done}/{g.items.length}</span>}>
            <ul className="pb-2">
              {g.items.map((t) => (
                <TaskRow key={t.id} task={t} status={statuses.get(t.id) ?? null} editable={editable}
                  busy={pending?.has(t.id)} onSet={onSet} />
              ))}
            </ul>
          </Collapsible>
        );
      })}
    </div>
  );
}

function TaskRow({ task, status, editable, busy, onSet }: { task: Task; status: Status | null; editable: boolean; busy?: boolean; onSet?: Props["onSet"] }) {
  const done = status === "done";
  const meta = [SLOTS[task.slot], task.minutes ? `${task.minutes} мин` : null, task.points ? `${task.points} оноо` : null].filter(Boolean).join(" · ");
  return (
    <li className="flex items-start gap-3 px-5 py-3">
      {editable ? (
        <button type="button" onClick={() => onSet?.(task.id, done ? null : "done")} disabled={busy}
          aria-pressed={done} aria-label={`${task.title}: ${done ? "хийсэн тэмдэглэгээг арилгах" : "хийсэн гэж тэмдэглэх"}`}
          className={cx("mt-0.5 grid h-8 w-8 shrink-0 place-items-center rounded-[10px] ring-2 ring-inset transition-colors",
            done ? "bg-accent ring-accent text-on-accent" : "bg-surface ring-line hover:ring-muted", busy && "opacity-60")}>
          <Check className={cx("h-5 w-5", done ? "opacity-100" : "opacity-0")} strokeWidth={3} aria-hidden />
        </button>
      ) : null}
      <div className="min-w-0 flex-1">
        <p className={cx("font-medium leading-snug", done && "text-muted line-through decoration-accent decoration-2")}>{task.title}</p>
        {task.description && <p className="mt-0.5 text-sm text-muted">{task.description}</p>}
        <p className="mt-1 text-[13px] text-muted">{meta}</p>
        {editable && (
          <div className="mt-2 flex flex-wrap gap-2">
            {(["partial", "help"] as const).map((s) => (
              <button key={s} type="button" disabled={busy} aria-pressed={status === s}
                onClick={() => onSet?.(task.id, status === s ? null : s)}
                className={cx("min-h-9 rounded-full px-3 text-[13px] ring-1 ring-inset",
                  status === s ? (s === "help" ? "bg-bad-soft text-bad ring-bad/30" : "bg-warn-soft text-warn ring-warn/30") : "text-muted ring-line hover:text-ink")}>
                {s === "partial" ? "Хэсэгчлэн хийсэн" : "Дэмжлэг хэрэгтэй"}
              </button>
            ))}
          </div>
        )}
      </div>
      {!editable && <StatusPill status={status} />}
    </li>
  );
}
