// Танилцуулгын бүх урсгалыг жинхэнэ component-уудаар шалгана (jsdom дотор).
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { cleanup, render, screen, within, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { MemoryRouter } from "react-router-dom";
import { AuthProvider } from "../lib/auth";
import { reloadFromStorage, resetDemo } from "../lib/demo/store";
import App from "../App";

const mount = (path = "/") => render(<MemoryRouter initialEntries={[path]}><AuthProvider><App /></AuthProvider></MemoryRouter>);
const user = userEvent.setup();
const points = () => Number(screen.getByTestId("points").textContent);
const progress = (name: string) => Number(screen.getByRole("progressbar", { name }).getAttribute("aria-valuenow"));
async function demoLogin(role: RegExp) {
  await user.click(await screen.findByRole("radio", { name: role }));
  await user.click(screen.getByRole("button", { name: "Demo-оор нэвтрэх" }));
}
async function logout() { await user.click(screen.getAllByRole("button", { name: "Гарах" })[0]); await screen.findByRole("heading", { name: "Нэвтрэх" }); }

beforeAll(() => { localStorage.clear(); resetDemo(); });
afterAll(() => cleanup());

describe("demo урсгал", () => {
  it("1. Сайт нээхэд login page гарна, dashboard харагдахгүй", async () => {
    mount("/s");
    expect(await screen.findByRole("heading", { name: "Нэвтрэх" })).toBeTruthy();
    expect(screen.queryByText("Өдрийн ахиц")).toBeNull();
    expect((screen.getByRole("button", { name: "Нэвтрэх" }) as HTMLButtonElement).disabled).toBe(true);
    // Logo: "51" бичвэр биш, бөмбөгийн SVG
    expect(screen.queryByText("51")).toBeNull();
    expect(document.querySelector("span.bg-accent svg")).toBeTruthy();
  });

  it("Theme: шөнийн горим асч, localStorage-д хадгалагдана", async () => {
    await user.click(screen.getByRole("button", { name: "Шөнийн горимд шилжих" }));
    expect(document.documentElement.getAttribute("data-theme")).toBe("dark");
    expect(localStorage.getItem("odriin-deglem.theme")).toBe("dark");
    expect(screen.getByRole("button", { name: "Өдрийн горимд шилжих" })).toBeTruthy();
    await user.click(screen.getByRole("button", { name: "Өдрийн горимд шилжих" }));
    expect(document.documentElement.getAttribute("data-theme")).toBe("light");
  });

  it("2. Буруу нууц үг, буруу role-ийг татгалзана", async () => {
    await user.click(screen.getByRole("radio", { name: /^Сурагч/ }));
    await user.type(screen.getByLabelText("Нэвтрэх нэр"), "bat");
    await user.type(screen.getByLabelText("Нууц үг"), "wrong");
    await user.click(screen.getByRole("button", { name: "Нэвтрэх" }));
    expect(await screen.findByText(/нууц үг буруу/)).toBeTruthy();
    await user.click(screen.getByRole("radio", { name: /^Багш/ }));
    await user.clear(screen.getByLabelText("Нууц үг"));
    await user.type(screen.getByLabelText("Нууц үг"), "demo123");
    await user.click(screen.getByRole("button", { name: "Нэвтрэх" }));
    expect(await screen.findByText(/«Багш» эрхгүй/)).toBeTruthy();
  });

  it("3–6. Сурагч: тэмдэглэхэд ахиц өөрчлөгдөж, тэмдэглэл хадгалагдана", async () => {
    await user.click(screen.getByRole("radio", { name: /^Сурагч/ }));
    await user.click(screen.getByRole("button", { name: "Нэвтрэх" }));
    expect(await screen.findByText("Өдрийн ахиц")).toBeTruthy();
    expect(progress("Өдрийн ахиц")).toBe(0);
    await waitFor(() => expect(screen.getByTestId("points")).toBeTruthy());
    const p0 = points();
    const boxes = await screen.findAllByRole("button", { name: /хийсэн гэж тэмдэглэх/ });
    await user.click(boxes[0]);
    await waitFor(() => expect(points()).toBe(p0 + 5));
    // Ижил даалгаврыг буцааж, дахин тэмдэглэхэд оноо давхардахгүй
    await user.click(screen.getByRole("button", { name: /Цүнх, хэрэгслээ шалгах: хийсэн тэмдэглэгээг арилгах/ }));
    await waitFor(() => expect(points()).toBe(p0));
    await user.click(screen.getByRole("button", { name: /Цүнх, хэрэгслээ шалгах: хийсэн гэж тэмдэглэх/ }));
    await waitFor(() => expect(points()).toBe(p0 + 5));
    await user.click(screen.getByRole("button", { name: /Хичээлдээ оролцох: хийсэн гэж тэмдэглэх/ }));
    await waitFor(() => expect(progress("Өдрийн ахиц")).toBe(11)); // 2/18
    await waitFor(() => expect(points()).toBe(p0 + 15));
    await user.click(screen.getAllByRole("button", { name: "Хэсэгчлэн хийсэн" })[2]);
    await waitFor(() => expect(progress("Өдрийн ахиц")).toBe(14)); // 2.5/18
    expect(points()).toBe(p0 + 15); // хэсэгчлэн хийсэн нь оноо өгөхгүй
    await user.type(screen.getByLabelText("Өдрийн тэмдэглэл"), "Бөмбөгтэй дасгал хийлээ");
    await user.click(screen.getByRole("button", { name: "Хадгалах" }));
    expect(await screen.findByText(/Хадгалагдсан/)).toBeTruthy();
  });

  it("7. Refresh хийсний дараа мэдээлэл хэвээр", async () => {
    cleanup(); reloadFromStorage();
    mount("/");
    expect(await screen.findByText("Өдрийн ахиц")).toBeTruthy();
    await waitFor(() => expect(progress("Өдрийн ахиц")).toBe(14));
    expect((screen.getByLabelText("Өдрийн тэмдэглэл") as HTMLTextAreaElement).value).toBe("Бөмбөгтэй дасгал хийлээ");
    await user.click(screen.getAllByRole("link", { name: /Түүх/ })[0]);
    expect(await screen.findByText("Өмнөх өдрүүд")).toBeTruthy();
  });

  it("Шагнал: оноо хүрэхгүй бол идэвхгүй, авахад оноо хасагдаж, refresh-д хадгалагдана", async () => {
    await user.click(screen.getAllByRole("link", { name: /Шагнал/ })[0]);
    expect(await screen.findByText("Миний оноо")).toBeTruthy();
    const bal = () => Number(screen.getByText("Миний оноо").nextElementSibling!.textContent);
    const b0 = bal();
    const glove = screen.getByRole("button", { name: "Хаалгачийн бээлий: оноо хүрэлцэхгүй байна" }) as HTMLButtonElement;
    expect(glove.disabled).toBe(true);
    expect(screen.getAllByText(/Оноо хүрэлцэхгүй байна/).length).toBeGreaterThan(0);
    await user.click(screen.getByRole("button", { name: "Дасгалын нэмэлт 15 минут авах" }));
    const dlg = await screen.findByRole("dialog", { name: "Шагнал авах уу?" });
    await user.click(within(dlg).getByRole("button", { name: "Тийм, авах" }));
    expect(await screen.findByText(/шагналыг авлаа/)).toBeTruthy();
    expect(bal()).toBe(b0 - 80);
    cleanup(); reloadFromStorage();
    mount("/s/rewards");
    expect(await screen.findByText("Миний оноо")).toBeTruthy();
    expect(bal()).toBe(b0 - 80);
    const got = screen.getByRole("heading", { name: "Авсан шагналууд" }).closest("section")!;
    expect(within(got).getAllByText("Дасгалын нэмэлт 15 минут").length).toBe(2); // жишээ + шинэ
  });

  it("Сурагч URL-аар багшийн хуудас руу орж чадахгүй", async () => {
    cleanup(); mount("/t");
    expect(await screen.findByText("Өдрийн ахиц")).toBeTruthy();
    expect(screen.queryByText("Хариуцсан сурагчид")).toBeNull();
  });

  it("8. Багш: ахиц харж, даалгавар засаж, тэмдэглэл нэмнэ", async () => {
    await logout();
    await demoLogin(/^Багш/);
    expect(await screen.findByText("Хариуцсан сурагчид")).toBeTruthy();
    const bat = await screen.findByRole("link", { name: /Бат/ });
    expect(within(bat).getByText(/14%/)).toBeTruthy();
    expect(screen.getByRole("link", { name: /Номин/ })).toBeTruthy();
    await user.click(bat);
    expect(await screen.findByText("Дэмжлэг хэрэгтэй гэж тэмдэглэсэн")).toBeTruthy();
    await user.click(screen.getByRole("tab", { name: "Даалгавар" }));
    await user.click(await screen.findByRole("button", { name: "Цүнх, хэрэгслээ шалгах засах" }));
    const title = screen.getByLabelText("Нэр");
    await user.clear(title); await user.type(title, "Цүнх, харандаагаа шалгах");
    await user.click(screen.getByRole("button", { name: "Хадгалах" }));
    expect(await screen.findByText("Цүнх, харандаагаа шалгах")).toBeTruthy();
    await user.click(screen.getByRole("tab", { name: "Тэмдэглэл, зорилго" }));
    await user.type(await screen.findByLabelText("Шинэ тэмдэглэл"), "Өнөөдөр идэвхтэй байлаа");
    await user.click(screen.getByRole("button", { name: "Нэмэх" }));
    expect(await screen.findByText("Өнөөдөр идэвхтэй байлаа")).toBeTruthy();
    await user.click(screen.getByRole("tab", { name: "Хуваарь" }));
    expect(await screen.findByDisplayValue("Сургуулийн цаг")).toBeTruthy();
    await user.click(screen.getByRole("tab", { name: "Тохиргоо" }));
    expect(await screen.findByText("Зорилго ба хязгаар")).toBeTruthy();
    expect(screen.queryByText(/Хуучин хувилбараас/)).toBeNull();
    await user.click(screen.getByRole("tab", { name: "Шагнал" }));
    await user.click(await screen.findByRole("button", { name: "Хөлбөмбөгийн оймс засах" }));
    const cost = screen.getByLabelText("Шаардлагатай оноо");
    await user.clear(cost); await user.type(cost, "150");
    await user.click(screen.getByRole("button", { name: "Хадгалах" }));
    expect(await screen.findByText("150 оноо")).toBeTruthy();
  });

  it("8. Эцэг эх: зөвхөн өөрийн хүүхэд, хуваалцсан тэмдэглэл, гэрийн хуудас", async () => {
    await logout();
    await demoLogin(/^Эцэг эх/);
    expect(await screen.findByText("Өнөөдрийн бүртгэл")).toBeTruthy();
    expect(await screen.findByText("Өнөөдөр идэвхтэй байлаа")).toBeTruthy();
    expect(screen.queryByText(/Дэмжлэг хүссэн даалгаврыг маргааш/)).toBeNull(); // хуваалцаагүй тэмдэглэл
    expect(screen.queryByRole("button", { name: /хийсэн гэж тэмдэглэх/ })).toBeNull(); // зөвхөн харна
    expect(screen.getByText("Цүнх, харандаагаа шалгах")).toBeTruthy(); // багшийн засвар харагдана
    await user.type(screen.getByLabelText("Цаг"), "1");
    await user.type(screen.getByLabelText("Минут"), "30");
    await user.type(screen.getByLabelText("Хөдөлгөөн"), "25");
    await user.click(screen.getByRole("button", { name: "Хадгалах" }));
    expect(await screen.findByText(/Хадгалагдсан/)).toBeTruthy();
    await user.click(screen.getAllByRole("link", { name: /Долоо хоног/ })[0]);
    const today = await screen.findByRole("row", { name: /Өнөөдөр/ });
    expect(within(today).getByText("1 ц 30 мин")).toBeTruthy();
    expect(within(today).getByText("25 мин")).toBeTruthy();
    await logout();
  });
});
