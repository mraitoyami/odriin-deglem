// Онооны дүрэм: давхар тоологдохгүй, зарцуулсан оноотой даалгаврыг буцаахгүй.
import { beforeEach, describe, expect, it } from "vitest";
import * as api from "../lib/api";
import { db, resetDemo, setSessionUser } from "../lib/demo/store";
import { todayUB } from "../lib/dates";

describe("оноо", () => {
  beforeEach(() => { localStorage.clear(); resetDemo(); setSessionUser("u-student"); });

  it("нэг даалгаврыг олон удаа «хийсэн» гэхэд нэг л удаа тоологдоно", async () => {
    const t = (await api.listTasks("s-bat"))[0];
    const a = (await api.pointsSummary("s-bat")).balance;
    for (let i = 0; i < 3; i++) await api.setLog("s-bat", t.id, todayUB(), "done");
    expect((await api.pointsSummary("s-bat")).balance).toBe(a + t.points);
    await api.setLog("s-bat", t.id, todayUB(), "help");
    expect((await api.pointsSummary("s-bat")).balance).toBe(a);
  });

  it("зарцуулсан оноотой даалгаврыг буцааж чадахгүй, оноо сөрөг болохгүй", async () => {
    const t = (await api.listTasks("s-bat"))[0];
    await api.setLog("s-bat", t.id, todayUB(), "done");
    const { balance } = await api.pointsSummary("s-bat");
    db().redemptions.push({ id: "x", student_id: "s-bat", reward_id: null, title: "Тест", icon: "gift", cost: balance, created_at: new Date().toISOString() });
    await expect(api.setLog("s-bat", t.id, todayUB(), null)).rejects.toThrow(/буцаах боломжгүй/);
    expect((await api.pointsSummary("s-bat")).balance).toBe(0);
  });

  it("оноо хүрэхгүй шагнал авахыг татгалзана, бусдын шагналыг авч чадахгүй", async () => {
    const glove = (await api.listRewards("s-bat")).find((r) => r.icon === "glove")!;
    db().redemptions.push({ id: "y", student_id: "s-bat", reward_id: null, title: "Тест", icon: "gift", cost: (await api.pointsSummary("s-bat")).balance, created_at: "" });
    await expect(api.redeemReward(glove.id)).rejects.toThrow(/Оноо хүрэлцэхгүй/);
    const nominReward = db().rewards.find((r) => r.student_id === "s-nomin")!;
    await expect(api.redeemReward(nominReward.id)).rejects.toThrow(/эрх/);
  });
});
