import { Brand } from "../components/AppShell";

/** Supabase тохируулаагүй үед апп ажиллаж байгаа мэт харагдуулахгүй. */
export default function ConfigMissing() {
  return (
    <div className="min-h-dvh px-4 py-12">
      <div className="mx-auto max-w-xl">
        <Brand />
        <h1 className="mt-10 text-2xl font-semibold">Сервер тохируулаагүй байна</h1>
        <p className="mt-2 text-[15px] text-muted">Нэвтрэлт болон өгөгдөл хадгалалт Supabase дээр ажилладаг. Одоогоор холболтын тохиргоо алга тул нэвтрэх боломжгүй.</p>
        <ol className="mt-6 grid list-decimal gap-3 pl-5 text-[15px]">
          <li>supabase.com дээр төсөл үүсгэнэ.</li>
          <li>SQL Editor-т <code className="rounded bg-sunken px-1.5">supabase/migrations/0001_init.sql</code> файлыг ажиллуулна.</li>
          <li>Authentication → Sign In / Providers хэсэгт «Allow new users to sign up»-ыг унтраана.</li>
          <li>Төслийн үндсэн хавтаст <code className="rounded bg-sunken px-1.5">.env</code> файл үүсгэж, <code className="rounded bg-sunken px-1.5">.env.example</code>-ийн дагуу URL болон anon түлхүүрээ бичнэ.</li>
          <li>Аккаунтуудыг <code className="rounded bg-sunken px-1.5">scripts/admin.mjs</code>-ээр үүсгэнэ. Дэлгэрэнгүйг README-ээс харна уу.</li>
        </ol>
      </div>
    </div>
  );
}
