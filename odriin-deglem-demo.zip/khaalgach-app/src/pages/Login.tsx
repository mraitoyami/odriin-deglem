import { useState, type FormEvent } from "react";
import { Navigate } from "react-router-dom";
import { Eye, EyeOff, GraduationCap, HeartHandshake, CircleAlert, Users } from "lucide-react";
import { useAuth } from "../lib/auth";
import { ROLE_META } from "../lib/constants";
import { usernameDomain } from "../lib/supabase";
import { DEMO } from "../lib/mode";
import { DEMO_ACCOUNTS } from "../lib/demo/store";
import type { LoginRole } from "../lib/types";
import { Brand } from "../components/AppShell";
import ThemeToggle from "../components/ThemeToggle";
import { Button, Field, Input, Spinner, cx } from "../components/ui";

const ROLES: { id: LoginRole; icon: typeof Users }[] = [
  { id: "student", icon: GraduationCap },
  { id: "teacher", icon: Users },
  { id: "guardian", icon: HeartHandshake },
];

export default function Login() {
  const { state, signIn, resetDemoData } = useAuth();
  const [confirmReset, setConfirmReset] = useState(false);
  const [resetDone, setResetDone] = useState(false);
  const [role, setRole] = useState<LoginRole | null>(null);
  const [id, setId] = useState("");
  const [pw, setPw] = useState("");
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (state.status === "loading") return <Spinner />;
  if (state.status === "signedIn") return <Navigate to={ROLE_META[state.profile.role].home} replace />;

  const notice = state.notice;
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!role) { setError("Эхлээд нэвтрэх төрлөө сонгоно уу."); return; }
    setBusy(true); setError(null);
    const err = await signIn(role, id, pw);
    setBusy(false);
    if (err) setError(err);
  };
  // Demo: сонгосон role-ийн жишээ хэрэглэгчээр шууд нэвтэрнэ
  const demoLogin = async () => {
    if (!role) { setError("Эхлээд нэвтрэх төрлөө сонгоно уу."); return; }
    const a = DEMO_ACCOUNTS.find((x) => x.role === role)!;
    setId(a.username); setPw(a.password);
    setBusy(true); setError(null);
    const err = await signIn(role, a.username, a.password);
    setBusy(false);
    if (err) setError(err);
  };

  return (
    <div className="min-h-dvh bg-bg px-4 py-10 sm:py-16">
      <div className="mx-auto w-full max-w-md">
        <div className="flex items-center justify-between gap-2"><Brand /><ThemeToggle className="-mr-2" /></div>
        <h1 className="mt-10 text-2xl font-semibold tracking-tight">Нэвтрэх</h1>
        <p className="mt-1 text-[15px] text-muted">Суралцагчийн өдрийн дэглэм, дэмжлэгийн төлөвлөгөө</p>

        <form onSubmit={submit} className="mt-8 grid gap-6" noValidate>
          <fieldset>
            <legend className="text-[15px] font-medium">Та хэн бэ?</legend>
            <div className="mt-2 grid gap-2" role="radiogroup">
              {ROLES.map(({ id: r, icon: Icon }) => {
                const on = role === r;
                return (
                  <button key={r} type="button" role="radio" aria-checked={on} onClick={() => { setRole(r); setError(null); }}
                    className={cx("flex min-h-16 items-center gap-3 rounded-card bg-surface px-4 text-left ring-1 ring-inset transition-shadow",
                      on ? "ring-2 ring-ink" : "ring-line hover:ring-muted/50")}>
                    <span className={cx("grid h-10 w-10 shrink-0 place-items-center rounded-ctl", on ? "bg-accent text-on-accent" : "bg-sunken")}><Icon className="h-5 w-5" aria-hidden /></span>
                    <span className="min-w-0 flex-1">
                      <span className="block font-medium">{ROLE_META[r].label}</span>
                      <span className="block text-sm text-muted">{ROLE_META[r].desc}</span>
                    </span>
                    <span className={cx("h-5 w-5 shrink-0 rounded-full ring-2 ring-inset", on ? "bg-ink ring-ink shadow-[inset_0_0_0_4px_rgb(var(--surface))]" : "ring-line")} aria-hidden />
                  </button>
                );
              })}
            </div>
          </fieldset>

          <div className={cx("grid gap-4", !role && "opacity-50")} aria-disabled={!role}>
            <Field label={DEMO || usernameDomain ? "Нэвтрэх нэр" : "И-мэйл"} htmlFor="login-id">
              <Input id="login-id" autoComplete="username" inputMode="email" autoCapitalize="none" spellCheck={false}
                value={id} onChange={(e) => setId(e.target.value)} disabled={!role} />
            </Field>
            <Field label="Нууц үг" htmlFor="login-pw">
              <div className="relative">
                <Input id="login-pw" type={show ? "text" : "password"} autoComplete="current-password" className="pr-12"
                  value={pw} onChange={(e) => setPw(e.target.value)} disabled={!role} />
                <button type="button" onClick={() => setShow(!show)} disabled={!role}
                  aria-label={show ? "Нууц үгийг нуух" : "Нууц үгийг харуулах"} aria-pressed={show}
                  className="absolute right-1 top-1/2 grid h-10 w-10 -translate-y-1/2 place-items-center rounded-ctl text-muted hover:text-ink">
                  {show ? <EyeOff className="h-5 w-5" aria-hidden /> : <Eye className="h-5 w-5" aria-hidden />}
                </button>
              </div>
            </Field>
          </div>

          {(error || notice) && (
            <div role="alert" className="flex gap-2.5 rounded-card bg-bad-soft p-4 text-[15px]">
              <CircleAlert className="mt-0.5 h-5 w-5 shrink-0 text-bad" aria-hidden /><p>{error || notice}</p>
            </div>
          )}

          <div className="grid gap-2">
            <Button type="submit" loading={busy} disabled={!role}>Нэвтрэх</Button>
            {DEMO && <Button type="button" variant="secondary" onClick={demoLogin} disabled={!role || busy}>Demo-оор нэвтрэх</Button>}
          </div>
          {!DEMO && <p className="text-sm text-muted">Аккаунтыг сургууль үүсгэж олгоно. Нууц үгээ мартсан бол анги удирдсан багшдаа хандана уу.</p>}
        </form>

        {DEMO && (
          <section className="mt-8 rounded-card bg-sunken p-4 text-[15px]" aria-labelledby="demo-h">
            <h2 id="demo-h" className="font-medium">Танилцуулгын (demo) хувилбар</h2>
            <p className="mt-1 text-muted">Жинхэнэ нэвтрэлт биш. Бүх мэдээлэл жишээ бөгөөд зөвхөн энэ хөтөч дээр хадгалагдана.</p>
            <dl className="mt-3 grid grid-cols-[minmax(0,1fr)_auto] gap-x-4 gap-y-1">
              {DEMO_ACCOUNTS.filter((a) => a.id !== "u-student2").map((a) => (
                <div key={a.id} className="contents">
                  <dt className="truncate">{ROLE_META[a.role].label}</dt>
                  <dd className="tnum font-mono text-sm">{a.username} / {a.password}</dd>
                </div>
              ))}
            </dl>
            <div className="mt-4 border-t border-line pt-3">
              {resetDone ? <p className="text-ok" role="status">Жишээ мэдээллийг анхны байдалд нь буцаалаа.</p>
                : confirmReset ? (
                  <div className="flex flex-wrap items-center gap-2">
                    <span>Бүх өөрчлөлт арилна. Итгэлтэй байна уу?</span>
                    <Button size="sm" variant="danger" onClick={() => { resetDemoData?.(); setConfirmReset(false); setResetDone(true); }}>Тийм, дахин эхлүүлэх</Button>
                    <Button size="sm" variant="ghost" onClick={() => setConfirmReset(false)}>Болих</Button>
                  </div>
                ) : <button type="button" className="min-h-10 text-muted underline underline-offset-2 hover:text-ink" onClick={() => setConfirmReset(true)}>Demo өгөгдлийг дахин эхлүүлэх</button>}
            </div>
          </section>
        )}
      </div>
    </div>
  );
}
