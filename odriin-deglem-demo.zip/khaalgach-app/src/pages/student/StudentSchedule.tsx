import * as api from "../../lib/api";
import { useLoad } from "../../lib/hooks";
import { nowMinutesUB } from "../../lib/dates";
import type { ScheduleItem } from "../../lib/types";
import { Card, Empty, ErrorBox, PageHeader, Spinner, cx } from "../../components/ui";

export function ScheduleList({ items }: { items: ScheduleItem[] }) {
  const now = nowMinutesUB();
  const toMin = (t: string | null) => (t ? Number(t.slice(0, 2)) * 60 + Number(t.slice(3, 5)) : null);
  let current = -1;
  items.forEach((r, i) => { const m = toMin(r.start_time); if (m != null && m <= now) current = i; });
  return (
    <ol>
      {items.map((r, i) => (
        <li key={r.id} className={cx("flex gap-4 border-b border-line px-5 py-4 last:border-b-0", i === current && "bg-accent-soft")}>
          <span className="tnum w-12 shrink-0 pt-0.5 text-[15px] font-medium">{r.start_time?.slice(0, 5) ?? "—"}</span>
          <div className="min-w-0">
            <p className="text-sm text-muted">{r.period}{i === current && <span className="ml-2 font-medium text-accent-ink">· Одоо</span>}</p>
            <p className="font-medium">{r.activity}</p>
          </div>
        </li>
      ))}
    </ol>
  );
}

export default function StudentSchedule() {
  const { data, error, loading, reload } = useLoad(async () => {
    const [s] = await api.myStudent();
    return s ? api.listSchedule(s.id) : [];
  }, []);
  if (loading && !data) return <Spinner />;
  if (error) return <ErrorBox message={error} onRetry={reload} />;
  return (
    <div>
      <PageHeader title="Өдрийн хуваарь">Жишиг хуваарь. Цагийг багш тань тохируулна.</PageHeader>
      <Card>{data && data.length ? <ScheduleList items={data} /> : <Empty title="Хуваарь хоосон байна">Багш хуваарь нэмэхэд энд харагдана.</Empty>}</Card>
    </div>
  );
}
