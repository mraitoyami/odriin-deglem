import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { ChevronLeft, ChevronRight, Target } from "lucide-react";
import * as api from "../../lib/api";
import { useLoad, useSave } from "../../lib/hooks";
import { formatLong, greeting, isEditableDay, todayUB } from "../../lib/dates";
import { dayProgress } from "../../lib/progress";
import { friendlyError } from "../../lib/supabase";
import type { Status, TaskLog } from "../../lib/types";
import TaskChecklist from "../../components/TaskChecklist";
import { Button, Card, CardHeader, Empty, ErrorBox, PageHeader, Progress, SaveIndicator, Spinner, Textarea } from "../../components/ui";

export default function StudentDay() {
  const params = useParams();
  const today = todayUB();
  const date = params.date && /^\d{4}-\d{2}-\d{2}$/.test(params.date) && params.date <= today ? params.date : today;
  const isToday = date === today;
  const editable = isEditableDay(date);

  const { data, setData, error, loading, reload } = useLoad(async () => {
    const [student] = await api.myStudent();
    if (!student) return null;
    const [tasks, logs, note, goals, points] = await Promise.all([
      api.listTasks(student.id), api.listLogs([student.id], date, date),
      api.getStudentNote(student.id, date), api.listGoals(student.id, date, date), api.pointsSummary(student.id),
    ]);
    return { student, tasks, logs, note: note?.note ?? "", goal: goals[0]?.goal ?? "", points: points.balance };
  }, [date]);

  const [pending, setPending] = useState<Set<string>>(new Set());
  const [rowError, setRowError] = useState<string | null>(null);
  const [note, setNote] = useState("");
  const noteSave = useSave();
  useEffect(() => { if (data) setNote(data.note); }, [data?.note]); // eslint-disable-line react-hooks/exhaustive-deps

  if (loading && !data) return <Spinner />;
  if (error) return <ErrorBox message={error} onRetry={reload} />;
  if (!data) return <Card><Empty title="Сурагчийн бүртгэл холбогдоогүй байна">Таны аккаунтыг сурагчийн бүртгэлтэй холбох шаардлагатай. Анги удирдсан багшдаа хандана уу.</Empty></Card>;

  const { student, tasks, logs } = data;
  const p = dayProgress(tasks, logs, date);

  // Optimistic update: алдаа гарвал буцааж, алдааг харуулна.
  const setStatus = async (taskId: string, status: Status | null) => {
    const prev = logs;
    const next: TaskLog[] = logs.filter((l) => l.task_id !== taskId);
    if (status) next.push({ task_id: taskId, student_id: student.id, log_date: date, status });
    setData({ ...data, logs: next });
    setPending((s) => new Set(s).add(taskId)); setRowError(null);
    try {
      await api.setLog(student.id, taskId, date, status);
      // Оноог сервер/demo талын бүртгэлээс дахин уншина: давхар тоолохгүй
      const pts = await api.pointsSummary(student.id);
      setData((d) => (d ? { ...d, points: pts.balance } : d));
    }
    catch (e) { setData((d) => (d ? { ...d, logs: prev } : d)); setRowError(`Хадгалагдсангүй: ${friendlyError(e)}`); }
    finally { setPending((s) => { const n = new Set(s); n.delete(taskId); return n; }); }
  };

  const saveNote = () => noteSave.run(async () => {
    await api.saveStudentNote(student.id, date, note.trim());
    setData((d) => (d ? { ...d, note: note.trim() } : d));
  });

  return (
    <div className="grid gap-5">
      {isToday ? (
        <PageHeader eyebrow={formatLong(date)} title={`${greeting()}, ${student.full_name.split(" ")[0]}!`} />
      ) : (
        <div>
          <Link to="/s/history" className="inline-flex min-h-10 items-center gap-1 text-[15px] text-muted hover:text-ink"><ChevronLeft className="h-4 w-4" aria-hidden />Түүх</Link>
          <PageHeader title={formatLong(date)}>{editable ? "Энэ өдрийн бүртгэлээ засаж болно." : "Энэ өдрийн бүртгэлийг зөвхөн харах боломжтой."}</PageHeader>
        </div>
      )}

      <Card className="p-5">
        <div className="flex items-baseline justify-between gap-3">
          <p className="font-medium">Өдрийн ахиц</p>
          <p className="tnum text-[15px] text-muted"><span className="text-ink font-medium">{p.done}</span> / {p.total} хийсэн · {p.pct}%</p>
        </div>
        <div className="mt-3"><Progress pct={p.pct} label="Өдрийн ахиц" /></div>
        {data.goal && (
          <p className="mt-4 flex items-start gap-2 text-[15px]"><Target className="mt-0.5 h-5 w-5 shrink-0 text-accent-ink" aria-hidden /><span><span className="text-muted">Өнөөдрийн жижиг зорилго: </span>{data.goal}</span></p>
        )}
        {p.total > 0 && p.done === p.total && <p className="mt-3 text-[15px] font-medium text-ok">Өнөөдрийн бүх зүйлээ хийлээ. Сайн байна!</p>}
        <Link to="/s/rewards" className="mt-4 flex min-h-11 items-center justify-between gap-3 rounded-ctl bg-accent-soft px-4 text-[15px] hover:bg-accent-soft/70">
          <span>Миний оноо: <b className="tnum" data-testid="points">{data.points}</b></span>
          <span className="inline-flex items-center gap-1 text-accent-ink">Шагнал<ChevronRight className="h-4 w-4" aria-hidden /></span>
        </Link>
      </Card>

      {rowError && <ErrorBox message={rowError} />}

      <Card>
        <CardHeader title="Хийх зүйлс" hint="Хийснээ тэмдэглэ. Хэцүү байвал «Дэмжлэг хэрэгтэй»-г сонго." />
        <div className="mt-3 border-t border-line">
          {tasks.length ? (
            <TaskChecklist tasks={tasks} statuses={p.byTask} editable={editable} pending={pending} onSet={setStatus} />
          ) : (
            <Empty title="Даалгавар оноогдоогүй байна">Багш тань даалгавар нэмэхэд энд харагдана.</Empty>
          )}
        </div>
      </Card>

      <Card className="p-5">
        <label htmlFor="day-note" className="font-medium">Өдрийн тэмдэглэл</label>
        <p className="mt-0.5 text-sm text-muted">Өнөөдөр юу сайн болсон бэ? Юу хэцүү байсан бэ?</p>
        <Textarea id="day-note" className="mt-3" maxLength={500} value={note} disabled={!editable}
          onChange={(e) => { setNote(e.target.value); if (noteSave.state.kind === "saved") noteSave.setState({ kind: "idle" }); }} />
        <div className="mt-3 flex flex-wrap items-center justify-between gap-3">
          <SaveIndicator state={noteSave.state} onRetry={noteSave.retry} />
          {editable && <Button size="sm" onClick={saveNote} loading={noteSave.state.kind === "saving"} disabled={note.trim() === data.note}>Хадгалах</Button>}
        </div>
      </Card>
    </div>
  );
}
