import { Link } from "react-router-dom";
import { ChevronRight } from "lucide-react";
import * as api from "../../lib/api";
import { useLoad } from "../../lib/hooks";
import { addDays, formatLong, lastDays, todayUB } from "../../lib/dates";
import { dayProgress } from "../../lib/progress";
import { Card, Empty, ErrorBox, PageHeader, Progress, Spinner } from "../../components/ui";

export default function StudentHistory() {
  const today = todayUB();
  const days = lastDays(14, today).reverse();
  const { data, error, loading, reload } = useLoad(async () => {
    const [s] = await api.myStudent();
    if (!s) return null;
    const from = addDays(today, -13);
    const [tasks, logs, notes] = await Promise.all([api.listTasks(s.id), api.listLogs([s.id], from, today), api.listStudentNotes(s.id, from, today)]);
    return { tasks, logs, notes };
  }, [today]);
  if (loading && !data) return <Spinner />;
  if (error) return <ErrorBox message={error} onRetry={reload} />;
  if (!data) return <Card><Empty title="Сурагчийн бүртгэл холбогдоогүй байна" /></Card>;
  const any = data.logs.length > 0 || data.notes.length > 0;
  return (
    <div>
      <PageHeader title="Өмнөх өдрүүд">Сүүлийн 14 хоног. Сүүлийн 7 хоногийн бүртгэлээ засаж болно.</PageHeader>
      <Card>
        {!any ? <Empty title="Бүртгэл алга">Өнөөдрөөс эхлэн хийсэн зүйлээ тэмдэглэхэд энд харагдана.</Empty> : (
          <ul>
            {days.map((d) => {
              const p = dayProgress(data.tasks, data.logs, d);
              const note = data.notes.find((n) => n.log_date === d)?.note;
              return (
                <li key={d} className="border-b border-line last:border-b-0">
                  <Link to={d === today ? "/s" : `/s/day/${d}`} className="flex items-center gap-4 px-5 py-4 hover:bg-sunken/60">
                    <div className="min-w-0 flex-1">
                      <div className="flex items-baseline justify-between gap-3">
                        <p className="font-medium">{d === today ? "Өнөөдөр" : formatLong(d)}</p>
                        <p className="tnum text-sm text-muted">{p.done}/{p.total}{p.help ? ` · ${p.help} дэмжлэг` : ""}</p>
                      </div>
                      <div className="mt-2"><Progress pct={p.pct} label={`${d} ахиц`} /></div>
                      {note && <p className="mt-2 truncate text-sm text-muted">{note}</p>}
                    </div>
                    <ChevronRight className="h-5 w-5 shrink-0 text-muted" aria-hidden />
                  </Link>
                </li>
              );
            })}
          </ul>
        )}
      </Card>
    </div>
  );
}
