import { useState } from "react";
import * as api from "../../lib/api";
import { useLoad } from "../../lib/hooks";
import { formatLong } from "../../lib/dates";
import { friendlyError } from "../../lib/supabase";
import type { Reward } from "../../lib/types";
import RewardIcon from "../../components/RewardIcon";
import { Button, Card, CardHeader, Dialog, Empty, ErrorBox, PageHeader, Spinner, cx } from "../../components/ui";

export default function StudentRewards() {
  const { data, setData, error, loading, reload } = useLoad(async () => {
    const [student] = await api.myStudent();
    if (!student) return null;
    const [points, rewards, redemptions] = await Promise.all([api.pointsSummary(student.id), api.listRewards(student.id), api.listRedemptions(student.id)]);
    return { student, points, rewards, redemptions };
  }, []);
  const [pick, setPick] = useState<Reward | null>(null);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);

  if (loading && !data) return <Spinner />;
  if (error) return <ErrorBox message={error} onRetry={reload} />;
  if (!data) return <Card><Empty title="Сурагчийн бүртгэл холбогдоогүй байна" /></Card>;
  const { points, rewards, redemptions } = data;

  const confirm = async () => {
    if (!pick) return;
    setBusy(true); setMsg(null);
    try {
      const r = await api.redeemReward(pick.id);
      setData({ ...data, points: { ...points, spent: points.spent + r.cost, balance: points.balance - r.cost }, redemptions: [r, ...redemptions] });
      setMsg({ ok: true, text: `«${r.title}» шагналыг авлаа. Эцэг эх эсвэл багштайгаа тохиролцоорой.` });
    } catch (e) { setMsg({ ok: false, text: friendlyError(e) }); }
    finally { setBusy(false); setPick(null); }
  };

  return (
    <div className="grid gap-5">
      <PageHeader title="Шагнал">Хийсэн даалгавар бүр оноо өгнө. Шагналыг эцэг эх, багштайгаа тохиролцож авна.</PageHeader>

      <Card className="flex flex-wrap items-end justify-between gap-4 p-5">
        <div>
          <p className="text-[15px] text-muted">Миний оноо</p>
          <p className="tnum mt-1 text-4xl font-semibold tracking-tight" aria-live="polite">{points.balance}</p>
        </div>
        <p className="tnum text-sm text-muted">Цуглуулсан {points.earned} · Зарцуулсан {points.spent}</p>
      </Card>

      {msg && (msg.ok
        ? <div role="status" className="rounded-card bg-ok-soft p-4 text-[15px] text-ok">{msg.text}</div>
        : <ErrorBox message={msg.text} />)}

      {rewards.length === 0 ? <Card><Empty title="Шагнал алга">Багш шагнал нэмэхэд энд харагдана.</Empty></Card> : (
        <ul className="grid gap-3 sm:grid-cols-2">
          {rewards.map((r) => {
            const short = points.balance < r.cost;
            const pct = Math.min(100, Math.round((points.balance / r.cost) * 100));
            return (
              <li key={r.id}>
                <Card as="article" className="flex h-full flex-col p-5">
                  <div className="flex items-start gap-3">
                    <span className={cx("grid h-12 w-12 shrink-0 place-items-center rounded-ctl", short ? "bg-sunken text-muted" : "bg-accent text-on-accent")}><RewardIcon kind={r.icon} /></span>
                    <div className="min-w-0 flex-1">
                      <h3 className="font-medium leading-snug">{r.title}</h3>
                      <p className="tnum mt-0.5 text-[15px] font-medium text-accent-ink">{r.cost} оноо</p>
                    </div>
                  </div>
                  {r.description && <p className="mt-3 text-sm text-muted">{r.description}</p>}
                  <div className="mt-auto pt-4">
                    {short && (
                      <div className="mb-3">
                        <div className="h-1.5 overflow-hidden rounded-full bg-sunken" aria-hidden><div className="h-full rounded-full bg-accent" style={{ width: `${pct}%` }} /></div>
                        <p className="mt-1.5 text-sm text-muted">Оноо хүрэлцэхгүй байна · {r.cost - points.balance} дутуу</p>
                      </div>
                    )}
                    <Button className="w-full" variant={short ? "secondary" : "primary"} disabled={short}
                      aria-label={short ? `${r.title}: оноо хүрэлцэхгүй байна` : `${r.title} авах`}
                      onClick={() => { setMsg(null); setPick(r); }}>Авах</Button>
                  </div>
                </Card>
              </li>
            );
          })}
        </ul>
      )}

      <Card>
        <CardHeader title="Авсан шагналууд" />
        {redemptions.length ? (
          <ul className="mt-3">{redemptions.map((r) => (
            <li key={r.id} className="flex items-center gap-3 border-t border-line px-5 py-3">
              <span className="grid h-9 w-9 shrink-0 place-items-center rounded-ctl bg-accent-soft text-accent-ink"><RewardIcon kind={r.icon} className="h-5 w-5" /></span>
              <div className="min-w-0 flex-1"><p className="font-medium">{r.title}</p><p className="text-[13px] text-muted">{formatLong(r.created_at.slice(0, 10))}</p></div>
              <span className="tnum shrink-0 text-sm text-muted">−{r.cost}</span>
            </li>))}
          </ul>
        ) : <p className="px-5 pb-5 pt-2 text-[15px] text-muted">Одоогоор шагнал аваагүй байна.</p>}
      </Card>

      <Dialog open={!!pick} title="Шагнал авах уу?" onClose={() => !busy && setPick(null)}
        actions={<>
          <Button variant="secondary" size="sm" onClick={() => setPick(null)} disabled={busy} autoFocus>Болих</Button>
          <Button size="sm" onClick={confirm} loading={busy}>Тийм, авах</Button>
        </>}>
        {pick && <>«{pick.title}» шагналд <b className="text-ink">{pick.cost} оноо</b> зарцуулна. Үлдэх оноо: {points.balance - pick.cost}.</>}
      </Dialog>
    </div>
  );
}
