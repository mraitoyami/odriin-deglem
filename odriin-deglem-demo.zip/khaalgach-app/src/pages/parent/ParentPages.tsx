import { useEffect, useState, type FormEvent, type ReactNode } from "react";
import { useSearchParams } from "react-router-dom";
import { MessageSquare, Target } from "lucide-react";
import * as api from "../../lib/api";
import { useLoad, useSave } from "../../lib/hooks";
import { MOODS, OFFSCREEN, moodLabel } from "../../lib/constants";
import { addDays, formatLong, formatShort, isEditableDay, lastDays, todayUB } from "../../lib/dates";
import { dayProgress } from "../../lib/progress";
import type { HomeLog, Mood, Student } from "../../lib/types";
import TaskChecklist from "../../components/TaskChecklist";
import { WeekTable } from "../../components/Summaries";
import { Button, Card, CardHeader, Checkbox, Empty, ErrorBox, Field, Input, PageHeader, Progress, SaveIndicator, Segmented, Spinner, Textarea, cx } from "../../components/ui";

/** Эцэг эхэд холбогдсон хүүхдүүд (RLS зөвхөн өөрийн хүүхдийг буцаана) */
function useChild() {
  const [sp, setSp] = useSearchParams();
  const q = useLoad(() => api.listStudents(), []);
  const kids = q.data ?? [];
  const child = kids.find((k) => k.id === sp.get("c")) ?? kids[0] ?? null;
  const pick = (id: string) => setSp((p) => { p.set("c", id); return p; }, { replace: true });
  return { ...q, kids, child, pick };
}

function ChildPicker({ kids, child, pick }: { kids: Student[]; child: Student; pick: (id: string) => void }) {
  if (kids.length < 2) return null;
  return (
    <div className="mb-5 flex flex-wrap gap-2" role="radiogroup" aria-label="Хүүхэд сонгох">
      {kids.map((k) => (
        <button key={k.id} role="radio" aria-checked={k.id === child.id} onClick={() => pick(k.id)}
          className={cx("min-h-10 rounded-full px-4 text-[15px] ring-1 ring-inset", k.id === child.id ? "bg-ink text-bg ring-ink" : "ring-line text-muted hover:text-ink")}>{k.full_name}</button>
      ))}
    </div>
  );
}

function Gate({ q, children }: { q: ReturnType<typeof useChild>; children: (c: Student) => ReactNode }) {
  if (q.loading && !q.data) return <Spinner />;
  if (q.error) return <ErrorBox message={q.error} onRetry={q.reload} />;
  if (!q.child) return <Card><Empty title="Хүүхдийн бүртгэл холбогдоогүй байна">Таны аккаунтыг хүүхдийн бүртгэлтэй холбохын тулд анги удирдсан багшид хандана уу.</Empty></Card>;
  return <><ChildPicker kids={q.kids} child={q.child} pick={q.pick} />{children(q.child)}</>;
}

export function ParentToday() {
  const q = useChild();
  return <Gate q={q}>{(c) => <TodayFor key={c.id} child={c} />}</Gate>;
}

function TodayFor({ child }: { child: Student }) {
  const today = todayUB();
  const [date, setDate] = useState(today);
  const { data, setData, error, loading, reload } = useLoad(async () => {
    const [tasks, logs, home, goals, notes, snote] = await Promise.all([
      api.listTasks(child.id), api.listLogs([child.id], date, date), api.listHomeLogs(child.id, date, date),
      api.listGoals(child.id, date, date), api.listTeacherNotes(child.id, 5), api.getStudentNote(child.id, date),
    ]);
    return { tasks, logs, home: home[0], goal: goals[0]?.goal, notes, snote: snote?.note };
  }, [child.id, date]);

  return (
    <div className="grid gap-5">
      <PageHeader eyebrow={child.full_name} title={date === today ? "Өнөөдрийн бүртгэл" : formatLong(date)}>
        <div className="flex flex-wrap gap-2 pt-1">
          {[today, addDays(today, -1)].map((d) => (
            <button key={d} onClick={() => setDate(d)} aria-pressed={date === d}
              className={cx("min-h-10 rounded-full px-4 text-[15px] ring-1 ring-inset", date === d ? "bg-ink text-bg ring-ink" : "ring-line text-muted hover:text-ink")}>
              {d === today ? "Өнөөдөр" : "Өчигдөр"}
            </button>
          ))}
        </div>
      </PageHeader>

      {loading && !data ? <Spinner /> : error ? <ErrorBox message={error} onRetry={reload} /> : data && (() => {
        const p = dayProgress(data.tasks, data.logs, date);
        return (<>
          <Card className="p-5">
            <div className="flex items-baseline justify-between gap-3"><p className="font-medium">Даалгаврын биелэлт</p><p className="tnum text-[15px] text-muted">{p.done}/{p.total} · {p.pct}%</p></div>
            <div className="mt-3"><Progress pct={p.pct} label="Даалгаврын биелэлт" /></div>
            {p.help > 0 && <p className="mt-3 text-[15px] text-bad">{p.help} даалгаварт дэмжлэг хэрэгтэй гэж тэмдэглэсэн.</p>}
            {data.goal && <p className="mt-4 flex items-start gap-2 text-[15px]"><Target className="mt-0.5 h-5 w-5 shrink-0 text-accent-ink" aria-hidden /><span><span className="text-muted">Жижиг зорилго: </span>{data.goal}</span></p>}
            {data.snote && <p className="mt-4 rounded-ctl bg-sunken p-3 text-[15px]"><span className="text-muted">Хүүхдийн тэмдэглэл: </span>{data.snote}</p>}
          </Card>

          <Card>
            <CardHeader title="Даалгавар" hint="Хүүхэд өөрөө тэмдэглэнэ" />
            <div className="mt-3 border-t border-line">
              {data.tasks.length ? <TaskChecklist tasks={data.tasks} statuses={p.byTask} editable={false} /> : <Empty title="Даалгавар оноогдоогүй байна" />}
            </div>
          </Card>

          <HomeLogForm child={child} date={date} initial={data.home} onSaved={(h) => setData({ ...data, home: h })} />

          <Card>
            <CardHeader title="Багшийн тэмдэглэл" />
            {data.notes.length ? (
              <ul className="mt-3">{data.notes.map((n) => (
                <li key={n.id} className="flex gap-3 border-t border-line px-5 py-4">
                  <MessageSquare className="mt-0.5 h-5 w-5 shrink-0 text-muted" aria-hidden />
                  <div className="min-w-0"><p className="whitespace-pre-wrap text-[15px]">{n.body}</p><p className="mt-1 text-[13px] text-muted">{formatLong(n.log_date)}</p></div>
                </li>))}
              </ul>
            ) : <p className="px-5 pb-5 pt-2 text-[15px] text-muted">Одоогоор тэмдэглэл алга.</p>}
          </Card>
        </>);
      })()}
    </div>
  );
}

const emptyLog = (sid: string, d: string): HomeLog => ({ student_id: sid, log_date: d, screen_minutes: null, movement_minutes: null, offscreen: [], chore: "", hygiene_morning: false, hygiene_evening: false, hygiene_reminded: false, mood: null, sleep_note: "" });

function HomeLogForm({ child, date, initial, onSaved }: { child: Student; date: string; initial?: HomeLog; onSaved: (h: HomeLog) => void }) {
  const [v, setV] = useState<HomeLog>(initial ?? emptyLog(child.id, date));
  const [h, setH] = useState(""); const [m, setM] = useState(""); const [mv, setMv] = useState("");
  const [err, setErr] = useState<{ screen?: string; move?: string }>({});
  const save = useSave();
  const editable = isEditableDay(date);
  useEffect(() => {
    const x = initial ?? emptyLog(child.id, date);
    setV(x);
    setH(x.screen_minutes == null ? "" : String(Math.floor(x.screen_minutes / 60)));
    setM(x.screen_minutes == null ? "" : String(x.screen_minutes % 60));
    setMv(x.movement_minutes == null ? "" : String(x.movement_minutes));
    save.setState({ kind: "idle" });
  }, [initial, child.id, date]); // eslint-disable-line react-hooks/exhaustive-deps

  const set = (p: Partial<HomeLog>) => { setV({ ...v, ...p }); if (save.state.kind === "saved") save.setState({ kind: "idle" }); };
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const hh = h === "" ? null : Number(h), mm = m === "" ? null : Number(m), mo = mv === "" ? null : Number(mv);
    const er: typeof err = {};
    if ((hh != null && (!Number.isInteger(hh) || hh < 0 || hh > 16)) || (mm != null && (!Number.isInteger(mm) || mm < 0 || mm > 59))) er.screen = "Цаг 0–16, минут 0–59 бүхэл тоо байна.";
    if (mo != null && (!Number.isInteger(mo) || mo < 0 || mo > 600)) er.move = "0–600 минутын бүхэл тоо.";
    setErr(er); if (Object.keys(er).length) return;
    const row: HomeLog = { ...v, student_id: child.id, log_date: date, screen_minutes: hh == null && mm == null ? null : (hh ?? 0) * 60 + (mm ?? 0), movement_minutes: mo, chore: v.chore.trim(), sleep_note: v.sleep_note.trim() };
    const ok = await save.run(() => api.saveHomeLog(row));
    if (ok) onSaved(row);
  };
  const toggleAct = (id: string) => set({ offscreen: v.offscreen.includes(id) ? v.offscreen.filter((x) => x !== id) : [...v.offscreen, id] });

  return (
    <Card>
      <CardHeader title="Гэрийн хяналтын хуудас" hint={`${formatShort(date)} · Дэлгэцийн хязгаар ${child.screen_limit_min} мин`} />
      <form onSubmit={submit} className="grid gap-5 p-5" noValidate>
        <fieldset disabled={!editable} className="grid gap-5">
          <Field label="Дэлгэцийн нийт хэрэглээ" error={err.screen} hint="Эхний долоо хоногт бодит хугацааг тэмдэглээд, дараа нь хамтдаа тохирно.">
            <div className="flex items-center gap-2">
              <Input aria-label="Цаг" className="w-20" type="number" inputMode="numeric" value={h} invalid={!!err.screen} onChange={(e) => setH(e.target.value)} /><span className="text-muted">цаг</span>
              <Input aria-label="Минут" className="w-20" type="number" inputMode="numeric" value={m} invalid={!!err.screen} onChange={(e) => setM(e.target.value)} /><span className="text-muted">минут</span>
            </div>
          </Field>
          <Field label="Хөдөлгөөн" htmlFor="hl-move" error={err.move}>
            <div className="flex items-center gap-2"><Input id="hl-move" className="w-24" type="number" inputMode="numeric" value={mv} invalid={!!err.move} onChange={(e) => setMv(e.target.value)} /><span className="text-muted">минут</span></div>
          </Field>
          <div className="grid gap-2">
            <p className="text-[15px] font-medium">Ариун цэвэр</p>
            <div className="flex flex-wrap gap-2">
              <Checkbox checked={v.hygiene_morning} onChange={(x) => set({ hygiene_morning: x })} label="Өглөө" />
              <Checkbox checked={v.hygiene_evening} onChange={(x) => set({ hygiene_evening: x })} label="Орой" />
              <Checkbox checked={v.hygiene_reminded} onChange={(x) => set({ hygiene_reminded: x })} label="Сануулгатай" />
            </div>
          </div>
          <div className="grid gap-2">
            <p className="text-[15px] font-medium">Дэлгэцгүй үйл ажиллагаа</p>
            <div className="flex flex-wrap gap-2">{OFFSCREEN.map((o) => <Checkbox key={o.id} checked={v.offscreen.includes(o.id)} onChange={() => toggleAct(o.id)} label={o.label} />)}</div>
          </div>
          <Field label="Гэрийн жижиг ажил" htmlFor="hl-chore"><Input id="hl-chore" maxLength={160} value={v.chore} onChange={(e) => set({ chore: e.target.value })} placeholder="Жишээ нь: аяга угаасан" /></Field>
          <div className="grid gap-2">
            <p className="text-[15px] font-medium">Сэтгэл санаа</p>
            <Segmented<Mood> label="Сэтгэл санаа" value={v.mood} onChange={(x) => set({ mood: v.mood === x ? null : x })} options={MOODS} />
          </div>
          <Field label="Нойр, ажиглалт" htmlFor="hl-sleep"><Textarea id="hl-sleep" maxLength={500} value={v.sleep_note} onChange={(e) => set({ sleep_note: e.target.value })} placeholder="Жишээ нь: 21:30-д унтсан, өглөө эрч хүчтэй" /></Field>
        </fieldset>
        <div className="flex flex-wrap items-center justify-between gap-3 border-t border-line pt-4">
          {editable ? <SaveIndicator state={save.state} onRetry={save.retry} /> : <p className="text-sm text-muted">7 хоногоос өмнөх хуудсыг засах боломжгүй.</p>}
          {editable && <Button type="submit" loading={save.state.kind === "saving"}>Хадгалах</Button>}
        </div>
      </form>
    </Card>
  );
}

export function ParentWeek() {
  const q = useChild();
  return <Gate q={q}>{(c) => <WeekFor key={c.id} child={c} />}</Gate>;
}

function WeekFor({ child }: { child: Student }) {
  const today = todayUB(); const days = lastDays(7, today);
  const { data, error, loading, reload } = useLoad(async () => {
    const from = days[0];
    const [tasks, logs, home] = await Promise.all([api.listTasks(child.id), api.listLogs([child.id], from, today), api.listHomeLogs(child.id, from, today)]);
    return { tasks, logs, home };
  }, [child.id, today]);
  if (loading && !data) return <Spinner />;
  if (error) return <ErrorBox message={error} onRetry={reload} />;
  if (!data) return null;
  const obs = data.home.filter((h) => h.mood || h.sleep_note).sort((a, b) => b.log_date.localeCompare(a.log_date));
  return (
    <div className="grid gap-5">
      <PageHeader eyebrow={child.full_name} title="Сүүлийн 7 хоног" />
      <Card><div className="pt-2"><WeekTable days={days} tasks={data.tasks} logs={data.logs} home={data.home} screenLimit={child.screen_limit_min} /></div></Card>
      <Card>
        <CardHeader title="Нойр, сэтгэл санааны ажиглалт" />
        {obs.length ? <ul className="mt-3">{obs.map((h) => (
          <li key={h.log_date} className="border-t border-line px-5 py-3 text-[15px]"><span className="text-muted">{formatShort(h.log_date)} · {moodLabel(h.mood)}</span>{h.sleep_note && <p>{h.sleep_note}</p>}</li>))}</ul>
          : <p className="px-5 pb-5 pt-2 text-[15px] text-muted">Энэ долоо хоногт ажиглалт бичигдээгүй байна.</p>}
      </Card>
    </div>
  );
}
