import { useEffect, useState, type FormEvent } from "react";
import { Pencil, Plus, Trash2, X } from "lucide-react";
import * as api from "../../lib/api";
import { useLoad, useSave } from "../../lib/hooks";
import { CATEGORIES, SLOTS } from "../../lib/constants";
import { addDays, formatLong, formatShort, todayUB } from "../../lib/dates";
import { friendlyError } from "../../lib/supabase";
import type { Category, Reward, RewardIcon, ScheduleItem, Slot, Student, Task } from "../../lib/types";
import RewardIconView, { REWARD_ICONS } from "../../components/RewardIcon";
import { Button, Card, CardHeader, Checkbox, Empty, ErrorBox, Field, Input, Notice, SaveIndicator, Select, Spinner, Textarea, cx } from "../../components/ui";

// ------------------------------------------------------------ Даалгавар

type Draft = { title: string; description: string; category: Category; slot: Slot; minutes: string; points: string; is_mongol: boolean };
const blank: Draft = { title: "", description: "", category: "study", slot: "after", minutes: "10", points: "5", is_mongol: false };

export function TasksEditor({ studentId }: { studentId: string }) {
  const { data: tasks, setData, error, loading, reload } = useLoad(() => api.listTasks(studentId, true), [studentId]);
  const [editing, setEditing] = useState<string | "new" | null>(null);
  const [seedErr, setSeedErr] = useState<string | null>(null);
  const [seeding, setSeeding] = useState(false);
  const [rowErr, setRowErr] = useState<string | null>(null);

  if (loading && !tasks) return <Spinner />;
  if (error) return <ErrorBox message={error} onRetry={reload} />;
  const list = tasks ?? [];

  const seed = async () => {
    setSeeding(true); setSeedErr(null);
    try { await api.seedPlan(studentId); await reload(); } catch (e) { setSeedErr(friendlyError(e)); } finally { setSeeding(false); }
  };
  const toggleActive = async (t: Task) => {
    setRowErr(null);
    try { const u = await api.updateTask(t.id, { active: !t.active }); setData(list.map((x) => (x.id === t.id ? u : x))); }
    catch (e) { setRowErr(friendlyError(e)); }
  };

  if (!list.length) return (
    <Card>
      <Empty title="Даалгавар алга">
        <p>51 дүгээр сургуулийн төлөвлөгөөний анхны даалгавар, хуваарийг ачаалж эхлэх боломжтой. Дараа нь засна.</p>
        <div className="mt-4 flex flex-wrap justify-center gap-2">
          <Button onClick={seed} loading={seeding}>Анхны төлөвлөгөөг ачаалах</Button>
          <Button variant="secondary" onClick={() => setEditing("new")}><Plus className="h-4 w-4" aria-hidden />Өөрөө нэмэх</Button>
        </div>
        {seedErr && <div className="mt-4"><ErrorBox message={seedErr} /></div>}
      </Empty>
      {editing === "new" && <div className="border-t border-line p-5"><TaskForm studentId={studentId} onDone={(t) => { if (t) setData([t]); setEditing(null); }} /></div>}
    </Card>
  );

  return (
    <div className="grid gap-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <p className="text-[15px] text-muted">Хасах оронд «Түр зогсоох» ашиглана. Ингэснээр өмнөх бүртгэл хадгалагдана.</p>
        <Button size="sm" onClick={() => setEditing("new")}><Plus className="h-4 w-4" aria-hidden />Даалгавар нэмэх</Button>
      </div>
      {rowErr && <ErrorBox message={rowErr} />}
      {editing === "new" && <Card className="p-5"><TaskForm studentId={studentId} onDone={(t) => { if (t) setData([...list, t]); setEditing(null); }} /></Card>}
      {CATEGORIES.map((c) => {
        const items = list.filter((t) => t.category === c.id);
        if (!items.length) return null;
        return (
          <Card key={c.id}>
            <CardHeader title={c.label} hint={`${items.filter((t) => t.active).length} идэвхтэй`} />
            <ul className="mt-3">
              {items.map((t) => (
                <li key={t.id} className="border-t border-line">
                  {editing === t.id ? (
                    <div className="p-5"><TaskForm studentId={studentId} task={t} onDone={(u) => { if (u) setData(list.map((x) => (x.id === u.id ? u : x))); setEditing(null); }} /></div>
                  ) : (
                    <div className={cx("flex items-start gap-3 px-5 py-3", !t.active && "opacity-60")}>
                      <div className="min-w-0 flex-1">
                        <p className="font-medium">{t.title}{!t.active && <span className="ml-2 text-sm font-normal text-muted">· түр зогссон</span>}</p>
                        <p className="text-sm text-muted">{SLOTS[t.slot]}{t.minutes ? ` · ${t.minutes} мин` : ""}{t.is_mongol ? " · Монгол хэл" : ""} · {t.points} оноо</p>
                      </div>
                      <button className="grid h-10 w-10 place-items-center rounded-ctl text-muted hover:bg-sunken hover:text-ink" aria-label={`${t.title} засах`} onClick={() => setEditing(t.id)}><Pencil className="h-4 w-4" aria-hidden /></button>
                      <Button size="sm" variant="ghost" onClick={() => toggleActive(t)}>{t.active ? "Түр зогсоох" : "Сэргээх"}</Button>
                    </div>
                  )}
                </li>
              ))}
            </ul>
          </Card>
        );
      })}
    </div>
  );
}

function TaskForm({ studentId, task, onDone }: { studentId: string; task?: Task; onDone: (t: Task | null) => void }) {
  const [d, setD] = useState<Draft>(task ? { title: task.title, description: task.description, category: task.category, slot: task.slot, minutes: String(task.minutes), points: String(task.points ?? 5), is_mongol: task.is_mongol } : blank);
  const [err, setErr] = useState<{ title?: string; minutes?: string; points?: string; form?: string }>({});
  const [busy, setBusy] = useState(false);
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const m = Number(d.minutes);
    const v: typeof err = {};
    if (!d.title.trim()) v.title = "Нэрийг бичнэ үү.";
    if (d.minutes === "" || !Number.isInteger(m) || m < 0 || m > 180) v.minutes = "0–180 минутын бүхэл тоо оруулна уу.";
    const pts = Number(d.points);
    if (d.points === "" || !Number.isInteger(pts) || pts < 0 || pts > 100) v.points = "0–100 хооронд бүхэл тоо.";
    setErr(v); if (Object.keys(v).length) return;
    setBusy(true);
    try {
      const row = { title: d.title.trim(), description: d.description.trim(), category: d.category, slot: d.slot, minutes: m, points: Number(d.points), is_mongol: d.is_mongol };
      const t = task ? await api.updateTask(task.id, row) : await api.createTask({ ...row, student_id: studentId, sort: 100 });
      onDone(t);
    } catch (e) { setErr({ form: friendlyError(e) }); setBusy(false); }
  };
  const fid = task?.id ?? "new";
  return (
    <form onSubmit={submit} className="grid gap-4" noValidate>
      <div className="flex items-center justify-between"><h3 className="font-semibold">{task ? "Даалгавар засах" : "Шинэ даалгавар"}</h3>
        <button type="button" className="grid h-10 w-10 place-items-center rounded-ctl text-muted hover:bg-sunken" aria-label="Болих" onClick={() => onDone(null)}><X className="h-5 w-5" aria-hidden /></button></div>
      <Field label="Нэр" htmlFor={`tf-title-${fid}`} error={err.title}><Input id={`tf-title-${fid}`} maxLength={80} value={d.title} invalid={!!err.title} onChange={(e) => setD({ ...d, title: e.target.value })} /></Field>
      <Field label="Товч тайлбар" htmlFor={`tf-desc-${fid}`} hint="Хүүхдэд ойлгомжтой, богино өгүүлбэр"><Input id={`tf-desc-${fid}`} maxLength={200} value={d.description} onChange={(e) => setD({ ...d, description: e.target.value })} /></Field>
      <div className="grid gap-4 sm:grid-cols-3">
        <Field label="Бүлэг" htmlFor={`tf-cat-${fid}`}><Select id={`tf-cat-${fid}`} value={d.category} onChange={(e) => setD({ ...d, category: e.target.value as Category })}>{CATEGORIES.map((c) => <option key={c.id} value={c.id}>{c.label}</option>)}</Select></Field>
        <Field label="Үе" htmlFor={`tf-slot-${fid}`}><Select id={`tf-slot-${fid}`} value={d.slot} onChange={(e) => setD({ ...d, slot: e.target.value as Slot })}>{Object.entries(SLOTS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</Select></Field>
        <Field label="Хугацаа, минут" htmlFor={`tf-min-${fid}`} error={err.minutes} hint="0 бол харуулахгүй"><Input id={`tf-min-${fid}`} type="number" inputMode="numeric" min={0} max={180} value={d.minutes} invalid={!!err.minutes} onChange={(e) => setD({ ...d, minutes: e.target.value })} /></Field>
      </div>
      <div className="sm:w-1/3"><Field label="Оноо" htmlFor={`tf-pts-${fid}`} error={err.points} hint="«Хийсэн» гэж тэмдэглэхэд өгнө"><Input id={`tf-pts-${fid}`} type="number" inputMode="numeric" min={0} max={100} value={d.points} invalid={!!err.points} onChange={(e) => setD({ ...d, points: e.target.value })} /></Field></div>
      <div><Checkbox checked={d.is_mongol} onChange={(v) => setD({ ...d, is_mongol: v })} label="Монгол хэлний унших-бичих даалгавар" /></div>
      {err.form && <ErrorBox message={err.form} />}
      <div className="flex justify-end gap-2"><Button type="button" variant="secondary" onClick={() => onDone(null)}>Болих</Button><Button type="submit" loading={busy}>{task ? "Хадгалах" : "Нэмэх"}</Button></div>
    </form>
  );
}

// ------------------------------------------------------------ Хуваарь

export function ScheduleEditor({ studentId }: { studentId: string }) {
  const { data, error, loading, reload } = useLoad(() => api.listSchedule(studentId), [studentId]);
  const [rows, setRows] = useState<ScheduleItem[]>([]);
  const [removed, setRemoved] = useState<string[]>([]);
  const [invalid, setInvalid] = useState<string | null>(null);
  const save = useSave();
  useEffect(() => { if (data) { setRows(data); setRemoved([]); } }, [data]);

  if (loading && !data) return <Spinner />;
  if (error) return <ErrorBox message={error} onRetry={reload} />;

  const upd = (id: string, v: Partial<ScheduleItem>) => { setRows(rows.map((r) => (r.id === id ? { ...r, ...v } : r))); if (save.state.kind !== "saving") save.setState({ kind: "idle" }); };
  const add = () => setRows([...rows, { id: `new-${crypto.randomUUID()}`, student_id: studentId, start_time: null, period: "", activity: "", sort: (rows[rows.length - 1]?.sort ?? 0) + 10 }]);
  const del = (id: string) => { setRows(rows.filter((r) => r.id !== id)); if (!id.startsWith("new-")) setRemoved([...removed, id]); };
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (rows.some((r) => !r.activity.trim())) { setInvalid("Үйл ажиллагааны нүд хоосон мөр байна."); return; }
    setInvalid(null);
    const sorted = [...rows].sort((a, b) => (a.start_time ?? "99").localeCompare(b.start_time ?? "99")).map((r, i) => ({ ...r, sort: (i + 1) * 10, period: r.period.trim(), activity: r.activity.trim(), start_time: r.start_time || null }));
    const ok = await save.run(() => api.saveSchedule(studentId, sorted, removed));
    if (ok) await reload();
  };

  return (
    <Card>
      <CardHeader title="Өдрийн хуваарь" hint="Сургуулийн бодит хуваарь, замын хугацаа, нойрны хэрэгцээтэй уялдуулна" />
      <form onSubmit={submit} noValidate className="mt-3">
        {rows.length === 0 && <Empty title="Хуваарь хоосон">Мөр нэмнэ үү эсвэл «Даалгавар» хэсгээс анхны төлөвлөгөөг ачаална уу.</Empty>}
        <ul>
          {rows.map((r, i) => (
            <li key={r.id} className="grid grid-cols-[6.5rem_minmax(0,1fr)_auto] items-start gap-2 border-t border-line px-5 py-3 sm:grid-cols-[6.5rem_minmax(0,1fr)_minmax(0,1.4fr)_auto]">
              <Input type="time" aria-label={`Мөр ${i + 1}: цаг`} value={r.start_time?.slice(0, 5) ?? ""} onChange={(e) => upd(r.id, { start_time: e.target.value })} />
              <Input aria-label={`Мөр ${i + 1}: үе`} placeholder="Үе" maxLength={80} value={r.period} onChange={(e) => upd(r.id, { period: e.target.value })} />
              <Input aria-label={`Мөр ${i + 1}: үйл ажиллагаа`} placeholder="Үйл ажиллагаа" maxLength={160} value={r.activity} invalid={!!invalid && !r.activity.trim()}
                className="col-span-2 row-start-2 sm:col-span-1 sm:row-start-auto" onChange={(e) => upd(r.id, { activity: e.target.value })} />
              <button type="button" onClick={() => del(r.id)} aria-label={`Мөр ${i + 1} хасах`} className="col-start-3 row-start-1 grid h-12 w-11 place-items-center rounded-ctl text-muted hover:bg-bad-soft hover:text-bad sm:col-start-auto sm:row-start-auto"><Trash2 className="h-4 w-4" aria-hidden /></button>
            </li>
          ))}
        </ul>
        <div className="flex flex-wrap items-center justify-between gap-3 border-t border-line px-5 py-4">
          <Button type="button" size="sm" variant="secondary" onClick={add}><Plus className="h-4 w-4" aria-hidden />Мөр нэмэх</Button>
          <div className="flex flex-wrap items-center gap-3">
            {invalid ? <p className="text-sm font-medium text-bad" role="alert">{invalid}</p> : <SaveIndicator state={save.state} onRetry={save.retry} />}
            <Button type="submit" size="sm" loading={save.state.kind === "saving"}>Хадгалах</Button>
          </div>
        </div>
      </form>
    </Card>
  );
}

// ------------------------------------------------------------ Тэмдэглэл, зорилго

export function NotesPanel({ studentId }: { studentId: string }) {
  const today = todayUB(), tomorrow = addDays(today, 1);
  const { data, setData, error, loading, reload } = useLoad(async () => {
    const [goals, notes] = await Promise.all([api.listGoals(studentId, today, tomorrow), api.listTeacherNotes(studentId)]);
    return { goals, notes };
  }, [studentId, today]);
  const [goalT, setGoalT] = useState(""); const [goalN, setGoalN] = useState("");
  const [body, setBody] = useState(""); const [share, setShare] = useState(true);
  const goalSave = useSave(), noteSave = useSave();
  const [delErr, setDelErr] = useState<string | null>(null);
  useEffect(() => {
    if (!data) return;
    setGoalT(data.goals.find((g) => g.log_date === today)?.goal ?? "");
    setGoalN(data.goals.find((g) => g.log_date === tomorrow)?.goal ?? "");
  }, [data, today, tomorrow]);

  if (loading && !data) return <Spinner />;
  if (error) return <ErrorBox message={error} onRetry={reload} />;
  if (!data) return null;

  const saveGoals = () => goalSave.run(async () => { await api.saveGoal(studentId, today, goalT); await api.saveGoal(studentId, tomorrow, goalN); });
  const addNote = async (e: FormEvent) => {
    e.preventDefault();
    if (!body.trim()) return;
    const ok = await noteSave.run(async () => { const n = await api.addTeacherNote(studentId, body.trim(), share); setData({ ...data, notes: [n, ...data.notes] }); });
    if (ok) setBody("");
  };
  const remove = async (id: string) => {
    setDelErr(null);
    try { await api.deleteTeacherNote(id); setData({ ...data, notes: data.notes.filter((n) => n.id !== id) }); } catch (e) { setDelErr(friendlyError(e)); }
  };

  return (
    <div className="grid gap-5">
      <Card className="p-5">
        <h2 className="text-[17px] font-semibold">Өдрийн жижиг зорилго</h2>
        <p className="mt-0.5 text-sm text-muted">Сурагч болон эцэг эхийн нүүр хуудсанд харагдана.</p>
        <div className="mt-4 grid gap-4">
          <Field label={`Өнөөдөр · ${formatShort(today)}`} htmlFor="goal-t"><Input id="goal-t" maxLength={140} value={goalT} onChange={(e) => setGoalT(e.target.value)} placeholder="Жишээ нь: Хоёр өгүүлбэр бие даан бичих" /></Field>
          <Field label={`Маргааш · ${formatShort(tomorrow)}`} htmlFor="goal-n"><Input id="goal-n" maxLength={140} value={goalN} onChange={(e) => setGoalN(e.target.value)} /></Field>
        </div>
        <div className="mt-4 flex flex-wrap items-center justify-between gap-3"><SaveIndicator state={goalSave.state} onRetry={goalSave.retry} /><Button size="sm" onClick={saveGoals} loading={goalSave.state.kind === "saving"}>Зорилго хадгалах</Button></div>
      </Card>

      <Card>
        <CardHeader title="Багшийн тэмдэглэл" hint="Сурагч харахгүй. Хуваалцсан тэмдэглэлийг эцэг эх харна." />
        <form onSubmit={addNote} className="grid gap-3 p-5" noValidate>
          <label htmlFor="tn-body" className="sr-only">Шинэ тэмдэглэл</label>
          <Textarea id="tn-body" maxLength={1000} value={body} onChange={(e) => setBody(e.target.value)} placeholder="Ахиц, ажиглалт, дараагийн алхам" />
          <div className="flex flex-wrap items-center justify-between gap-3">
            <Checkbox checked={share} onChange={setShare} label="Эцэг эхтэй хуваалцах" />
            <div className="flex items-center gap-3"><SaveIndicator state={noteSave.state} onRetry={noteSave.retry} /><Button type="submit" size="sm" disabled={!body.trim()} loading={noteSave.state.kind === "saving"}>Нэмэх</Button></div>
          </div>
        </form>
        {delErr && <div className="px-5 pb-3"><ErrorBox message={delErr} /></div>}
        {data.notes.length ? (
          <ul>{data.notes.map((n) => (
            <li key={n.id} className="flex items-start gap-3 border-t border-line px-5 py-4">
              <div className="min-w-0 flex-1">
                <p className="whitespace-pre-wrap text-[15px]">{n.body}</p>
                <p className="mt-1 text-[13px] text-muted">{formatLong(n.log_date)} · {n.share_with_guardian ? "Эцэг эхтэй хуваалцсан" : "Зөвхөн багш"}</p>
              </div>
              <button onClick={() => remove(n.id)} aria-label="Тэмдэглэл устгах" className="grid h-10 w-10 shrink-0 place-items-center rounded-ctl text-muted hover:bg-bad-soft hover:text-bad"><Trash2 className="h-4 w-4" aria-hidden /></button>
            </li>))}
          </ul>
        ) : <p className="border-t border-line px-5 py-5 text-[15px] text-muted">Тэмдэглэл алга.</p>}
      </Card>
    </div>
  );
}

// ------------------------------------------------------------ Тохиргоо

export function SettingsPanel({ student, onSaved }: { student: Student; onSaved: (s: Student) => void }) {
  const [goal, setGoal] = useState(String(student.goal_pct));
  const [limit, setLimit] = useState(String(student.screen_limit_min));
  const [err, setErr] = useState<{ goal?: string; limit?: string }>({});
  const save = useSave();

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const g = Number(goal), l = Number(limit); const v: typeof err = {};
    if (!Number.isInteger(g) || g < 10 || g > 100) v.goal = "10–100 хооронд бүхэл тоо.";
    if (!Number.isInteger(l) || l < 0 || l > 600) v.limit = "0–600 минутын хооронд.";
    setErr(v); if (Object.keys(v).length) return;
    const ok = await save.run(() => api.updateStudentSettings(student.id, { goal_pct: g, screen_limit_min: l }));
    if (ok) onSaved({ ...student, goal_pct: g, screen_limit_min: l });
  };

  return (
    <Card className="p-5">
      <h2 className="text-[17px] font-semibold">Зорилго ба хязгаар</h2>
      <form onSubmit={submit} className="mt-4 grid gap-4" noValidate>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Өдрийн зорилго, %" htmlFor="st-goal" hint="Эхэндээ бага зорилгоос эхэлж, аажмаар нэмнэ" error={err.goal}><Input id="st-goal" type="number" inputMode="numeric" value={goal} invalid={!!err.goal} onChange={(e) => setGoal(e.target.value)} /></Field>
          <Field label="Дэлгэцийн өдрийн хязгаар, минут" htmlFor="st-lim" hint="Гэр бүлтэй тохирсон хэмжээ" error={err.limit}><Input id="st-lim" type="number" inputMode="numeric" value={limit} invalid={!!err.limit} onChange={(e) => setLimit(e.target.value)} /></Field>
        </div>
        <div className="flex flex-wrap items-center justify-between gap-3"><SaveIndicator state={save.state} onRetry={save.retry} /><Button type="submit" size="sm" loading={save.state.kind === "saving"}>Хадгалах</Button></div>
      </form>
    </Card>
  );
}

// ------------------------------------------------------------ Шагнал

type RDraft = { title: string; description: string; icon: RewardIcon; cost: string };

export function RewardsEditor({ studentId }: { studentId: string }) {
  const { data, setData, error, loading, reload } = useLoad(async () => {
    const [rewards, redemptions, points] = await Promise.all([api.listRewards(studentId, true), api.listRedemptions(studentId), api.pointsSummary(studentId)]);
    return { rewards, redemptions, points };
  }, [studentId]);
  const [editing, setEditing] = useState<string | "new" | null>(null);
  const [rowErr, setRowErr] = useState<string | null>(null);
  if (loading && !data) return <Spinner />;
  if (error) return <ErrorBox message={error} onRetry={reload} />;
  if (!data) return null;
  const { rewards, redemptions, points } = data;
  const replace = (r: Reward) => setData({ ...data, rewards: rewards.some((x) => x.id === r.id) ? rewards.map((x) => (x.id === r.id ? r : x)) : [...rewards, r] });
  const toggle = async (r: Reward) => {
    setRowErr(null);
    try { replace(await api.updateReward(r.id, { active: !r.active })); } catch (e) { setRowErr(friendlyError(e)); }
  };

  return (
    <div className="grid gap-5">
      <Card className="flex flex-wrap items-end justify-between gap-3 p-5">
        <div><p className="text-[15px] text-muted">Сурагчийн оноо</p><p className="tnum text-3xl font-semibold">{points.balance}</p></div>
        <p className="tnum text-sm text-muted">Цуглуулсан {points.earned} · Зарцуулсан {points.spent}</p>
      </Card>
      <Notice>Даалгавар бүрийн оноог «Даалгавар» табаас засна. Шагнал бол эцэг эх, багштай тохиролцох урамшуулал бөгөөд сайт өөрөө юм худалдаж өгөхгүй.</Notice>
      {rowErr && <ErrorBox message={rowErr} />}

      <Card>
        <CardHeader title="Шагналын жагсаалт" action={<Button size="sm" onClick={() => setEditing("new")}><Plus className="h-4 w-4" aria-hidden />Шагнал нэмэх</Button>} />
        {editing === "new" && <div className="mt-3 border-t border-line p-5"><RewardForm studentId={studentId} onDone={(r) => { if (r) replace(r); setEditing(null); }} /></div>}
        <ul className="mt-3">
          {rewards.map((r) => (
            <li key={r.id} className="border-t border-line">
              {editing === r.id ? <div className="p-5"><RewardForm studentId={studentId} reward={r} onDone={(u) => { if (u) replace(u); setEditing(null); }} /></div> : (
                <div className={cx("flex items-center gap-3 px-5 py-3", !r.active && "opacity-60")}>
                  <span className="grid h-10 w-10 shrink-0 place-items-center rounded-ctl bg-sunken"><RewardIconView kind={r.icon} className="h-5 w-5" /></span>
                  <div className="min-w-0 flex-1"><p className="font-medium">{r.title}{!r.active && <span className="ml-2 text-sm font-normal text-muted">· нуусан</span>}</p><p className="tnum text-sm text-muted">{r.cost} оноо</p></div>
                  <button className="grid h-10 w-10 place-items-center rounded-ctl text-muted hover:bg-sunken hover:text-ink" aria-label={`${r.title} засах`} onClick={() => setEditing(r.id)}><Pencil className="h-4 w-4" aria-hidden /></button>
                  <Button size="sm" variant="ghost" onClick={() => toggle(r)}>{r.active ? "Нуух" : "Харуулах"}</Button>
                </div>
              )}
            </li>
          ))}
        </ul>
        {!rewards.length && editing !== "new" && <Empty title="Шагнал алга">«Шагнал нэмэх» товчоор эхлүүлнэ үү.</Empty>}
      </Card>

      <Card>
        <CardHeader title="Сурагчийн авсан шагналууд" />
        {redemptions.length ? <ul className="mt-3">{redemptions.map((r) => (
          <li key={r.id} className="flex justify-between gap-3 border-t border-line px-5 py-3 text-[15px]"><span className="min-w-0">{r.title}</span><span className="tnum shrink-0 text-sm text-muted">{formatShort(r.created_at.slice(0, 10))} · −{r.cost}</span></li>))}</ul>
          : <p className="px-5 pb-5 pt-2 text-[15px] text-muted">Одоогоор шагнал аваагүй.</p>}
      </Card>
    </div>
  );
}

function RewardForm({ studentId, reward, onDone }: { studentId: string; reward?: Reward; onDone: (r: Reward | null) => void }) {
  const [d, setD] = useState<RDraft>(reward ? { title: reward.title, description: reward.description, icon: reward.icon, cost: String(reward.cost) } : { title: "", description: "Эцэг эх/багштай тохиролцож авна.", icon: "gift", cost: "100" });
  const [err, setErr] = useState<{ title?: string; cost?: string; form?: string }>({});
  const [busy, setBusy] = useState(false);
  const fid = reward?.id ?? "new";
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const c = Number(d.cost); const v: typeof err = {};
    if (!d.title.trim()) v.title = "Нэрийг бичнэ үү.";
    if (!Number.isInteger(c) || c < 1 || c > 10000) v.cost = "1–10000 хооронд бүхэл тоо.";
    setErr(v); if (Object.keys(v).length) return;
    setBusy(true);
    try {
      const row = { title: d.title.trim(), description: d.description.trim(), icon: d.icon, cost: c };
      onDone(reward ? await api.updateReward(reward.id, row) : await api.createReward({ ...row, student_id: studentId }));
    } catch (e) { setErr({ form: friendlyError(e) }); setBusy(false); }
  };
  return (
    <form onSubmit={submit} className="grid gap-4" noValidate>
      <div className="flex items-center justify-between"><h3 className="font-semibold">{reward ? "Шагнал засах" : "Шинэ шагнал"}</h3>
        <button type="button" className="grid h-10 w-10 place-items-center rounded-ctl text-muted hover:bg-sunken" aria-label="Болих" onClick={() => onDone(null)}><X className="h-5 w-5" aria-hidden /></button></div>
      <Field label="Нэр" htmlFor={`rf-title-${fid}`} error={err.title}><Input id={`rf-title-${fid}`} maxLength={60} value={d.title} invalid={!!err.title} onChange={(e) => setD({ ...d, title: e.target.value })} /></Field>
      <Field label="Тайлбар" htmlFor={`rf-desc-${fid}`}><Input id={`rf-desc-${fid}`} maxLength={160} value={d.description} onChange={(e) => setD({ ...d, description: e.target.value })} /></Field>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Дүрс" htmlFor={`rf-icon-${fid}`}><Select id={`rf-icon-${fid}`} value={d.icon} onChange={(e) => setD({ ...d, icon: e.target.value as RewardIcon })}>{REWARD_ICONS.map((i) => <option key={i.id} value={i.id}>{i.label}</option>)}</Select></Field>
        <Field label="Шаардлагатай оноо" htmlFor={`rf-cost-${fid}`} error={err.cost}><Input id={`rf-cost-${fid}`} type="number" inputMode="numeric" value={d.cost} invalid={!!err.cost} onChange={(e) => setD({ ...d, cost: e.target.value })} /></Field>
      </div>
      {err.form && <ErrorBox message={err.form} />}
      <div className="flex justify-end gap-2"><Button type="button" variant="secondary" onClick={() => onDone(null)}>Болих</Button><Button type="submit" loading={busy}>{reward ? "Хадгалах" : "Нэмэх"}</Button></div>
    </form>
  );
}
