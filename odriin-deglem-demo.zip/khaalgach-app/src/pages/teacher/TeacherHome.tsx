import { Link } from "react-router-dom";
import { ChevronRight } from "lucide-react";
import * as api from "../../lib/api";
import { useLoad } from "../../lib/hooks";
import { formatLong, todayUB } from "../../lib/dates";
import { dayProgress } from "../../lib/progress";
import { Card, Empty, ErrorBox, PageHeader, Progress, Spinner } from "../../components/ui";

export default function TeacherHome() {
  const today = todayUB();
  const { data, error, loading, reload } = useLoad(async () => {
    const students = await api.listStudents();
    const ids = students.map((s) => s.id);
    const [tasks, logs] = ids.length ? await Promise.all([api.listActiveTasksFor(ids), api.listLogs(ids, today, today)]) : [[], []];
    return { students, tasks, logs };
  }, [today]);

  if (loading && !data) return <Spinner />;
  if (error) return <ErrorBox message={error} onRetry={reload} />;
  const { students = [], tasks = [], logs = [] } = data ?? {};

  return (
    <div>
      <PageHeader eyebrow={formatLong(today)} title="Хариуцсан сурагчид">Өнөөдрийн биелэлт. Дэлгэрэнгүйг сурагч дээр дарж харна.</PageHeader>
      <Card>
        {students.length === 0 ? (
          <Empty title="Танд хариуцуулсан сурагч алга">Сургуулийн админ таны аккаунтыг сурагчтай холбосны дараа энд харагдана.</Empty>
        ) : (
          <ul>
            {students.map((s) => {
              const p = dayProgress(tasks.filter((t) => t.student_id === s.id), logs.filter((l) => l.student_id === s.id), today);
              return (
                <li key={s.id} className="border-b border-line last:border-b-0">
                  <Link to={`/t/student/${s.id}`} className="flex items-center gap-4 px-5 py-4 hover:bg-sunken/60">
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-baseline justify-between gap-x-3">
                        <p className="font-medium">{s.full_name}{s.class_name && <span className="ml-2 text-sm font-normal text-muted">{s.class_name}</span>}</p>
                        <p className="tnum text-sm text-muted">{p.pct}% · {p.done}/{p.total}
                          {p.help > 0 && <span className="ml-2 rounded-full bg-bad-soft px-2 py-0.5 text-[13px] font-medium text-bad">{p.help} дэмжлэг</span>}</p>
                      </div>
                      <div className="mt-2"><Progress pct={p.pct} label={`${s.full_name} ахиц`} /></div>
                    </div>
                    <ChevronRight className="h-5 w-5 shrink-0 text-muted" aria-hidden />
                  </Link>
                </li>
              );
            })}
          </ul>
        )}
      </Card>
    </div>
  );
}
