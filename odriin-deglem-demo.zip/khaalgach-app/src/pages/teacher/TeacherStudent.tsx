import { useState } from "react";
import { Link, useParams } from "react-router-dom";
import { ChevronLeft } from "lucide-react";
import * as api from "../../lib/api";
import { useLoad } from "../../lib/hooks";
import { addDays, formatLong, formatShort, lastDays, todayUB } from "../../lib/dates";
import { dayProgress } from "../../lib/progress";
import type { Student } from "../../lib/types";
import { CategoryBars, HomeLogSummary, WeekTable } from "../../components/Summaries";
import { Card, CardHeader, Empty, ErrorBox, PageHeader, Progress, Spinner, cx } from "../../components/ui";
import { NotesPanel, RewardsEditor, ScheduleEditor, SettingsPanel, TasksEditor } from "./Editors";

const TABS = [
  ["overview", "Тойм"], ["tasks", "Даалгавар"], ["schedule", "Хуваарь"], ["rewards", "Шагнал"], ["notes", "Тэмдэглэл, зорилго"], ["settings", "Тохиргоо"],
] as const;
type Tab = (typeof TABS)[number][0];

export default function TeacherStudent() {
  const { id = "" } = useParams();
  const [tab, setTab] = useState<Tab>("overview");
  const { data: student, setData, error, loading, reload } = useLoad(() => api.getStudent(id), [id]);

  if (loading && !student) return <Spinner />;
  if (error) return <ErrorBox message={error} onRetry={reload} />;
  if (!student) return (
    <Card><Empty title="Сурагч олдсонгүй">Энэ сурагч танд хариуцуулагдаагүй эсвэл бүртгэл байхгүй байна. <Link className="underline" to="/t">Жагсаалт руу буцах</Link></Empty></Card>
  );

  return (
    <div>
      <Link to="/t" className="inline-flex min-h-10 items-center gap-1 text-[15px] text-muted hover:text-ink"><ChevronLeft className="h-4 w-4" aria-hidden />Сурагчид</Link>
      <PageHeader title={student.full_name}>{student.class_name ?? "51 дүгээр сургууль"}</PageHeader>
      <div role="tablist" aria-label="Сурагчийн хэсгүүд" className="-mx-4 mb-5 flex gap-1 overflow-x-auto px-4 [scrollbar-width:none] sm:mx-0 sm:px-0">
        {TABS.map(([k, label]) => (
          <button key={k} role="tab" aria-selected={tab === k} onClick={() => setTab(k)}
            className={cx("min-h-10 shrink-0 rounded-full px-4 text-[15px] transition-colors", tab === k ? "bg-ink text-bg" : "text-muted hover:bg-sunken hover:text-ink")}>
            {label}
          </button>
        ))}
      </div>
      <div role="tabpanel">
        {tab === "overview" && <Overview student={student} />}
        {tab === "tasks" && <TasksEditor studentId={student.id} />}
        {tab === "schedule" && <ScheduleEditor studentId={student.id} />}
        {tab === "rewards" && <RewardsEditor studentId={student.id} />}
        {tab === "notes" && <NotesPanel studentId={student.id} />}
        {tab === "settings" && <SettingsPanel student={student} onSaved={(s: Student) => setData(s)} />}
      </div>
    </div>
  );
}

function Overview({ student }: { student: Student }) {
  const today = todayUB();
  const days = lastDays(7, today);
  const { data, error, loading, reload } = useLoad(async () => {
    const from = addDays(today, -6);
    const [tasks, logs, home, notes] = await Promise.all([
      api.listTasks(student.id), api.listLogs([student.id], from, today),
      api.listHomeLogs(student.id, from, today), api.listStudentNotes(student.id, from, today),
    ]);
    return { tasks, logs, home, notes };
  }, [student.id, today]);
  if (loading && !data) return <Spinner />;
  if (error) return <ErrorBox message={error} onRetry={reload} />;
  if (!data) return null;
  const { tasks, logs, home, notes } = data;
  const p = dayProgress(tasks, logs, today);
  const helps = logs.filter((l) => l.status === "help").sort((a, b) => b.log_date.localeCompare(a.log_date));
  const title = (tid: string) => tasks.find((t) => t.id === tid)?.title ?? "Хасагдсан даалгавар";
  const todayNote = notes.find((n) => n.log_date === today)?.note;

  return (
    <div className="grid gap-5">
      <Card className="p-5">
        <div className="flex items-baseline justify-between gap-3">
          <h2 className="text-[17px] font-semibold">Өнөөдөр</h2>
          <p className="tnum text-[15px] text-muted">{p.done}/{p.total} хийсэн · {p.pct}% · зорилго {student.goal_pct}%</p>
        </div>
        <div className="mt-3"><Progress pct={p.pct} label="Өнөөдрийн биелэлт" /></div>
        <div className="mt-5"><CategoryBars tasks={tasks} logs={logs} date={today} /></div>
        {todayNote && <p className="mt-5 rounded-ctl bg-sunken p-3 text-[15px]"><span className="text-muted">Сурагчийн тэмдэглэл: </span>{todayNote}</p>}
      </Card>

      <Card>
        <CardHeader title="Дэмжлэг хэрэгтэй гэж тэмдэглэсэн" hint="Сүүлийн 7 хоног" />
        {helps.length ? (
          <ul className="mt-2">{helps.map((h) => (
            <li key={h.task_id + h.log_date} className="flex justify-between gap-3 border-t border-line px-5 py-3 text-[15px]">
              <span className="min-w-0">{title(h.task_id)}</span><span className="tnum shrink-0 text-sm text-muted">{formatShort(h.log_date)}</span>
            </li>))}
          </ul>
        ) : <p className="px-5 pb-5 pt-2 text-[15px] text-muted">Дэмжлэг хүссэн даалгавар алга.</p>}
      </Card>

      <Card>
        <CardHeader title="Долоо хоног" hint="Дэлгэц, хөдөлгөөнийг эцэг эх бөглөнө" />
        <div className="mt-3 border-t border-line"><WeekTable days={days} tasks={tasks} logs={logs} home={home} screenLimit={student.screen_limit_min} /></div>
      </Card>

      <Card>
        <CardHeader title="Гэрийн хуудас" hint={formatLong(today)} />
        <div className="mt-1"><HomeLogSummary log={home.find((h) => h.log_date === today)} screenLimit={student.screen_limit_min} /></div>
      </Card>
    </div>
  );
}
