import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter, MemoryRouter } from "react-router-dom";
import "./index.css";
import { configMissing } from "./lib/supabase";
import { AuthProvider } from "./lib/auth";
import App from "./App";
import { initTheme } from "./lib/theme";
import ConfigMissing from "./pages/ConfigMissing";

// Нэг HTML файлаар (artifact, offline) нээх үед URL-гүй MemoryRouter ашиглана.
const Router = import.meta.env.VITE_ROUTER === "memory" ? MemoryRouter : BrowserRouter;

initTheme();

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    {configMissing ? <ConfigMissing /> : (
      <Router>
        <AuthProvider><App /></AuthProvider>
      </Router>
    )}
  </StrictMode>,
);
