import { Navigate, Route, Routes } from "react-router-dom";
import { useAuth } from "./lib/auth";
import { ROLE_META } from "./lib/constants";
import { RequireRole } from "./components/AppShell";
import { Spinner } from "./components/ui";
import Login from "./pages/Login";
import StudentDay from "./pages/student/StudentDay";
import StudentSchedule from "./pages/student/StudentSchedule";
import StudentHistory from "./pages/student/StudentHistory";
import StudentRewards from "./pages/student/StudentRewards";
import TeacherHome from "./pages/teacher/TeacherHome";
import TeacherStudent from "./pages/teacher/TeacherStudent";
import { ParentToday, ParentWeek } from "./pages/parent/ParentPages";

function Home() {
  const { state } = useAuth();
  if (state.status === "loading") return <Spinner />;
  return <Navigate to={state.status === "signedIn" ? ROLE_META[state.profile.role].home : "/login"} replace />;
}

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/s" element={<RequireRole role="student" />}>
        <Route index element={<StudentDay />} />
        <Route path="day/:date" element={<StudentDay />} />
        <Route path="rewards" element={<StudentRewards />} />
        <Route path="schedule" element={<StudentSchedule />} />
        <Route path="history" element={<StudentHistory />} />
      </Route>
      <Route path="/t" element={<RequireRole role="teacher" />}>
        <Route index element={<TeacherHome />} />
        <Route path="student/:id" element={<TeacherStudent />} />
      </Route>
      <Route path="/p" element={<RequireRole role="guardian" />}>
        <Route index element={<ParentToday />} />
        <Route path="week" element={<ParentWeek />} />
      </Route>
      <Route path="*" element={<Home />} />
    </Routes>
  );
}
